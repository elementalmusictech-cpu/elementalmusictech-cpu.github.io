// prism_bridge.js
// Auto-resolves Instrument/Drum Rack macros on the parent track.
// Observes device swaps, preset loads, and macro name changes.
//
// Activation-gated: the device does NOTHING until it receives `active 1`
// (driven by the __PrismBridge__ param). `active 0` unwinds everything and
// frees the macros. An inactive bridge holds zero LiveAPI objects and zero
// bound live.remote~ targets — it is fully transparent.
//
// Expected patch wiring:  live.toggle (__PrismBridge__) -> prepend active -> js inlet
//
// Outlet 0 (left):   slot_number "id" param_id   (e.g. 1 id 42)
// Outlet 1 (middle): slot_number name_string      (e.g. 1 Filter Cutoff)
// Outlet 2 (right):  slot_number value_0_127       (e.g. 1 64)

autowatch = 1;
inlets = 1;
outlets = 3;

var MACRO_COUNT = 16;

// --- Globals: prevent GC from killing observers ---
var g = {
	devicesObserver: null,
	rackNameObserver: null,
	nameObservers: [],
	resolveTask: null,
	active: false,        // driven by __PrismBridge__ via active()
	ready: false,         // live.thisdevice bang received
	pendingActive: false, // active(1) arrived before ready
	bound: {},            // slot -> { id, min, max }
	heard: {},            // slot -> value live.remote~ is applying
	dirty: {}             // slots Prism moved since bind
};

// --- Entry point: bang from live.thisdevice ---
// No longer starts observers directly. Marks the device ready and applies a
// deferred activation if `active 1` raced ahead of device load (possible
// during lazy insert: the script can write the param before the js is live).
function bang() {
	g.ready = true;
	if (g.pendingActive) {
		g.pendingActive = false;
		startObserving();   // g.active is already true
	}
}

// === ACTIVATION LAYER ===

// Entry point from the __PrismBridge__ param: `active 1` / `active 0`.
// Also the manual kill switch — a UI click on the toggle arrives here too.
function active(v) {
	var on = (v == 1);
	if (on) {
		if (g.active) return;          // 1 -> 1, nothing to do
		g.active = true;
		if (g.ready) startObserving();
		else g.pendingActive = true;   // apply when live.thisdevice bangs
	} else {
		if (!g.active && !g.pendingActive) return;  // already off
		g.active = false;
		g.pendingActive = false;
		stopObserving();
	}
}

// === OBSERVATION LAYER ===

function startObserving() {
    stopDevicesObserver();

    // Observe future track-device changes.
    g.devicesObserver = new LiveAPI(
        onDevicesChanged,
        "this_device canonical_parent"
    );
    g.devicesObserver.property = "devices";

    // IMPORTANT:
    // Do not rely on LiveAPI's initial property callback to perform
    // the initial bind. Always resolve explicitly whenever the bridge
    // transitions active again.
    scheduleResolve();
}

// Patch tap: gate 2 right outlet -> prepend ccvalue.
function ccvalue(num, v) {
	var b = g.bound[num];
	if (!b) return;
	g.heard[num] = b.min + (v / 127.0) * (b.max - b.min);
	g.dirty[num] = true;
}

// Store what each macro was actually playing before releasing it.
function writeBackMacros() {
	for (var key in g.dirty) {
		var b = g.bound[key];
		if (!b || !b.id) continue;
		try {
			var wb = new LiveAPI("id " + b.id);
			if (parseInt(wb.id) === 0) continue;
			wb.set("value", Math.max(b.min, Math.min(b.max, g.heard[key])));
		} catch (e) {
			post("PrismBridge write-back error: " + e + "\n");
		}
	}
	g.bound = {}; g.heard = {}; g.dirty = {};
}

function stopObserving() {
	if (g.resolveTask) { g.resolveTask.cancel(); g.resolveTask = null; }
	stopDevicesObserver();
	clearRackObservers();
	writeBackMacros();
	clear_all();  // emits id 0 per slot -> unbinds every live.remote~
	outlet(0, "teardown_done");
}

function stopDevicesObserver() {
	if (g.devicesObserver) {
		g.devicesObserver.property = "";
		g.devicesObserver.id = 0;
		g.devicesObserver = null;
	}
}

function onDevicesChanged(args) {
	if ((args[0] + "") === "devices") {
		scheduleResolve();
	}
}

// Change-detecting name callback: ignores the initial fire on .property
// assignment (and any duplicate notifications) by comparing against the
// name captured at resolve time. Only a REAL name change triggers a
// re-resolve — this is what breaks the resolve → attach → fire → resolve loop.
function makeNameCallback(initialName) {
	var lastName = initialName;
	return function (args) {
		if ((args[0] + "") !== "name") return;
		var newName = (args[1] + "").split('"').join("");
		if (newName === lastName) return;
		lastName = newName;
		scheduleResolve();
	};
}

// "id 12 id 13 ..." -> "12,13" (non-numeric tokens dropped)
function idsSig(arr) {
	var out = [];
	for (var i = 0; i < arr.length; i++) {
		var n = parseInt(arr[i]);
		if (!isNaN(n)) out.push(n);
	}
	return out.join(",");
}

// Same change-detecting pattern as makeNameCallback: ignores the initial
// fire on .property assignment; re-resolves only on a real list change.
function makeParamsCallback(initialSig) {
	var lastSig = initialSig;
	return function (args) {
		if ((args[0] + "") !== "parameters") return;
		var sig = idsSig(args);
		if (sig === lastSig) return;
		lastSig = sig;
		scheduleResolve();
	};
}

function scheduleResolve() {
	if (!g.active) return;  // inactive bridge does nothing
	if (g.resolveTask) g.resolveTask.cancel();
	g.resolveTask = new Task(function () { resolve(); });
	g.resolveTask.schedule(150); // ms — coalesces remove+add bursts
}

function attachRackObservers(rackId, rackName, paramIds, paramNames, paramsSig) {
	clearRackObservers();

	// Observe rack device name (preset loads rename the device)
	if (rackId > 0) {
		g.rackNameObserver = new LiveAPI(makeNameCallback(rackName), "id " + rackId);
		g.rackNameObserver.property = "name";

		// Parameter-list changes (plugin Configure add/remove/reorder).
		// Same teardown path as the name observers.
		var pobs = new LiveAPI(makeParamsCallback(paramsSig), "id " + rackId);
		pobs.property = "parameters";
		g.nameObservers.push(pobs);
	}

	// Observe each macro parameter's name (catches macro remapping)
	for (var i = 0; i < paramIds.length; i++) {
		if (paramIds[i] > 0) {
			var obs = new LiveAPI(makeNameCallback(paramNames[i]), "id " + paramIds[i]);
			obs.property = "name";
			g.nameObservers.push(obs);
		}
	}
}

function clearRackObservers() {
	for (var i = 0; i < g.nameObservers.length; i++) {
		g.nameObservers[i].property = "";
		g.nameObservers[i].id = 0;
	}
	g.nameObservers = [];

	if (g.rackNameObserver) {
		g.rackNameObserver.property = "";
		g.rackNameObserver.id = 0;
		g.rackNameObserver = null;
	}
}

// === RESOLVE LOGIC ===

function resolve() {
	var i;

	try {
		var api = new LiveAPI("this_device canonical_parent");

		if (parseInt(api.id) === 0) {
			post("PrismBridge: could not find parent track\n");
			clearRackObservers();
			clear_all();
			return;
		}

		var num_devices = api.getcount("devices");
		var inst_index = -1;

		// Walk devices, find first instrument (type 1)
		for (i = 0; i < num_devices; i++) {
			api.goto("this_device canonical_parent devices " + i);
			var dev_type = parseInt(api.get("type") + "");
			if (dev_type === 1) {
				inst_index = i;
				break;
			}
		}

		if (inst_index === -1) {
			post("PrismBridge: no instrument on track\n");
			clearRackObservers();
			clear_all();
			return;
		}

		// Check if it's a rack (InstrumentGroupDevice or DrumGroupDevice)
		api.goto("this_device canonical_parent devices " + inst_index);
		var class_name = (api.get("class_name") + "").split('"').join("");

		if (class_name === "OriginalSimpler") {
			clearRackObservers();
			writeBackMacros();
			clear_all();
			return;
		}

		// if (class_name.indexOf("GroupDevice") === -1) {
		// 	post("PrismBridge: instrument '" + (api.get("name") + "").split('"').join("") +
		// 		"' is not a rack, CC mapping skipped\n");
		// 	clearRackObservers();
		// 	clear_all();
		// 	return;
		// }

		var rack_id = parseInt(api.id);
		var rack_name = (api.get("name") + "").split('"').join("");
		var params_sig = idsSig(api.get("parameters"));
		var num_params = api.getcount("parameters");


		var paramIds = [];
		var paramNames = [];

		// Parameters 1-16 are macros (parameter 0 is Device On)
		for (i = 1; i <= MACRO_COUNT; i++) {
			if (i < num_params) {
				api.goto("this_device canonical_parent devices " +
					inst_index + " parameters " + i);
				var param_id = parseInt(api.id);
				var param_name = (api.get("name") + "").split('"').join("");

				if (param_id > 0) {
					// Read current value and scale to 0-127
					var val = parseFloat(api.get("value") + "");
					var pmin = parseFloat(api.get("min") + "");
					var pmax = parseFloat(api.get("max") + "");
					var scaled = 0;
					if (pmax > pmin) {
						scaled = Math.round((val - pmin) / (pmax - pmin) * 127);
					}

					// Bind first (deferred), then seed. The direct seed lands before the
					// bind; the deferlow'd copy (patch) lands right after it, so the
					// remote can never re-apply a value it held before teardown.
					outlet(0, i, "id", param_id);
					outlet(2, i, "range", pmin, pmax);
					outlet(2, i, scaled);
					g.bound[i] = { id: param_id, min: pmin, max: pmax };
					g.heard[i] = val;
					delete g.dirty[i];
					outlet(1, i, param_name);
					paramIds.push(param_id);
					paramNames.push(param_name);
				} else {
					outlet(0, i, "id", 0);
					outlet(1, i, "---");
					paramIds.push(0);
					paramNames.push("---");
				}
			} else {
				outlet(0, i, "id", 0);
				outlet(1, i, "---");
				paramIds.push(0);
				paramNames.push("---");
			}
		}

		// Attach name observers for preset/remap detection
		attachRackObservers(rack_id, rack_name, paramIds, paramNames, params_sig);

	} catch (e) {
		post("PrismBridge error: " + e + "\n");
		clearRackObservers();
		clear_all();
	}
}

function clear_all() {
    for (var i = 1; i <= MACRO_COUNT; i++) {
        outlet(0, i, "id", 0);
        outlet(1, i, "---");
    }

}
