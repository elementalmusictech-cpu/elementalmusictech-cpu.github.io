from __future__ import absolute_import, print_function, unicode_literals

import os
import random
import subprocess

import Live


class _FilesystemItem(object):
    """A folder/file outside Live's indexed browser, resolved from sample.file_path."""
    is_device = False

    def __init__(self, path, extensions):
        self.file_path = os.path.realpath(path)
        self.uri = 'prism-file:' + self.file_path
        self.name = os.path.basename(self.file_path) or self.file_path
        self.is_folder = os.path.isdir(self.file_path)
        self.is_loadable = not self.is_folder
        self._extensions = extensions

    @property
    def children(self):
        if not self.is_folder:
            return []
        with os.scandir(self.file_path) as entries:
            paths = [entry.path for entry in entries if not entry.name.startswith('.') and
                     (entry.is_dir() or (entry.is_file() and
                      os.path.splitext(entry.name)[1].lower() in self._extensions))]
        return [_FilesystemItem(path, self._extensions)
                for path in sorted(paths, key=lambda value: os.path.basename(value).lower())]


class PrismSampleLabConnector(object):
    """Sample Lab: swap the sample inside ONE existing drum-pad Simpler.

    Own pipe (0x33 request / 0x34 response).
    Waveform refresh after a swap goes out on 0x26 for the waveform coordinator.
    Never replaces devices, chains or racks.

    Loads: replace_sample(path) (Live 12.4+). Browser items get their path from
    Live's browser DB (FileId -> files table, via macOS sqlite3 CLI). Items with
    no FileId, or Live without replace_sample, fall back to a guarded hot-swap.

    Requests:  F0 7D 33 cmd b3 b4 argLo argHi session [x0 x1 x2] F7
      0x20 CAPS          b3=track b4=pad
      0x21 ROOTS         -
      0x22 CHILDREN      b3=page  arg=parent item id
      0x23 PREVIEW       arg=item id
      0x24 STOP_PREVIEW  -
      0x25 LOAD          b3=track b4=pad arg=item id
      0x26 SIMILAR       b3=track b4=pad arg=0 prev / 1 next / 2 random
      0x27 SESSION_BEGIN b3=track b4=pad   (snapshot for revert; replies CAPS,
                                            SESSION_OK, WARP_STATE)
      0x28 REVERT        b3=track b4=pad   (sample + warp + start/end + params)
      0x29 RANDOM        arg=parent item id (subfolders, then 32 random samples below it)
      0x2A WARP_STATE    b3=track b4=pad
      0x2B WARP_SET      b3=track b4=pad arg=field  x0..x2 = value*100 (u21)
      0x2C WARP_ACTION   b3=track b4=pad arg=0 half / 1 double / 2 as-N / 3 suggested
                                            x0..x1 = N (u14) for as-N
      0x2D BROWSER_OPEN  b3=track b4=pad arg=cached parent; extras epoch(u21), target(u21)

    Responses: F0 7D 34 type session ... F7
      0x20 LIST_BEGIN    session parentLo parentHi page hasMore
      0x21 ITEM          session idLo idHi flags name...
      0x22 LIST_END      session parentLo parentHi page hasMore
      0x23 LOAD_OK       session track pad name...
      0x24 CAPS          session major minor bugfix flags
                         flags: 1 replace_sample, 2 db_path, 4 warp_as,
                                8 warp_half, 16 warp_double, 32 guess_length
      0x25 WARP_STATE    session track pad warping mode can(1 as,2 half,4 double)
                         beats100(u21) seconds100(u21) suggestedBeats(u14)
                         count [fieldId value100(u21)]*count
      0x26 SESSION_OK    session track pad canRevert
      0x27 WARP_RESULT   session track pad requested(u14) resultBeats100(u21)
                         (sent right after warp_as so Prism can learn Live's limits)
      0x28 LOCATION_BEGIN session track pad epoch(u21) target(u21) restored
      0x29 LOCATION_ITEM  session track pad folderId(u14) name... (root to leaf)
      0x2A LOCATION_END   session track pad
      0x2B PREVIEW_END    session itemId(u14)
      0x2F ERROR         session track pad code text...
    """

    # Own pipe: requests 0x33, responses 0x34.
    REQUEST_TYPE = 0x33
    CMD_FIRST = 0x20
    CMD_CAPS = 0x20
    CMD_ROOTS = 0x21
    CMD_CHILDREN = 0x22
    CMD_PREVIEW = 0x23
    CMD_STOP_PREVIEW = 0x24
    CMD_LOAD = 0x25
    CMD_SIMILAR = 0x26
    CMD_SESSION_BEGIN = 0x27
    CMD_REVERT = 0x28
    CMD_RANDOM = 0x29
    CMD_WARP_STATE = 0x2A
    CMD_WARP_SET = 0x2B
    CMD_WARP_ACTION = 0x2C
    CMD_BROWSER_OPEN = 0x2D

    RESPONSE_TYPE = 0x34
    RESP_LIST_BEGIN = 0x20
    RESP_ITEM = 0x21
    RESP_LIST_END = 0x22
    RESP_LOAD_OK = 0x23
    RESP_CAPS = 0x24
    RESP_WARP_STATE = 0x25
    RESP_SESSION_OK = 0x26
    RESP_WARP_RESULT = 0x27
    RESP_LOCATION_BEGIN = 0x28
    RESP_LOCATION_ITEM = 0x29
    RESP_LOCATION_END = 0x2A
    RESP_PREVIEW_END = 0x2B
    RESP_ERROR = 0x2F

    FLAG_FOLDER = 1 << 0
    FLAG_SAMPLE = 1 << 1

    ERR_TARGET = 4
    ERR_BAD_COMMAND = 20
    ERR_ITEM_NOT_FOUND = 21
    ERR_NOT_SAMPLE = 22
    ERR_NO_FILE_PATH = 23
    ERR_NO_REPLACE_SAMPLE = 24
    ERR_REPLACE_FAILED = 25
    ERR_BROWSER = 26
    ERR_NO_NEIGHBOURS = 27
    ERR_HOTSWAP_TARGET = 28
    ERR_NO_SESSION = 29
    ERR_WARP = 30
    RESTORE_DELAY_TICKS = 2

    SIMILAR_PREV = 0
    SIMILAR_NEXT = 1
    SIMILAR_RANDOM = 2

    PAGE_SIZE = 32
    RANDOM_COUNT = 32
    RANDOM_VISIT_CAP = 3000
    REVERT_SETTLE_TICKS = 3

    CAP_REPLACE_SAMPLE = 1
    CAP_DB_PATH = 2
    CAP_WARP_AS = 4
    CAP_WARP_HALF = 8
    CAP_WARP_DOUBLE = 16
    CAP_GUESS_LENGTH = 32

    WARP_HALF = 0
    WARP_DOUBLE = 1
    WARP_AS = 2
    WARP_SUGGESTED = 3

    # Warp fields: id -> (Sample attribute, is_int). Values travel as value*100.
    WARP_FIELDS = {
        1: ('warping', True),
        2: ('warp_mode', True),
        10: ('beats_granulation_resolution', True),   # Beats: Preserve
        11: ('beats_transient_loop_mode', True),      # Beats: Transient Loop
        12: ('beats_transient_envelope', False),      # Beats: Envelope
        13: ('tones_grain_size', False),              # Tones: Grain
        14: ('texture_grain_size', False),            # Texture: Grain
        15: ('texture_flux', False),                  # Texture: Flux
        16: ('complex_pro_formants', False),          # Complex Pro: Formants
        17: ('complex_pro_envelope', False),          # Complex Pro: Envelope
    }
    # warp_mode -> mode-specific field ids (Simpler skips mode 5).
    WARP_MODE_FIELDS = {0: (10, 11, 12), 1: (13,), 2: (14, 15), 3: (), 4: (), 6: (16, 17)}
    MAX_ITEM_ID = 16383
    MAX_NAME_LENGTH = 60
    VERIFY_DELAY_TICKS = 3
    ORIGIN_VISIT_CAP = 512

    AUDIO_EXTENSIONS = ('.wav', '.wave', '.aif', '.aiff', '.aifc',
                        '.flac', '.mp3', '.ogg', '.m4a')

    ROOTS = (
        ("Samples", "samples"),
        ("Drums", "drums"),
        ("User Library", "user_library"),
        ("Packs", "packs"),
    )

    def __init__(self, script):
        self._s = script
        self._items = {}
        self._item_keys = {}
        self._next_item_id = 1
        self._live_db = None
        self._sessions = {}     # (track, pad) -> snapshot for revert
        self._browse_epoch = random.randint(1, 0x1FFFFF)
        self._browse_song = None
        self._browse_targets = {}  # only targets whose browser has been opened
        self._next_browse_target = 1
        self._file_preview = None

    def disconnect(self):
        self._stop_preview()

    # ------------------------------------------------------------
    # Entry
    # ------------------------------------------------------------

    def receive(self, midi_bytes):
        if len(midi_bytes) < 10:
            return

        command = midi_bytes[3] & 0x7F
        b3 = midi_bytes[4] & 0x7F
        b4 = midi_bytes[5] & 0x7F
        arg = (midi_bytes[6] & 0x7F) | ((midi_bytes[7] & 0x7F) << 7)
        session = midi_bytes[8] & 0x7F
        extras = [b & 0x7F for b in midi_bytes[9:-1]]

        self._s.log_message(
            "SampleLab: RX cmd=0x%02X b3=%d b4=%d arg=%d session=%d"
            % (command, b3, b4, arg, session)
        )

        def run():
            try:
                if command == self.CMD_CAPS:
                    self._send_caps(session, b3, b4)
                elif command == self.CMD_ROOTS:
                    self._send_roots(session)
                elif command == self.CMD_CHILDREN:
                    self._send_children(session, arg, b3)
                elif command == self.CMD_PREVIEW:
                    self._preview(session, arg)
                elif command == self.CMD_STOP_PREVIEW:
                    self._stop_preview()
                elif command == self.CMD_LOAD:
                    self._stop_preview()
                    self._load(session, b3, b4, arg)
                elif command == self.CMD_SIMILAR:
                    self._stop_preview()
                    self._similar(session, b3, b4, arg)
                elif command == self.CMD_SESSION_BEGIN:
                    self._stop_preview()
                    self._session_begin(session, b3, b4)
                elif command == self.CMD_REVERT:
                    self._stop_preview()
                    self._revert(session, b3, b4)
                elif command == self.CMD_RANDOM:
                    self._send_random(session, arg)
                elif command == self.CMD_WARP_STATE:
                    self._send_warp_state(session, b3, b4)
                elif command == self.CMD_WARP_SET:
                    self._warp_set(session, b3, b4, arg, self._u21(extras))
                elif command == self.CMD_WARP_ACTION:
                    self._warp_action(session, b3, b4, arg, self._u14(extras))
                elif command == self.CMD_BROWSER_OPEN:
                    self._open_browser(session, b3, b4, arg,
                                       self._u21(extras), self._u21(extras[3:]))
                else:
                    self._error(session, 0, 0, self.ERR_BAD_COMMAND,
                                "Unknown Sample Lab command")
            except Exception as e:
                self._s.log_message(
                    "SampleLab: cmd 0x%02X exception: %s" % (command, str(e)))
                self._error(session, b3, b4, self.ERR_BROWSER,
                            "Sample Lab exception")

        # Keep all browser / LOM work out of receive_midi().
        self._s.schedule_message(1, run)

    # ------------------------------------------------------------
    # Browse
    # ------------------------------------------------------------

    def _send_roots(self, session):
        self._send_list_edge(self.RESP_LIST_BEGIN, session, 0, 0, False)
        for item, fallback in self._browser_roots():
            self._send_item(session, self._register(item), item, fallback, self.FLAG_FOLDER)
        self._send_list_edge(self.RESP_LIST_END, session, 0, 0, False)

    def _browser_roots(self):
        browser = Live.Application.get_application().browser
        roots = [(getattr(browser, prop, None), name) for name, prop in self.ROOTS]
        roots.append((getattr(browser, 'current_project', None), 'Current Project'))
        roots.extend((item, '') for item in (getattr(browser, 'user_folders', ()) or ()))
        unique, seen = [], set()
        for item, fallback in roots:
            if item is None:
                continue
            item_id = self._register(item)
            if item_id not in seen:
                seen.add(item_id)
                unique.append((item, fallback))
        return unique

    def _open_browser(self, session, track_id, pad_index, parent_id, epoch, target):
        track, simpler, _, _ = self._s._resolve_simpler_lab_target(track_id, pad_index)
        song = self._s.song()
        if self._browse_song is not None and self._browse_song != song:
            self._browse_epoch = random.randint(1, 0x1FFFFF)
            self._browse_targets.clear()
            self._items.clear()
            self._item_keys.clear()
            self._next_item_id = 1
        self._browse_song = song

        key = (track_id, pad_index)
        previous = self._browse_targets.get(key)
        if previous is None or previous[:2] != (track, simpler):
            previous = (track, simpler, self._next_browse_target)
            self._next_browse_target += 1
            self._browse_targets[key] = previous
        token = previous[2]
        restored = (epoch == self._browse_epoch and target == token and
                    self._cached_folder_available(parent_id))
        path = []
        if not restored and simpler is not None:
            file_path = str(getattr(getattr(simpler, 'sample', None), 'file_path', '') or '')
            path = self._origin_folders(file_path)

        self._s._send_midi(tuple([0xF0, 0x7D, self.RESPONSE_TYPE,
            self.RESP_LOCATION_BEGIN, session & 0x7F, track_id & 0x7F, pad_index & 0x7F]
            + self._enc21(self._browse_epoch) + self._enc21(token)
            + [1 if restored else 0, 0xF7]))
        for item in path:
            item_id = self._register(item)
            self._s._send_midi(tuple([0xF0, 0x7D, self.RESPONSE_TYPE,
                self.RESP_LOCATION_ITEM, session & 0x7F, track_id & 0x7F, pad_index & 0x7F,
                item_id & 0x7F, (item_id >> 7) & 0x7F]
                + self._s._sanitize_label(self._name(item, ''), self.MAX_NAME_LENGTH)
                + [0xF7]))
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LOCATION_END,
                           session & 0x7F, track_id & 0x7F, pad_index & 0x7F, 0xF7))
        self._s.log_message('SampleLab: browser open track=%d pad=%d restored=%s depth=%d'
                            % (track_id, pad_index, restored, len(path)))

    def _cached_folder_available(self, parent_id):
        if parent_id == 0:
            return True
        item = self._items.get(parent_id)
        if item is None or not self._is_folder(item):
            return False
        if isinstance(item, _FilesystemItem):
            return os.path.isdir(item.file_path)
        import re
        if re.search(r'FileId_(\d+)', str(getattr(item, 'uri', ''))):
            return self._fileid_path(item, allow_folder=True) is not None
        try:
            return getattr(item, 'children', None) is not None
        except Exception:
            return False

    def _indexed_sample_ancestry(self, file_path):
        """Resolve one basename's candidates, not the entire browser database."""
        db = self._live_db_path()
        if not db or not file_path or not os.path.isfile(file_path):
            return []
        import subprocess
        name = os.path.basename(file_path).replace("'", "''")
        sql = ("WITH RECURSIVE p(candidate,id,parent,name,depth) AS ("
               " SELECT file_id,file_id,parent_id,name,0 FROM files WHERE name='%s'"
               " UNION ALL SELECT p.candidate,f.file_id,f.parent_id,f.name,p.depth+1"
               " FROM files f JOIN p ON f.file_id=p.parent WHERE p.depth<64)"
               " SELECT candidate,id,hex(name),depth FROM p ORDER BY candidate,depth DESC;") % name
        try:
            result = subprocess.run(['/usr/bin/sqlite3', '-readonly', '-separator', '\t', db, sql],
                                    capture_output=True, text=True, timeout=2)
            if result.returncode != 0:
                return []
            candidates = {}
            for line in result.stdout.splitlines():
                candidate, item_id, encoded_name, _ = line.split('\t')
                candidates.setdefault(candidate, []).append(
                    (int(item_id), bytes.fromhex(encoded_name).decode('utf-8')))
            for lineage in candidates.values():
                indexed = os.path.join(*(name for _, name in lineage))
                if os.path.realpath(indexed) == os.path.realpath(file_path):
                    return lineage
        except Exception as error:
            self._s.log_message('SampleLab: origin lookup failed: %s' % str(error))
        return []

    def _origin_folders(self, file_path):
        if not file_path or not os.path.isfile(file_path):
            return []
        native = self._native_origin_folders(file_path)
        if native:
            return native
        # Samples loaded by presets can live outside every indexed browser root.
        # Their actual parent folder remains browsable without indexing a library.
        folders = []
        directory = os.path.dirname(os.path.realpath(file_path))
        while True:
            folders.append(_FilesystemItem(directory, self.AUDIO_EXTENSIONS))
            parent = os.path.dirname(directory)
            if parent == directory:
                break
            directory = parent
        self._s.log_message('SampleLab: direct sample folder=%s' % folders[0].file_path)
        return list(reversed(folders))

    def _native_origin_folders(self, file_path):
        lineage = self._indexed_sample_ancestry(file_path)
        if len(lineage) < 2:
            return []
        import re
        ancestor_ids = {item_id for item_id, _ in lineage[:-1]}
        folder_id, folder_name = lineage[-2]
        sample_id = lineage[-1][0]
        names = {name.lower() for _, name in lineage[:-1]}
        # Real folder roots precede the broad, usually flattened Samples category.
        roots = self._browser_roots()
        broad_roots = {self._register(item) for item, fallback in roots if fallback in ('Samples', 'Drums')}
        roots.sort(key=lambda pair: pair[1] in ('Samples', 'Drums'))
        queue = [([item], item) for item, _ in roots]
        visited, seen = 0, set()
        while queue and visited < self.ORIGIN_VISIT_CAP:
            path, item = queue.pop(0)
            uri = str(getattr(item, 'uri', '') or '')
            identity = uri or str(id(item))
            if identity in seen:
                continue
            seen.add(identity)
            visited += 1
            match = re.search(r'FileId_(\d+)', uri)
            if match and int(match.group(1)) == folder_id:
                return path
            descendants = []
            try:
                children = getattr(item, 'children', ()) or ()
            except Exception:
                continue
            for child in children:
                match = re.search(r'FileId_(\d+)', str(getattr(child, 'uri', '') or ''))
                # Some native folders have virtual URIs. Confirm the loaded file's
                # exact identity among their direct children before accepting one.
                if (match and int(match.group(1)) == sample_id and
                        self._register(path[0]) not in broad_roots and
                        (self._name(item, '').lower() == folder_name.lower() or
                         (len(path) == 1 and self._name(item, '') == 'Current Project'))):
                    return path
                if not self._is_folder(child):
                    continue
                if ((match and int(match.group(1)) in ancestor_ids) or
                        (not match and self._name(child, '').lower() in names)):
                    descendants.append((path + [child], child))
            # Finish the promising real-folder branch before visiting broad categories.
            queue[0:0] = descendants
        return []

    def _send_children(self, session, parent_id, page):
        parent = self._items.get(parent_id)
        if parent is None:
            self._error(session, 0, 0, self.ERR_ITEM_NOT_FOUND,
                        "Browser item not found")
            return

        folders = []
        samples = []
        for child in list(getattr(parent, 'children', ()) or ()):
            flags = self._flags(child)
            if flags & self.FLAG_FOLDER:
                folders.append((child, flags))
            elif flags & self.FLAG_SAMPLE:
                samples.append((child, flags))

        folders.sort(key=lambda pair: self._name(pair[0], "").lower())
        visible = folders + samples

        start = page * self.PAGE_SIZE
        end = min(start + self.PAGE_SIZE, len(visible))
        has_more = end < len(visible)

        self._send_list_edge(self.RESP_LIST_BEGIN, session, parent_id, page, has_more)
        for child, flags in visible[start:end]:
            self._send_item(session, self._register(child), child, "", flags)
        self._send_list_edge(self.RESP_LIST_END, session, parent_id, page, has_more)

    def _preview(self, session, item_id):
        item = self._items.get(item_id)
        if item is None or not self._is_sample(item):
            self._error(session, 0, 0, self.ERR_NOT_SAMPLE, "Not a sample")
            return
        self._stop_preview()
        path = None
        if isinstance(item, _FilesystemItem):
            path = item.file_path
            # A direct folder can remain cached after the user adds it to Places.
            # Resolve its native item now so preview starts working without losing navigation.
            lineage = self._indexed_sample_ancestry(item.file_path)
            folders = self._native_origin_folders(item.file_path) if lineage else []
            native = None
            if folders:
                import re
                for child in getattr(folders[-1], 'children', ()) or ():
                    match = re.search(r'FileId_(\d+)', str(getattr(child, 'uri', '') or ''))
                    if match and int(match.group(1)) == lineage[-1][0]:
                        native = child
                        break
            if native is None:
                self._preview_file(session, item_id, path)
                return
            item = native
        try:
            Live.Application.get_application().browser.preview_item(item)
        except Exception as error:
            self._s.log_message('SampleLab: Live preview failed: %s' % str(error))
            path = path or self._fileid_path(item)
            if path:
                self._preview_file(session, item_id, path)
            else:
                self._preview_ended(session, item_id)
                self._error(session, 0, 0, self.ERR_BROWSER, 'Sample preview unavailable')

    def _preview_file(self, session, item_id, path):
        try:
            if not path or not os.path.isfile(path):
                raise IOError('Sample file is missing')
            process = subprocess.Popen(['/usr/bin/afplay', path],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except Exception as error:
            self._s.log_message('SampleLab: Mac preview start failed: %s' % str(error))
            self._preview_ended(session, item_id)
            self._error(session, 0, 0, self.ERR_BROWSER, 'Mac preview could not start')
            return
        self._file_preview = process
        self._s.log_message('SampleLab: Mac preview=%s' % path)

        def check_finished():
            if self._file_preview is not process:
                return
            result = process.poll()
            if result is None:
                self._s.schedule_message(3, check_finished)
                return
            self._file_preview = None
            _, detail = process.communicate()
            self._preview_ended(session, item_id)
            if result != 0:
                self._s.log_message('SampleLab: Mac preview exit=%d %s' %
                                    (result, (detail or b'').decode('utf-8', 'replace')[:200]))
                self._error(session, 0, 0, self.ERR_BROWSER, 'Mac preview could not play this file')

        self._s.schedule_message(1, check_finished)

    def _preview_ended(self, session, item_id):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_PREVIEW_END,
                           session & 0x7F, item_id & 0x7F, (item_id >> 7) & 0x7F, 0xF7))

    def _stop_preview(self):
        process = self._file_preview
        self._file_preview = None
        if process is not None:
            try:
                if process.poll() is None:
                    process.terminate()
                process.communicate(timeout=0.25)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate(timeout=0.25)
        try:
            Live.Application.get_application().browser.stop_preview()
        except Exception:
            pass

    # ------------------------------------------------------------
    # Load = replace_sample on the pad's existing Simpler. Nothing else.
    # ------------------------------------------------------------

    def _load(self, session, track_id, pad_index, item_id):
        item = self._items.get(item_id)
        if item is None:
            self._error(session, track_id, pad_index, self.ERR_ITEM_NOT_FOUND,
                        "Browser item not found")
            return
        if not self._is_sample(item):
            self._error(session, track_id, pad_index, self.ERR_NOT_SAMPLE,
                        "Not a sample")
            return

        track, simpler, info, target_error = \
            self._s._resolve_simpler_lab_target(track_id, pad_index)
        if simpler is None:
            self._error(session, track_id, pad_index, self.ERR_TARGET,
                        target_error or "Simpler unavailable")
            return

        path = self._fileid_path(item) if hasattr(simpler, 'replace_sample') else None
        if path:
            self._replace(session, track_id, pad_index, simpler, info,
                          path, self._name(item, ""))
            return

        if isinstance(item, _FilesystemItem):
            self._error(session, track_id, pad_index, self.ERR_NO_REPLACE_SAMPLE,
                        'Direct sample loading requires Live 12.4')
            return

        self._s.log_message("SampleLab: no DB path for uri=%s, using hot-swap"
                            % str(getattr(item, 'uri', '')))
        self._hotswap_load(session, track_id, pad_index, track, simpler, info, item)

    # ------------------------------------------------------------
    # Browser FileId -> real path, via Live's own browser database.
    # Live's Python has no _sqlite3, so use macOS's sqlite3 CLI (read-only).
    # ------------------------------------------------------------

    def _live_db_path(self):
        if self._live_db and os.path.exists(self._live_db):
            return self._live_db
        base = os.path.expanduser("~/Library/Application Support/Ableton/Live Database")
        try:
            candidates = [os.path.join(base, n) for n in os.listdir(base)
                          if n.startswith("Live-files-") and n.endswith(".db")]
        except Exception:
            return None
        if not candidates:
            return None
        self._live_db = max(candidates, key=os.path.getmtime)
        return self._live_db

    def _fileid_path(self, item, allow_folder=False):
        if isinstance(item, _FilesystemItem):
            valid = os.path.isdir(item.file_path) if allow_folder else os.path.isfile(item.file_path)
            return item.file_path if valid else None
        import re
        import subprocess
        m = re.search(r'FileId_(\d+)', str(getattr(item, 'uri', '') or ''))
        if not m:
            return None
        db = self._live_db_path()
        if not db:
            return None
        sql = ("WITH RECURSIVE p(id, parent, name, depth) AS ("
               " SELECT file_id, parent_id, name, 0 FROM files WHERE file_id = %d"
               " UNION ALL SELECT f.file_id, f.parent_id, f.name, p.depth + 1"
               " FROM files f JOIN p ON f.file_id = p.parent"
               " WHERE p.parent != 0 AND p.depth < 64)"
               " SELECT name FROM p ORDER BY depth DESC;") % int(m.group(1))
        try:
            out = subprocess.run(['/usr/bin/sqlite3', '-readonly', db, sql],
                                 capture_output=True, text=True, timeout=2)
        except Exception as e:
            self._s.log_message("SampleLab: DB lookup error: %s" % str(e))
            return None
        if out.returncode != 0:
            self._s.log_message("SampleLab: DB lookup rc=%d %s"
                                % (out.returncode, out.stderr.strip()[:200]))
            return None
        names = [n for n in out.stdout.split('\n') if n]
        if not names:
            return None
        path = os.path.join(*names)
        if not (os.path.isdir(path) if allow_folder else os.path.isfile(path)):
            self._s.log_message("SampleLab: DB path missing on disk: %s" % path)
            return None
        return path

    def _hotswap_load(self, session, track_id, pad_index, track, simpler, info, item):
        """Browser load via Live's hot-swap, aimed at the pad's own Simpler.
        Refuses unless the hot-swap target is exactly that Simpler, so the
        kit / chain can never be replaced. Live's UI state is restored after.

        Two phases: Live applies rack view changes (chain shown / selected)
        on the next tick, so the nested Simpler is only selected after that.
        """
        log = self._s.log_message
        app = Live.Application.get_application()
        browser = app.browser
        song = self._s.song()
        pad = info.get('pad') if info else None
        chain = info.get('chain') if info else None
        drum_rack = getattr(pad, 'canonical_parent', None) if pad is not None else None
        name = self._name(item, "")

        state = {
            'prev_track': None,
            'prev_suppress': getattr(self._s, '_suppress_selection', False),
            'prev_showing': None,
            'entered_browse': False,
            'loaded': False,
            'attempt': 0,
            'expanded': [],
        }

        def restore():
            try:
                if state['entered_browse'] and app.view.browse_mode:
                    app.view.toggle_browse()
            except Exception as e:
                log("SampleLab: HOTSWAP exit browse error: %s" % str(e))
            try:
                if drum_rack is not None and state['prev_showing'] is not None:
                    drum_rack.view.is_showing_chain_devices = state['prev_showing']
            except Exception:
                pass
            for rack, was_showing in reversed(state['expanded']):
                try:
                    rack.view.is_showing_chain_devices = was_showing
                except Exception:
                    pass
            try:
                if state['prev_track'] is not None:
                    song.view.selected_track = state['prev_track']
            except Exception:
                pass
            self._s._suppress_selection = state['prev_suppress']
            if state['loaded']:
                self._after_swap(session, track_id, pad_index, simpler, info, name)

        def phase2():
            try:
                state['attempt'] += 1
                song.view.select_device(simpler)
                log("SampleLab: HOTSWAP attempt=%d selected=%s chain_visible=%s"
                    % (state['attempt'],
                       self._describe(getattr(track.view, 'selected_device', None)),
                       str(app.view.is_view_visible('Detail/DeviceChain'))))
                try:
                    app.view.focus_view('Detail/DeviceChain')
                except Exception as e:
                    log("SampleLab: HOTSWAP focus error: %s" % str(e))

                if not app.view.browse_mode:
                    app.view.toggle_browse()
                    state['entered_browse'] = True

                target = browser.hotswap_target
                if target != simpler and state['attempt'] < 3:
                    # Rack view not settled yet: leave hot-swap, wait a tick, retry.
                    if state['entered_browse'] and app.view.browse_mode:
                        app.view.toggle_browse()
                        state['entered_browse'] = False
                    log("SampleLab: HOTSWAP retry %d target=%s"
                        % (state['attempt'], self._describe(target)))
                    self._s.schedule_message(1, phase2)
                    return

                if target != simpler:
                    log("SampleLab: HOTSWAP REFUSED track=%d pad=%d target=%s selected=%s"
                        % (track_id, pad_index, self._describe(target),
                           self._describe(getattr(track.view, 'selected_device', None))))
                    self._error(session, track_id, pad_index, self.ERR_HOTSWAP_TARGET,
                                "Hot-swap target is not this pad's Simpler")
                else:
                    browser.load_item(item)
                    state['loaded'] = True
                    log("SampleLab: HOTSWAP load track=%d pad=%d name='%s' attempt=%d"
                        % (track_id, pad_index, name, state['attempt']))
            except Exception as e:
                log("SampleLab: HOTSWAP load FAILED: %s" % str(e))
                self._error(session, track_id, pad_index, self.ERR_REPLACE_FAILED,
                            "Load failed")
            self._s.schedule_message(self.RESTORE_DELAY_TICKS, restore)

        # Phase 1: point Live at the track, rack, pad and chain.
        self._stop_preview()
        try:
            try:
                state['prev_track'] = song.view.selected_track
            except Exception:
                pass
            self._s._suppress_selection = True
            song.view.selected_track = track
            try:
                app.view.show_view('Detail/DeviceChain')
            except Exception as e:
                log("SampleLab: HOTSWAP show device chain error: %s" % str(e))
            if drum_rack is not None:
                song.view.select_device(drum_rack)
                if pad is not None:
                    drum_rack.view.selected_drum_pad = pad
                state['prev_showing'] = drum_rack.view.is_showing_chain_devices
                drum_rack.view.is_showing_chain_devices = True
                if chain is not None:
                    drum_rack.view.selected_chain = chain
            # Kits are often an Instrument Rack wrapping the Drum Rack: open
            # every enclosing rack down to the Simpler, or Live targets the
            # outer rack.
            state['expanded'] = self._open_racks_to(simpler, drum_rack)
            song.view.select_device(simpler)
            try:
                app.view.focus_view('Detail/DeviceChain')
            except Exception as e:
                log("SampleLab: HOTSWAP focus error: %s" % str(e))
        except Exception as e:
            log("SampleLab: HOTSWAP setup FAILED: %s" % str(e))
            self._error(session, track_id, pad_index, self.ERR_REPLACE_FAILED, "Load failed")
            self._s.schedule_message(1, restore)
            return

        self._s.schedule_message(1, phase2)

    def _open_racks_to(self, device, skip_rack=None):
        """Walk up from device to its track. For each enclosing rack, show its
        chain devices and select the chain that leads to device.
        Returns [(rack, was_showing)] for restore."""
        opened = []
        node = device
        for _ in range(16):
            parent = getattr(node, 'canonical_parent', None)
            if parent is None or hasattr(parent, 'clip_slots'):
                break                                   # reached the track
            if not hasattr(parent, 'devices'):
                node = parent                           # e.g. a DrumPad
                continue
            chain = parent
            rack = getattr(chain, 'canonical_parent', None)
            if rack is not None and hasattr(rack, 'note'):
                rack = getattr(rack, 'canonical_parent', None)   # DrumPad -> Drum Rack
            if rack is None:
                break
            if rack != skip_rack:
                try:
                    view = rack.view
                    opened.append((rack, view.is_showing_chain_devices))
                    view.is_showing_chain_devices = True
                    view.selected_chain = chain
                except Exception as e:
                    self._s.log_message("SampleLab: open rack error: %s" % str(e))
            node = rack
        self._s.log_message("SampleLab: opened racks: %s"
                            % ", ".join(self._describe(r) for r, _ in opened))
        return opened

    def _describe(self, obj):
        if obj is None:
            return "None"
        kind = getattr(obj, 'class_name', None) or type(obj).__name__
        return "%s '%s'" % (kind, getattr(obj, 'name', '?'))

    # ------------------------------------------------------------
    # Similar = neighbours in the current sample's folder
    # ------------------------------------------------------------

    def _similar(self, session, track_id, pad_index, direction):
        track, simpler, info, target_error = \
            self._s._resolve_simpler_lab_target(track_id, pad_index)
        if simpler is None:
            self._error(session, track_id, pad_index, self.ERR_TARGET,
                        target_error or "Simpler unavailable")
            return

        sample = getattr(simpler, 'sample', None)
        current = str(getattr(sample, 'file_path', '') or '') if sample is not None else ''
        if not current:
            self._error(session, track_id, pad_index, self.ERR_NO_FILE_PATH,
                        "Current sample has no file")
            return

        folder = os.path.dirname(current)
        try:
            names = sorted(
                [n for n in os.listdir(folder)
                 if not n.startswith('.')
                 and os.path.splitext(n)[1].lower() in self.AUDIO_EXTENSIONS],
                key=lambda n: n.lower()
            )
        except Exception as e:
            self._s.log_message("SampleLab: similar listdir failed '%s': %s"
                                % (folder, str(e)))
            names = []

        current_name = os.path.basename(current)
        others = [n for n in names if n != current_name]
        if not others:
            self._error(session, track_id, pad_index, self.ERR_NO_NEIGHBOURS,
                        "No other samples in this folder")
            return

        if direction == self.SIMILAR_RANDOM:
            chosen = random.choice(others)
        else:
            index = names.index(current_name) if current_name in names else -1
            if direction == self.SIMILAR_PREV:
                index = (index if index >= 0 else len(names)) - 1
            else:
                index = index + 1
            chosen = names[index % len(names)]

        self._s.log_message("SampleLab: similar dir=%d '%s' -> '%s'"
                            % (direction, current_name, chosen))
        self._replace(session, track_id, pad_index, simpler, info,
                      os.path.join(folder, chosen), chosen)

    # ------------------------------------------------------------
    # The one write: swap the sample inside the existing Simpler.
    # ------------------------------------------------------------

    def _replace(self, session, track_id, pad_index, simpler, info, path, name):
        self._stop_preview()

        try:
            simpler.replace_sample(path)
        except Exception as e:
            self._s.log_message("SampleLab: replace_sample FAILED '%s': %s"
                                % (path, str(e)))
            self._error(session, track_id, pad_index, self.ERR_REPLACE_FAILED,
                        "Replace failed")
            return

        self._s.log_message("SampleLab: replace_sample track=%d pad=%d path='%s'"
                            % (track_id, pad_index, path))
        self._after_swap(session, track_id, pad_index, simpler, info, name)

    def _after_swap(self, session, track_id, pad_index, simpler, info, name):
        """Shared tail for every swap: pad name, LOAD_OK, invariant check, waveform."""
        chain_before = info.get('chain') if info else None
        self._rename_pad(track_id, pad_index, info, name)
        self._send_load_ok(session, track_id, pad_index, name)

        def verify():
            _, simpler_after, info_after, _ = \
                self._s._resolve_simpler_lab_target(track_id, pad_index)
            chain_after = info_after.get('chain') if info_after else None
            same = (simpler_after == simpler and chain_after == chain_before)
            self._s.log_message(
                "SampleLab: INVARIANT %s track=%d pad=%d"
                % ("OK" if same else "BROKEN", track_id, pad_index)
            )
            # Use a fresh waveform push ID independent of the Lab session.
            self._s._send_simpler_waveform_response(
                track_id, pad_index,
                self._s._next_waveform_push_session(),
                self._s.WAVEFORM_BIN_COUNT)
            # New sample -> new warp state (mode, length, suggestion).
            self._send_warp_state(session, track_id, pad_index)

        self._s.schedule_message(self.VERIFY_DELAY_TICKS, verify)

    def _rename_pad(self, track_id, pad_index, info, sample_name):
        """Pad name follows the sample (file name without extension)."""
        self._set_pad_name(track_id, pad_index, info, os.path.splitext(sample_name)[0])

    def _set_pad_name(self, track_id, pad_index, info, pad_name):
        chain = info.get('chain') if info else None
        if chain is None:
            return
        try:
            chain.name = pad_name
        except Exception as e:
            self._s.log_message("SampleLab: chain rename failed: %s" % str(e))
            return
        link = self._s._links.get(track_id)
        if link is not None:
            link._drum_names[pad_index] = pad_name
        self._s._send_pad_name_sysex(track_id, pad_index + 1, pad_name)

    def _caps_flags(self, simpler):
        flags = 0
        if simpler is not None:
            if hasattr(simpler, 'replace_sample'):
                flags |= self.CAP_REPLACE_SAMPLE
            if hasattr(simpler, 'warp_as'):
                flags |= self.CAP_WARP_AS
            if hasattr(simpler, 'warp_half'):
                flags |= self.CAP_WARP_HALF
            if hasattr(simpler, 'warp_double'):
                flags |= self.CAP_WARP_DOUBLE
            if hasattr(simpler, 'guess_playback_length'):
                flags |= self.CAP_GUESS_LENGTH
        if os.path.exists('/usr/bin/sqlite3') and self._live_db_path():
            flags |= self.CAP_DB_PATH
        return flags

    def _send_caps(self, session, track_id, pad_index):
        app = Live.Application.get_application()
        _, simpler, _, _ = self._s._resolve_simpler_lab_target(track_id, pad_index)
        try:
            major = int(app.get_major_version())
            minor = int(app.get_minor_version())
            bugfix = int(app.get_bugfix_version())
        except Exception:
            major = minor = bugfix = 0
        flags = self._caps_flags(simpler)
        self._s.log_message("SampleLab: CAPS Live %d.%d.%d flags=0x%02X"
                            % (major, minor, bugfix, flags))
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_CAPS,
                            session & 0x7F, major & 0x7F, minor & 0x7F,
                            bugfix & 0x7F, flags & 0x7F, 0xF7))

    # ------------------------------------------------------------
    # Session + revert (sample + warp + start/end + Simpler params)
    # ------------------------------------------------------------

    def _session_begin(self, session, track_id, pad_index):
        _, simpler, info, err = self._s._resolve_simpler_lab_target(track_id, pad_index)
        can_revert = False
        if simpler is not None:
            snap = self._snapshot(simpler, info)
            if snap is not None:
                self._sessions[(track_id, pad_index)] = snap
                can_revert = bool(snap.get('path')) and hasattr(simpler, 'replace_sample')
        self._send_caps(session, track_id, pad_index)
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_SESSION_OK,
                            session & 0x7F, track_id & 0x7F, pad_index & 0x7F,
                            1 if can_revert else 0, 0xF7))
        if simpler is not None:
            self._send_warp_state(session, track_id, pad_index)

    def _snapshot(self, simpler, info):
        sample = getattr(simpler, 'sample', None)
        if sample is None:
            return None
        chain = info.get('chain') if info else None
        snap = {
            'path': str(getattr(sample, 'file_path', '') or ''),
            'chain_name': str(getattr(chain, 'name', '') or '') if chain is not None else '',
            'warp': {},
            'markers': None,
            'params': [],
        }
        for fid, (attr, _) in self.WARP_FIELDS.items():
            try:
                snap['warp'][attr] = getattr(sample, attr)
            except Exception:
                pass
        try:
            snap['markers'] = (sample.start_marker, sample.end_marker)
        except Exception:
            pass
        try:
            snap['params'] = [p.value for p in simpler.parameters]
        except Exception:
            pass
        return snap

    def _revert(self, session, track_id, pad_index):
        snap = self._sessions.get((track_id, pad_index))
        if snap is None:
            self._error(session, track_id, pad_index, self.ERR_NO_SESSION,
                        "Nothing to revert")
            return
        _, simpler, info, err = self._s._resolve_simpler_lab_target(track_id, pad_index)
        if simpler is None:
            self._error(session, track_id, pad_index, self.ERR_TARGET,
                        err or "Simpler unavailable")
            return
        if not hasattr(simpler, 'replace_sample'):
            self._error(session, track_id, pad_index, self.ERR_NO_REPLACE_SAMPLE,
                        "Revert needs Live 12.4 or later")
            return

        current = str(getattr(getattr(simpler, 'sample', None), 'file_path', '') or '')
        self._stop_preview()
        if snap['path'] and current != snap['path']:
            try:
                simpler.replace_sample(snap['path'])
            except Exception as e:
                self._s.log_message("SampleLab: revert replace FAILED: %s" % str(e))
                self._error(session, track_id, pad_index, self.ERR_REPLACE_FAILED,
                            "Revert failed")
                return

        def restore_rest():
            _, simpler2, info2, _ = self._s._resolve_simpler_lab_target(track_id, pad_index)
            if simpler2 is None:
                return
            sample = getattr(simpler2, 'sample', None)
            if sample is not None:
                # warping + mode first, then the mode's own fields
                for attr in ('warping', 'warp_mode'):
                    self._set_attr(sample, attr, snap['warp'].get(attr))
                for attr, value in snap['warp'].items():
                    if attr not in ('warping', 'warp_mode'):
                        self._set_attr(sample, attr, value)
                if snap['markers'] is not None:
                    self._set_attr(sample, 'start_marker', snap['markers'][0])
                    self._set_attr(sample, 'end_marker', snap['markers'][1])
            try:
                params = list(simpler2.parameters)
                if len(params) == len(snap['params']):
                    for param, value in zip(params, snap['params']):
                        if param.value != value:
                            try:
                                param.value = value
                            except Exception:
                                pass
            except Exception as e:
                self._s.log_message("SampleLab: revert params error: %s" % str(e))

            if snap['chain_name']:
                self._set_pad_name(track_id, pad_index, info2, snap['chain_name'])
            self._send_load_ok(session, track_id, pad_index,
                               os.path.basename(snap['path']))
            self._send_warp_state(session, track_id, pad_index)
            self._s._send_simpler_waveform_response(
                track_id, pad_index,
                self._s._next_waveform_push_session(),
                self._s.WAVEFORM_BIN_COUNT)
            self._s.log_message("SampleLab: REVERT track=%d pad=%d -> '%s'"
                                % (track_id, pad_index, snap['path']))

        self._s.schedule_message(self.REVERT_SETTLE_TICKS, restore_rest)

    def _set_attr(self, obj, attr, value):
        if value is None:
            return
        try:
            if getattr(obj, attr) != value:
                setattr(obj, attr, value)
        except Exception as e:
            self._s.log_message("SampleLab: set %s error: %s" % (attr, str(e)))

    # ------------------------------------------------------------
    # Random: RANDOM_COUNT samples from anywhere below a folder
    # ------------------------------------------------------------

    def _send_random(self, session, parent_id):
        parent = self._items.get(parent_id)
        if parent is None:
            self._error(session, 0, 0, self.ERR_ITEM_NOT_FOUND, "Browser item not found")
            return
        found = []
        folders = [(child, self.FLAG_FOLDER)
                   for child in list(getattr(parent, 'children', ()) or ())
                   if self._is_folder(child) and not self._is_sample(child)]
        folders.sort(key=lambda pair: self._name(pair[0], '').lower())
        queue = [parent]
        visits = 0
        while queue and visits < self.RANDOM_VISIT_CAP:
            node = queue.pop(0)
            for child in list(getattr(node, 'children', ()) or ()):
                visits += 1
                if self._is_sample(child):
                    found.append(child)
                elif self._is_folder(child):
                    queue.append(child)
                if visits >= self.RANDOM_VISIT_CAP:
                    break
        picks = random.sample(found, min(self.RANDOM_COUNT, len(found)))
        self._s.log_message("SampleLab: random parent=%d found=%d visits=%d"
                            % (parent_id, len(found), visits))
        self._send_list_edge(self.RESP_LIST_BEGIN, session, parent_id, 0, False)
        for child, flags in folders:
            self._send_item(session, self._register(child), child, '', flags)
        for child in picks:
            self._send_item(session, self._register(child), child, "", self.FLAG_SAMPLE)
        self._send_list_edge(self.RESP_LIST_END, session, parent_id, 0, False)

    # ------------------------------------------------------------
    # Warp (Sample-level settings + Simpler stretch actions, direct LOM)
    # ------------------------------------------------------------

    def _send_warp_state(self, session, track_id, pad_index):
        _, simpler, _, err = self._s._resolve_simpler_lab_target(track_id, pad_index)
        sample = getattr(simpler, 'sample', None) if simpler is not None else None
        if sample is None:
            self._error(session, track_id, pad_index, self.ERR_WARP, err or "No sample")
            return

        warping = bool(self._get(sample, 'warping', False))
        mode = int(self._get(sample, 'warp_mode', 0))
        can = 0
        if self._get(simpler, 'can_warp_as', False):
            can |= 1
        if self._get(simpler, 'can_warp_half', False):
            can |= 2
        if self._get(simpler, 'can_warp_double', False):
            can |= 4

        beats, seconds = self._region_length(sample)
        suggested = self._suggested_beats(simpler)

        fields = []
        for fid in self.WARP_MODE_FIELDS.get(mode, ()):
            attr = self.WARP_FIELDS[fid][0]
            value = self._get(sample, attr, None)
            if value is not None:
                fields.append((fid, value))

        msg = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_WARP_STATE,
               session & 0x7F, track_id & 0x7F, pad_index & 0x7F,
               1 if warping else 0, mode & 0x7F, can & 0x7F]
        msg.extend(self._enc21(beats * 100.0))
        msg.extend(self._enc21(seconds * 100.0))
        msg.extend(self._enc14(suggested))
        msg.append(len(fields) & 0x7F)
        for fid, value in fields:
            msg.append(fid & 0x7F)
            msg.extend(self._enc21(float(value) * 100.0))
        msg.append(0xF7)
        self._s._send_midi(tuple(msg))

    def _send_warp_result(self, session, track_id, pad_index, requested, simpler):
        sample = getattr(simpler, 'sample', None)
        beats = self._region_length(sample)[0] if sample is not None else 0.0
        msg = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_WARP_RESULT,
               session & 0x7F, track_id & 0x7F, pad_index & 0x7F]
        msg.extend(self._enc14(requested))
        msg.extend(self._enc21(beats * 100.0))
        msg.append(0xF7)
        self._s._send_midi(tuple(msg))

    def _region_length(self, sample):
        """(beats, seconds) of the Start..End region as it currently plays."""
        try:
            start, end = sample.start_marker, sample.end_marker
        except Exception:
            return 0.0, 0.0
        beats = 0.0
        seconds = 0.0
        if self._get(sample, 'warping', False):
            try:
                beats = max(0.0, sample.sample_to_beat_time(end) - sample.sample_to_beat_time(start))
                seconds = beats * 60.0 / float(self._s.song().tempo)
            except Exception:
                pass
        else:
            try:
                seconds = max(0.0, float(end - start) / float(sample.sample_rate))
            except Exception:
                pass
        return beats, seconds

    def _suggested_beats(self, simpler):
        """Nearest power-of-two beat count to Live's own length estimate.
        UNVERIFIED against Live's 'Warp As' label; logged for comparison."""
        try:
            guess = float(simpler.guess_playback_length())
        except Exception:
            return 0
        if guess <= 0:
            return 0
        n = 1
        while n * 2 <= guess * 1.5:     # round to nearest power of two
            n *= 2
        return n

    def _warp_set(self, session, track_id, pad_index, field, value100):
        spec = self.WARP_FIELDS.get(field)
        _, simpler, _, err = self._s._resolve_simpler_lab_target(track_id, pad_index)
        sample = getattr(simpler, 'sample', None) if simpler is not None else None
        if spec is None or sample is None:
            self._error(session, track_id, pad_index, self.ERR_WARP, err or "Bad warp field")
            return
        attr, is_int = spec
        value = value100 / 100.0
        if attr == 'warping':
            value = bool(int(round(value)))
        elif is_int:
            value = int(round(value))
        try:
            setattr(sample, attr, value)
        except Exception as e:
            self._s.log_message("SampleLab: warp set %s=%s FAILED: %s" % (attr, value, str(e)))
            self._error(session, track_id, pad_index, self.ERR_WARP, "Warp change failed")
            return
        self._s.schedule_message(1, lambda: self._send_warp_state(session, track_id, pad_index))

    def _warp_action(self, session, track_id, pad_index, action, beats):
        _, simpler, _, err = self._s._resolve_simpler_lab_target(track_id, pad_index)
        if simpler is None:
            self._error(session, track_id, pad_index, self.ERR_TARGET, err or "Simpler unavailable")
            return
        try:
            if action == self.WARP_HALF:
                simpler.warp_half()
            elif action == self.WARP_DOUBLE:
                simpler.warp_double()
            elif action == self.WARP_AS:
                n = max(1, int(beats))
                simpler.warp_as(n)
                self._send_warp_result(session, track_id, pad_index, n, simpler)
            elif action == self.WARP_SUGGESTED:
                n = self._suggested_beats(simpler)
                self._s.log_message("SampleLab: warp suggested guess=%s -> %d"
                                    % (str(self._get(simpler, 'guess_playback_length', None)), n))
                if n <= 0:
                    raise RuntimeError("no suggestion")
                simpler.warp_as(n)
            else:
                raise RuntimeError("unknown action %d" % action)
        except Exception as e:
            self._s.log_message("SampleLab: warp action %d FAILED: %s" % (action, str(e)))
            self._error(session, track_id, pad_index, self.ERR_WARP, "Warp action unavailable")
            return
        self._s.schedule_message(1, lambda: self._send_warp_state(session, track_id, pad_index))

    # ------------------------------------------------------------
    # Small helpers
    # ------------------------------------------------------------

    def _get(self, obj, attr, default):
        try:
            value = getattr(obj, attr)
            return value() if callable(value) and attr == 'guess_playback_length' else value
        except Exception:
            return default

    def _u14(self, extras):
        if len(extras) < 2:
            return 0
        return extras[0] | (extras[1] << 7)

    def _u21(self, extras):
        if len(extras) < 3:
            return 0
        return extras[0] | (extras[1] << 7) | (extras[2] << 14)

    def _enc14(self, value):
        v = max(0, min(0x3FFF, int(round(value))))
        return [v & 0x7F, (v >> 7) & 0x7F]

    def _enc21(self, value):
        v = max(0, min(0x1FFFFF, int(round(value))))
        return [v & 0x7F, (v >> 7) & 0x7F, (v >> 14) & 0x7F]

    # ------------------------------------------------------------
    # Item helpers
    # ------------------------------------------------------------

    def _register(self, item):
        key = None
        try:
            uri = getattr(item, 'uri', None)
            if uri:
                key = "uri:" + str(uri)
        except Exception:
            pass
        if key is None:
            key = "obj:" + str(id(item))

        existing = self._item_keys.get(key)
        if existing is not None:
            self._items[existing] = item
            return existing

        if self._next_item_id > self.MAX_ITEM_ID:
            raise RuntimeError("Sample Lab item registry full")

        item_id = self._next_item_id
        self._next_item_id += 1
        self._items[item_id] = item
        self._item_keys[key] = item_id
        return item_id

    def _name(self, item, fallback):
        try:
            name = str(item.name)
            if name:
                return name
        except Exception:
            pass
        return fallback

    def _is_sample(self, item):
        try:
            if not bool(getattr(item, 'is_loadable', False)):
                return False
            if bool(getattr(item, 'is_device', False)):
                return False
        except Exception:
            return False
        ext = os.path.splitext(self._name(item, ""))[1].lower()
        return ext in self.AUDIO_EXTENSIONS

    def _is_folder(self, item):
        try:
            if bool(getattr(item, 'is_device', False)):
                return False
            if bool(getattr(item, 'is_folder', False)):
                return True
            children = getattr(item, 'children', None)
            return children is not None and len(children) > 0
        except Exception:
            return False

    def _flags(self, item):
        if self._is_sample(item):
            return self.FLAG_SAMPLE
        if self._is_folder(item):
            return self.FLAG_FOLDER
        return 0

    # ------------------------------------------------------------
    # Senders
    # ------------------------------------------------------------

    def _send_list_edge(self, resp, session, parent_id, page, has_more):
        self._s._send_midi((
            0xF0, 0x7D, self.RESPONSE_TYPE, resp,
            session & 0x7F,
            parent_id & 0x7F, (parent_id >> 7) & 0x7F,
            page & 0x7F,
            1 if has_more else 0,
            0xF7
        ))

    def _send_item(self, session, item_id, item, fallback, flags):
        message = [
            0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_ITEM,
            session & 0x7F,
            item_id & 0x7F, (item_id >> 7) & 0x7F,
            flags & 0x7F
        ]
        message.extend(self._s._sanitize_label(self._name(item, fallback),
                                               self.MAX_NAME_LENGTH))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _send_load_ok(self, session, track_id, pad_index, name):
        message = [
            0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LOAD_OK,
            session & 0x7F, track_id & 0x7F, pad_index & 0x7F
        ]
        message.extend(self._s._sanitize_label(name, self.MAX_NAME_LENGTH))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _error(self, session, track_id, pad_index, code, text):
        message = [
            0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_ERROR,
            session & 0x7F, track_id & 0x7F, pad_index & 0x7F, code & 0x7F
        ]
        message.extend(self._s._sanitize_label(str(text), self.MAX_NAME_LENGTH))
        message.append(0xF7)
        self._s._send_midi(tuple(message))
