# PrismScript v2 — Bridge-aware, Prism-driven track control
#
# Architecture:
#   - Nothing happens to any track until Prism sends TRACK_MODE_SET (0x21) mode=1.
#   - Each active track is owned by a TrackLink object (all params, listeners,
#     and echo-suppression state live inside it; activate/deactivate are symmetric).
#   - BridgeManager handles Prism Bridge (M4L) detection, lazy insertion via the
#     browser API, and writing the __PrismBridge__ marker/state parameter.
#   - Bridge links use live.remote~ for macros. Script-only links write CC 1-16
#     themselves, including p-locks/LFOs (without Max's audio-rate smoothing).
#   - Mixer / sends / drum pads / names / colors / labels: script, active tracks only.
#   - Handshake, transport sync, SysEx formats: unchanged from legacy.
#
# Protocol additions:
#   0x21 TRACK_MODE_SET   (Prism -> script): F0 7D 21 [track_id] [mode] F7
#   0x22 TRACK_MODE_STATUS (script -> Prism): F0 7D 22 [track_id] [mode] [status] F7
#     status: 0=ok  1=no bridge  2=out of range  3=not a MIDI track
#             4=insert/activation failed  5=track moved/deleted

#
# State model per track:
#   Unlinked — no bridge device, or device switched off, or Prism never sent mode 1.
#   Linked, macros engaged — __PrismMacros__ toggle ON (default). Full control.
#   Linked, macros released — __PrismMacros__ toggle OFF. Mixer/sends/drums still
#     flow; macro bindings released so user can dial in Ableton. Re-engage publishes
#     current macro values to Prism so nothing resets.
#
# Kill triggers: device deleted, device switched off, Prism mode 0, track moved/
#   deleted, connection lost, __PrismBridge__ manually zeroed (backstop).
#
# On-select enforcement:
#   Linked track:   MIDI From -> All Ins, Channel -> linked Ch, Monitor -> In
#   Unlinked track: MIDI From -> Computer Keyboard (only if currently All Ins),
#                   Channel & Monitor untouched (only set at the unlink moment)

from __future__ import absolute_import, print_function, unicode_literals

import Live

from _Framework.ControlSurface import ControlSurface
from .PrismBrowserConnector import PrismBrowserConnector
from .PrismTrackConnector import PrismTrackConnector
from .PrismSampleLabConnector import PrismSampleLabConnector



def create_instance(c_instance):
    """Entry point called by Ableton Live."""
    return PrismScript(c_instance)


class BridgeUnavailable(RuntimeError):
    """Bridge activation failed; unrelated refresh errors must not latch fallback."""


# ============================================================
# BridgeManager — everything about the Prism Bridge M4L device
# ============================================================

class BridgeManager(object):
    MARKER_PARAM_NAME = "__PrismBridge__"
    MACROS_PARAM_NAME = "__PrismMacros__"
    MACRO_HOLD_PARAM_NAME = "__PrismMacroHold__"
    HOLD_TOKEN_PARAM_NAME = "__PrismHoldToken__"
    HOLD_ACK_PARAM_NAME = "__PrismHoldAck__"
    TRACK_ID_PARAM_NAME = "__PrismTrack__"   # stores prism_track_id + 1; 0 = unassigned
    BROWSER_ITEM_NAMES = ("Prism Bridge", "Prism Bridge.amxd")
    MAX_BROWSER_DEPTH = 6

    def __init__(self, script):
        self._s = script
        self._cached_item = None  # browser item, found once per session

    # ---- param finders ----

    def _find_param(self, track, param_name):
        """Return the named DeviceParameter on this track, or None.

        Walks every device's parameters looking for the name.
        (When DEBUG is on, logs every device's class_name and every param
        name so detection failures can be pinpointed from Log.txt.)
        """
        if track is None or not hasattr(track, 'devices'):
            return None
        debug = self._s.DEBUG
        try:
            for device in track.devices:
                cname = "?"
                try:
                    cname = device.class_name
                except Exception:
                    pass
                if debug:
                    self._s.log_message(
                        "PrismScript: [detect] device '%s' class_name='%s'"
                        % (getattr(device, 'name', '?'), cname))
                # Bridge params only live on Max devices; skip the rest cheaply.
                if 'MxDevice' not in str(cname):
                    continue
                    
                try:
                    for p in device.parameters:
                        if debug:
                            self._s.log_message(
                                "PrismScript: [detect]    param '%s'" % p.name)
                        if p.name == param_name:
                            return p
                except Exception as e:
                    if debug:
                        self._s.log_message(
                            "PrismScript: [detect]    param walk error: %s" % str(e))
        except Exception:
            pass
        return None

    def find_bridge_param(self, track):
        return self._find_param(track, self.MARKER_PARAM_NAME)

    def find_bridge_device(self, track):
        if track is None or not hasattr(track, 'devices'):
            return None

        try:
            for device in track.devices:
                try:
                    if 'MxDevice' not in str(getattr(device, 'class_name', '')):
                        continue
                    for p in device.parameters:
                        if p.name == self.MARKER_PARAM_NAME:
                            return device
                except Exception:
                    pass
        except Exception:
            pass

        return None

    def script_only_bridge_devices(self, track):
        """Also recognize an insertion whose marker parameters are not ready yet."""
        found = []
        try:
            devices = list(track.devices)
        except Exception:
            return found
        for device in devices:
            try:
                if 'MxDevice' not in str(getattr(device, 'class_name', '')):
                    continue
                named = str(getattr(device, 'name', '')) in self.BROWSER_ITEM_NAMES
                if named or any(p.name == self.MARKER_PARAM_NAME for p in device.parameters):
                    found.append(device)
            except Exception:
                pass
        return found

    def set_bridge_project_name(self, track, project_name):
        clean = str(project_name or "").strip()

        if not clean:
            return False

        device = self.find_bridge_device(track)

        if device is None:
            self._s.log_message(
                "PrismScript: PROJECT NAME bridge device NOT FOUND"
            )
            return False

        display_name = "File: " + clean

        try:
            before = str(getattr(device, "name", ""))

            self._s.log_message(
                "PrismScript: PROJECT NAME before='%s' target='%s'"
                % (before, display_name)
            )

            device.name = display_name

            after = str(getattr(device, "name", ""))

            self._s.log_message(
                "PrismScript: PROJECT NAME after='%s'"
                % after
            )

            return after == display_name

        except Exception as e:
            self._s.log_message(
                "PrismScript: PROJECT NAME exception: %s"
                % str(e)
            )
            return False

    def find_macros_param(self, track):
        return self._find_param(track, self.MACROS_PARAM_NAME)
        
    def find_macro_hold_param(self, track):
        return self._find_param(track, self.MACRO_HOLD_PARAM_NAME)

    def find_hold_token_param(self, track):
        return self._find_param(track, self.HOLD_TOKEN_PARAM_NAME)

    def find_hold_ack_param(self, track):
        return self._find_param(track, self.HOLD_ACK_PARAM_NAME)

    def set_macro_hold(self, track, active):
        param = self.find_macro_hold_param(track)
        if param is None:
            return False
        try:
            param.value = 1.0 if active else 0.0
            self._s.log_message(
                "PrismScript: macro hold -> %d track '%s'"
                % (1 if active else 0, getattr(track, 'name', '?'))
            )
            return True
        except Exception as e:
            self._s.log_message("PrismScript: macro hold write failed: %s" % str(e))
            return False

    def set_hold_token(self, track, generation):
        param = self.find_hold_token_param(track)
        if param is None:
            self._s.log_message("PrismScript: hold token param unavailable")
            return False

        generation = int(generation) & 0x3FFF
        if generation == 0:
            self._s.log_message("PrismScript: refusing invalid hold generation 0")
            return False

        try:
            param.value = float(generation)
            self._s.log_message(
                "PrismScript: hold token -> %d track '%s'"
                % (generation, getattr(track, 'name', '?'))
            )
            return True
        except Exception as e:
            self._s.log_message(
                "PrismScript: hold token write failed: %s" % str(e)
            )
            return False

    def get_hold_ack(self, track):
        param = self.find_hold_ack_param(track)
        if param is None:
            return None
        try:
            return int(round(param.value)) & 0x3FFF
        except Exception:
            return None

    def find_track_id_param(self, track):
        return self._find_param(track, self.TRACK_ID_PARAM_NAME)

    def get_prism_track_id(self, track):
        """Prism track (0-15) saved on this bridge, or None if unassigned/missing."""
        param = self.find_track_id_param(track)
        if param is None:
            return None
        try:
            value = int(round(param.value))
        except Exception:
            return None
        return value - 1 if 1 <= value <= 16 else None

    def set_prism_track_id(self, track, track_id):
        """Persist Prism ownership on the bridge (saved with the Set).
        track_id=None clears it. Writes only on change (avoids undo spam)."""
        param = self.find_track_id_param(track)
        if param is None:
            return False
        value = 0 if track_id is None else int(track_id) + 1
        try:
            if int(round(param.value)) != value:
                param.value = float(value)
            return True
        except Exception as e:
            self._s.log_message("PrismScript: track id write failed: %s" % str(e))
            return False

    def get_device_on_param(self, track):
        """The bridge device's 'Device On' parameter (parameters[0]), or None."""
        marker = self.find_bridge_param(track)
        if marker is None:
            return None
        try:
            device = marker.canonical_parent
            params = list(device.parameters)
            if params:
                return params[0]
        except Exception:
            pass
        return None

    def ensure_device_on(self, track):
        """Switch the bridge device on if off. True if on (or turned on)."""
        p = self.get_device_on_param(track)
        if p is None:
            return False
        try:
            if p.value < 0.5:
                p.value = 1.0
                self._s.log_message("PrismScript: switched bridge device ON")
            return True
        except Exception as e:
            self._s.log_message("PrismScript: device-on write failed: %s" % str(e))
            return False

    # ---- state write ----

    def set_bridge_active(self, track, active):
        """Write 1/0 to the bridge's marker param. Returns True on success."""
        param = self.find_bridge_param(track)
        if param is None:
            return False
        try:
            param.value = 1.0 if active else 0.0
            return True
        except Exception as e:
            self._s.log_message("PrismScript: failed writing bridge state: %s" % str(e))
            return False

    # ---- lazy insertion ----

    def insert_bridge(self, track):
        """Insert the Prism Bridge device onto `track` via the browser API.

        Attempts to place it at the very start of the device chain
        (DeviceInsertMode.selected_left on the first device); falls back to
        the default insert position if that API is unavailable.

        Returns True if load_item was issued without raising. The device may
        not be registered in the LOM immediately — caller must verify with
        find_bridge_param() on a scheduled retry.
        """
        item = self._find_browser_item()
        if item is None:
            self._s.log_message(
                "PrismScript: 'Prism Bridge' not found in browser (user library)")
            return False

        s = self._s
        s._suppress_selection = True
        prev_selected = None
        try:
            prev_selected = s.song().view.selected_track
        except Exception:
            pass

        try:
            s.song().view.selected_track = track

            # Best-effort: insert at the start of the chain.
            try:
                devices = list(track.devices)
                if devices:
                    s.song().view.select_device(devices[0])
                    track.view.device_insert_mode = \
                        Live.Track.DeviceInsertMode.selected_left
            except Exception as e:
                s.log_message(
                    "PrismScript: insert-at-start unavailable (%s); "
                    "using default position" % str(e))

            Live.Application.get_application().browser.load_item(item)
            s.log_message("PrismScript: bridge insert issued on track '%s'"
                          % track.name)
            return True

        except Exception as e:
            s.log_message("PrismScript: bridge insert FAILED: %s" % str(e))
            return False

        finally:
            try:
                track.view.device_insert_mode = Live.Track.DeviceInsertMode.default
            except Exception:
                pass
            # Leave the target selected: bridges are only inserted on a connect
            # you made, and Ableton should follow it. Restoring the previous
            # selection fired a late "you clicked track X" that pulled Prism away.
            s._suppress_selection = False

    def _find_browser_item(self):
        """Locate the Prism Bridge .amxd in the browser. Cached per session."""
        if self._cached_item is not None:
            return self._cached_item
        try:
            browser = Live.Application.get_application().browser
            roots = []
            if hasattr(browser, 'user_library'):
                roots.append(browser.user_library)
            if hasattr(browser, 'max_for_live'):
                roots.append(browser.max_for_live)
            for root in roots:
                item = self._walk(root, 0)
                if item is not None:
                    self._cached_item = item
                    self._s.log_message(
                        "PrismScript: found 'Prism Bridge' in browser")
                    return item
        except Exception as e:
            self._s.log_message("PrismScript: browser walk error: %s" % str(e))
        return None

    def _walk(self, item, depth):
        if depth > self.MAX_BROWSER_DEPTH:
            return None
        try:
            name = str(item.name)
            if name in self.BROWSER_ITEM_NAMES and getattr(item, 'is_loadable', False):
                return item
            for child in item.children:
                found = self._walk(child, depth + 1)
                if found is not None:
                    return found
        except Exception:
            pass
        return None


# ============================================================
# TrackLink — one per ACTIVE track. Owns all per-track state.
# ============================================================

class TrackLink(object):

    def __init__(self, script, track_id, track, script_only=False):
        self._s = script
        self.track_id = track_id
        self.track = track
        self.script_only = bool(script_only)

        # Resolved parameters
        self._macro_params = [None] * 16
        self._mixer = {'VOL': None, 'PAN': None}
        self._sends = {'A': None, 'B': None}
        self._drum_params = {}
        self._drum_names = {}

        self._drum_pad_objects = [None] * 16
        self._pad_chains = [None] * 16
        self._simpler_devices = [None] * 16
        self._simpler_mode_listeners = {}
        self._simpler_targets = [[None] * 24 for _ in range(16)]
        self._simpler_control_listeners = []
        self._simpler_control_gen = 0
        self._simpler_pad_gen = [0] * 16
        self._simpler_meta_gen = [0] * 16
        self._simpler_pending_meta = {}
        self._simpler_address_low = None
        self._simpler_last_received = {}
        self._simpler_last_sent = {}
        self._simpler_pending_feedback = {}
        self._script_simpler_write_active = False
        self._script_simpler_modes = {}
        self._pad_chain_listeners = {}
        self._drum_pad_chain_listeners = {}

        self._is_drum = False

        # Script-only macro listeners publish manual Live edits and suppress
        # Prism-driven writes. Bridge links keep device-owned live feedback.
        self._macro_listeners = {}                # {index 0-15: fn}
        self._mixer_listeners = {}                # {'VOL'/'PAN': fn}
        self._send_listeners = {}                 # {'A'/'B': fn}
        self._drum_listeners = {}                 # {pad_index: {'VOL'/'PAN': fn}}
        self._devices_listener = None
        self._instrument_listeners = []           # [(kind, device, fn)]
        self._bridge_param = None                 # __PrismBridge__ param (kill switch)
        self._bridge_param_listener = None

        # Macros engagement toggle (__PrismMacros__, user-owned)
        self._macros_param = None
        self._macros_param_listener = None
        self._macros_engaged = None

        # Device on/off (second kill switch)
        self._device_on_param = None
        self._device_on_listener = None

        # Echo suppression, local to this link
        self._last_sent = {}                      # {cc: value}
        self._last_received = {}                  # {cc: value}
        self._script_macro_write_active = False
        self._script_bridge_listeners = []        # [(object, kind, callback)]
        self._script_bridge_check_pending = False

        self._authoritative_refresh_gen = 0
        self._simpler_feedback_gen = 0
        self._instrument_device = None
        self._macro_handoff_active = False
        self._hold_ack_param = None
        self._hold_ack_listener = None
        self._release_generation = 0
        self._waiting_for_release_ack = False
        self._waiting_for_snapshot_adopted = False
        self._snapshot_adopt_generation = 0 
        self._release_ack_callback = None

        # Preset/instrument convergence transaction.
        # Separate from _macro_handoff_active because the state refresh still matters
        # even when user-owned __PrismMacros__ is released.
        self._preset_handoff_active = False
        self._handoff_gen = 0
        self._handoff_txn = 0
        self._handoff_baseline_signature = None
        self._handoff_last_signature = None
        self._handoff_stable_reads = 0
        self._handoff_probe_pending = False
        self._handoff_activity_seen = False

        self._detached = False
        self._reasserting_connection = False

    # ---------------- lifecycle ----------------

    def activate(self, on_ready=None):
        s = self._s
        s._set_midi_from(self.track, s.MIDI_FROM_ALL_INS)
        s._auto_set_track_input_channel(self.track, self.track_id)
        s._sweep_unlinked_midi_from(exclude_track=self.track)

        if self.script_only:
            self._disable_script_only_bridges()
            s.request_rebuild_midi_map()
        else:
            if not s._bridge.ensure_device_on(self.track):
                raise BridgeUnavailable("could not verify bridge device state")

            # Internal preset handoff must never survive a saved/reloaded Set.
            s._bridge.set_macro_hold(self.track, False)
            s._bridge.set_prism_track_id(self.track, self.track_id)

            if not s._bridge.set_bridge_active(self.track, True):
                raise BridgeUnavailable("could not write bridge state param")

            param = s._bridge.find_bridge_param(self.track)
            if param is not None:
                self._attach_bridge_param_listener(param)

            self._attach_macros_listener()
            self._attach_hold_ack_listener()
            self._attach_device_on_listener()

        if s.ARM_ON_ACTIVATE:
            try:
                if getattr(self.track, 'can_be_armed', False):
                    self.track.arm = True
            except Exception as e:
                s.log_message("PrismScript: arm failed on track %d: %s"
                              % (self.track_id, str(e)))

        self._set_monitoring_in()
        self._resolve_all()
        self._attach_devices_listener()

        # Push absolutely everything, including waveforms.
        self.send_authoritative_refresh(
            resolve=False,
            on_ready=on_ready
        )

        s.log_message("PrismScript: link ACTIVE on track %d ('%s')"
                      % (self.track_id, self.track.name))

    def reassert_connection(self, on_ready=None):
        """Force the existing Prism<->Live connection through a real Max release/reacquire cycle, then publish authoritative Live state again."""
        if self._detached:
            return False
        s = self._s
        s._set_midi_from(self.track, s.MIDI_FROM_ALL_INS)
        s._auto_set_track_input_channel(self.track, self.track_id)
        s._sweep_unlinked_midi_from(exclude_track=self.track)
        self._set_monitoring_in()
        if self.script_only:
            def refresh():
                if self._detached:
                    return
                self._disable_script_only_bridges()
                self._resolve_all()
                self.send_authoritative_refresh(resolve=False, on_ready=on_ready)

            s.schedule_message(1, refresh)
            return True

        self._reasserting_connection = True
        try:
            if not s._bridge.ensure_device_on(self.track):
                raise RuntimeError("bridge device unavailable")
            s._bridge.set_macro_hold(self.track, False)
            s._bridge.set_prism_track_id(self.track, self.track_id)
            if not s._bridge.set_bridge_active(self.track, False):
                raise RuntimeError("could not release bridge")
        except Exception as e:
            self._reasserting_connection = False
            s.log_message("PrismScript: connection reassert release failed track %d: %s" % (self.track_id, str(e)))
            return False

        def reacquire():
            if self._detached:
                self._reasserting_connection = False
                return
            try:
                if not s._bridge.ensure_device_on(self.track):
                    raise RuntimeError("bridge device unavailable")
                if not s._bridge.set_bridge_active(self.track, True):
                    raise RuntimeError("could not reactivate bridge")
                self._resolve_all()
                self._reasserting_connection = False
                self.send_authoritative_refresh(resolve=False, on_ready=on_ready)
                s.log_message("PrismScript: connection REASSERT prism=%d live='%s'" % (self.track_id, getattr(self.track, 'name', '?')))
            except Exception as e:
                self._reasserting_connection = False
                s.log_message("PrismScript: connection reassert acquire failed track %d: %s" % (self.track_id, str(e)))

        s.schedule_message(2, reacquire)
        return True

    def deactivate(self, write_param=True, preserve_mapping=False):
        if not self.script_only:
            self._s._bridge.set_macro_hold(self.track, False)
        self._macro_handoff_active = False
        self._detached = True
        self._detach_script_simpler_controls()
        self._detach_script_bridge_listeners()
        self._detach_bridge_param_listener()  # before the param write below
        self._detach_macros_listener()
        self._detach_hold_ack_listener()
        self._detach_device_on_listener()
        self._detach_value_listeners()
        self._detach_instrument_listeners()
        self._detach_devices_listener()
        self._detach_simpler_meta_listeners()
        self._detach_pad_chain_listeners()
        self._detach_drum_pad_chain_listeners()
        
        if write_param and not self.script_only:
            try:
                self._s._bridge.set_bridge_active(self.track, False)
            except Exception:
                pass
        if not preserve_mapping:
            # Explicit disconnect: this bridge no longer belongs to a Prism track.
            # (Connection drops use preserve_mapping=True and keep the identity.)
            if not self.script_only:
                self._s._bridge.set_prism_track_id(self.track, None)
            try:
                if self._s._midi_from_is(self.track, self._s.MIDI_FROM_ALL_INS):
                    self._s._set_midi_from(self.track, self._s.MIDI_FROM_KEYBOARD)
            except Exception:
                pass
            # Keep the channel. Changing MIDI From can reset it, so re-apply.
            self._s._auto_set_track_input_channel(self.track, self.track_id)

        self._set_monitoring_auto()
        if self.script_only:
            self._s.request_rebuild_midi_map()
        self._s.log_message("PrismScript: link CLOSED on track %d" % self.track_id)

    def _queue_script_bridge_check(self):
        if self._detached or self._script_bridge_check_pending:
            return
        self._script_bridge_check_pending = True

        def check():
            self._script_bridge_check_pending = False
            if not self._detached:
                self._disable_script_only_bridges()

        self._s.schedule_message(1, check)

    def _disable_script_only_bridges(self):
        """Release stale/late Max ownership and keep it off for this link's life."""
        if not self.script_only or self._detached:
            return

        def watch(obj, kind):
            if any(old == obj and old_kind == kind
                   for old, old_kind, _ in self._script_bridge_listeners):
                return
            fn = self._queue_script_bridge_check
            try:
                getattr(obj, 'add_%s_listener' % kind)(fn)
                self._script_bridge_listeners.append((obj, kind, fn))
            except Exception:
                pass

        for device in self._s._bridge.script_only_bridge_devices(self.track):
            watch(device, 'parameters')
            try:
                params = list(device.parameters)
                marker = next((p for p in params
                               if p.name == self._s._bridge.MARKER_PARAM_NAME), None)
            except Exception as e:
                self._s.log_message("PrismScript: script-only bridge disable failed: %s" % str(e))
                continue

            # Clear pending active(1) before switching the device off. Attempt
            # Device On independently even if the marker cannot be written.
            for param in (marker, params[0] if params else None):
                if param is None:
                    continue
                watch(param, 'value')
                try:
                    if param.value >= 0.5:
                        param.value = 0.0
                except Exception as e:
                    self._s.log_message("PrismScript: script-only bridge disable failed: %s" % str(e))

    def _detach_script_bridge_listeners(self):
        for obj, kind, fn in self._script_bridge_listeners:
            try:
                getattr(obj, 'remove_%s_listener' % kind)(fn)
            except Exception:
                pass
        self._script_bridge_listeners = []

    # ---------------- kill switch (manual toggle in Live — backstop) --------

    def _attach_bridge_param_listener(self, param):
        self._bridge_param = param
        try:
            last_enabled = [param.value >= 0.5]
        except Exception:
            last_enabled = [None]

        def listener():
            if self._detached:
                return
            try:
                enabled = param.value >= 0.5
            except Exception:
                return

            was_enabled = last_enabled[0]
            last_enabled[0] = enabled

            if self._reasserting_connection:
                return

            # OFF is now only a soft M4L disconnect.
            if not enabled:
                return

            # Only refresh on a genuine OFF -> ON transition.
            if was_enabled is not False:
                return

            def cb():
                if self._detached:
                    return

                # Make absolutely sure we're still ON when the deferred refresh runs.
                try:
                    if param.value < 0.5:
                        return
                except Exception:
                    return

                self._resolve_all()
                self.send_full_state()

            # ~200 ms: lets prism_bridge.js re-resolve/rebind its live.remote~
            # connections before we publish the fresh state to Prism.
            self._s.schedule_message(2, cb)

        self._bridge_param_listener = listener
        try:
            param.add_value_listener(listener)
        except Exception as e:
            self._s.log_message(
                "PrismScript: bridge state listener failed on track %d: %s"
                % (self.track_id, str(e))
            )
            self._bridge_param = None
            self._bridge_param_listener = None

    def _next_release_generation(self):
        gen = (self._release_generation + 1) & 0x3FFF
        if gen == 0:
            gen = 1
        self._release_generation = gen
        return gen

    def _arm_snapshot_adoption_wait(self, generation):
        generation = int(generation) & 0x3FFF
        if generation == 0: return False

        self._waiting_for_snapshot_adopted = True
        self._snapshot_adopt_generation = generation
        self._s.log_message("PrismScript: adoption WAIT gen=%d track=%d" % (generation, self.track_id))

        def timeout(g=generation):
            if self._detached or not self._waiting_for_snapshot_adopted: return
            if self._snapshot_adopt_generation != g or self._release_generation != g: return

            self._s.log_message("PrismScript: adoption TIMEOUT gen=%d track=%d" % (g, self.track_id))
            self._clear_snapshot_adoption_wait()

            # Invalidate any late 0x2A from this transaction.
            self._next_release_generation()

            self._preset_handoff_active = False

            if self._macro_handoff_active: self._release_macro_handoff()

            # Same as the MATCH path: external changes still need waveforms.
            if getattr(self._s, "_browse_handoff_track_id", None) == self.track_id:
                self._complete_prism_browser_transaction()
            else:
                self.send_authoritative_waveforms()

        self._s.schedule_message(20, timeout)
        return True


    def handle_snapshot_adopted(self, generation):
        generation = int(generation) & 0x3FFF
        self._s.log_message(
            "PrismScript: SNAPSHOT_ADOPTED <- track=%d gen=%d"
            % (self.track_id, generation)
        )

        if not self._waiting_for_snapshot_adopted:
            return

        if (
            generation != self._snapshot_adopt_generation
            or generation != self._release_generation
        ):
            return

        # Defer because finishing the handoff writes __PrismMacroHold__.
        def finish(g=generation):
            if self._detached or not self._waiting_for_snapshot_adopted:
                return

            if (
                self._snapshot_adopt_generation != g
                or self._release_generation != g
            ):
                return

            self._clear_snapshot_adoption_wait()

            self._s.log_message(
                "PrismScript: adoption MATCH gen=%d track=%d"
                % (g, self.track_id)
            )

            # Final Prism adoption closes the local convergence transaction.
            # This also invalidates any stale local probe/candidate callbacks.
            self._clear_preset_handoff_state()

            if self._macro_handoff_active:
                self._release_macro_handoff()

            # Prism Browser completion already owns its waveform sweep.
            # External Ableton structural changes need the same authoritative
            # waveform publication after ownership has been released.
            if getattr(self._s, "_browse_handoff_track_id", None) == self.track_id:
                self._complete_prism_browser_transaction()
            else:
                self.send_authoritative_waveforms()

        self._s.schedule_message(1, finish)

    def request_prism_browser_release(self, on_released, on_timeout):
        if self._detached:
            return None

        gen = self._next_release_generation()

        # A new request owns the current release generation.
        self._waiting_for_release_ack = False
        self._release_ack_callback = None

        # Transaction tracking is independent of whether physical Macro
        # ownership is currently enabled.
        self._begin_preset_handoff_tracking()

        # __PrismMacros__ OFF means Max owns no realtime remotes for this
        # track, so there is nothing physical to release or acknowledge.
        if self._macros_engaged is not True:
            self._s.log_message(
                "PrismScript: release fence BYPASS no ownership gen=%d track=%d"
                % (gen, self.track_id)
            )

            def bypass():
                if self._detached:
                    return
                if self._release_generation != gen:
                    return
                if on_released is not None:
                    on_released(gen)

            self._s.schedule_message(1, bypass)
            return gen

        # Token MUST be visible to Max before Hold rises.
        if not self._s._bridge.set_hold_token(self.track, gen):
            self._s.log_message(
                "PrismScript: release fence TOKEN FAILED gen=%d track=%d"
                % (gen, self.track_id)
            )

            # Invalidate this generation.
            self._next_release_generation()

            def token_failed():
                if self._detached:
                    return
                if on_timeout is not None:
                    on_timeout("could not write Hold token")

            self._s.schedule_message(1, token_failed)
            return None

        # Arm the Ack receiver before raising Hold.
        self._waiting_for_release_ack = True
        self._release_ack_callback = on_released

        if not self._s._bridge.set_macro_hold(self.track, True):
            self._waiting_for_release_ack = False
            self._release_ack_callback = None

            self._s.log_message(
                "PrismScript: release fence HOLD FAILED gen=%d track=%d"
                % (gen, self.track_id)
            )

            # Invalidate this generation.
            self._next_release_generation()

            def hold_failed():
                if self._detached:
                    return
                if on_timeout is not None:
                    on_timeout("could not engage Hold")

            self._s.schedule_message(1, hold_failed)
            return None

        self._macro_handoff_active = True

        self._s.log_message(
            "PrismScript: release fence WAIT gen=%d track=%d"
            % (gen, self.track_id)
        )

        # About 1.2 seconds at the same scheduler cadence where the old
        # 60-tick watchdog represented roughly six seconds.
        def timeout():
            if self._detached:
                return
            if not self._waiting_for_release_ack:
                return
            if self._release_generation != gen:
                return

            self._s.log_message(
                "PrismScript: release fence TIMEOUT gen=%d track=%d"
                % (gen, self.track_id)
            )

            self._waiting_for_release_ack = False
            self._release_ack_callback = None

            # Invalidate all callbacks/Acks belonging to this generation.
            self._next_release_generation()

            # Pre-load timeout means the load is cancelled. Release Hold so
            # ownership can return instead of leaving the track stranded.
            if self._macro_handoff_active:
                self._release_macro_handoff()

            # The load never happened: stop settle tracking, otherwise the
            # probe keeps resolving this track every ~200 ms until the watchdog.
            self._clear_preset_handoff_state()

            if on_timeout is not None:
                on_timeout("Max release acknowledgment timed out")

        self._s.schedule_message(30, timeout)

        return gen

    def _detach_bridge_param_listener(self):
        if self._bridge_param is not None and self._bridge_param_listener is not None:
            try:
                self._bridge_param.remove_value_listener(self._bridge_param_listener)
            except Exception:
                pass
        self._bridge_param = None
        self._bridge_param_listener = None

    # ---------------- macros toggle (__PrismMacros__, user-owned) ----------------

    def _attach_macros_listener(self):
        param = self._s._bridge.find_macros_param(self.track)
        if param is None:
            self._s.log_message(
                "PrismScript: no __PrismMacros__ param on track %d "
                "(macros toggle unavailable)" % self.track_id)
            return
        self._macros_param = param
        try:
            self._macros_engaged = param.value >= 0.5
        except Exception:
            self._macros_engaged = None

        def listener():
            if self._detached:
                return
            try:
                engaged = param.value >= 0.5
            except Exception:
                return
            was = self._macros_engaged
            self._macros_engaged = engaged
            if engaged and was is False:
                # Re-engage: publish what the user set in Ableton while
                # released, so Prism resumes from reality, not stale state.
                self._send_macro_snapshot()
                self._send_simpler_snapshot()

        self._macros_param_listener = listener
        try:
            param.add_value_listener(listener)
        except Exception:
            self._macros_param = None
            self._macros_param_listener = None

    def _attach_hold_ack_listener(self):
        param = self._s._bridge.find_hold_ack_param(self.track)
        if param is None:
            self._s.log_message(
                "PrismScript: no __PrismHoldAck__ param on track %d"
                % self.track_id
            )
            return

        self._hold_ack_param = param

        def listener():
            if self._detached:
                return

            try:
                ack = int(round(param.value)) & 0x3FFF
            except Exception:
                return

            self._s.log_message(
                "PrismScript: hold ack <- %d track %d"
                % (ack, self.track_id)
            )

            if not self._waiting_for_release_ack:
                return

            if ack != self._release_generation:
                return

            gen = self._release_generation
            callback = self._release_ack_callback

            self._waiting_for_release_ack = False
            self._release_ack_callback = None

            self._s.log_message(
                "PrismScript: release ack MATCH gen=%d track=%d"
                % (gen, self.track_id)
            )

            # DeviceParameter listeners run in Live notification context.
            # Never continue into browser.load_item() directly from here.
            def deliver():
                if self._detached:
                    return
                if self._release_generation != gen:
                    return
                if callback is not None:
                    callback(gen)

            self._s.schedule_message(1, deliver)

        self._hold_ack_listener = listener

        try:
            param.add_value_listener(listener)
        except Exception:
            self._hold_ack_param = None
            self._hold_ack_listener = None

    def _detach_hold_ack_listener(self):
        if self._hold_ack_param is not None and self._hold_ack_listener is not None:
            try:
                self._hold_ack_param.remove_value_listener(self._hold_ack_listener)
            except Exception:
                pass

        self._hold_ack_param = None
        self._hold_ack_listener = None

    def _detach_macros_listener(self):
        if self._macros_param is not None and self._macros_param_listener is not None:
            try:
                self._macros_param.remove_value_listener(self._macros_param_listener)
            except Exception:
                pass
        self._macros_param = None
        self._macros_param_listener = None

    def _send_macro_snapshot(self):
        for i in range(16):
            param = self._macro_params[i]
            if param is not None:
                self._send_feedback_for_param(i + 1, param, force=True)

    def _preset_state_signature(self):
        s = self._s

        # Instrument/rack identity.
        inst = self._instrument_device
        if inst is None:
            inst_sig = None
        else:
            try:
                inst_sig = (
                    str(getattr(inst, 'class_name', '')),
                    str(getattr(inst, 'name', ''))
                )
            except Exception:
                inst_sig = None

        # Current authoritative Rack Macro state.
        macros = []
        for param in self._macro_params:
            if param is None:
                macros.append(None)
                continue

            try:
                macros.append((
                    str(getattr(param, 'name', '')),
                    s._param_to_cc_value(param)
                ))
            except Exception:
                macros.append(None)

        # Current authoritative Simpler state.
        simplers = []

        for simpler in self._simpler_devices:
            if simpler is None:
                simplers.append(None)
                continue

            try:
                playback_mode = int(
                    getattr(simpler, 'playback_mode', 0) or 0
                )
            except Exception:
                playback_mode = -1

            try:
                sample = getattr(simpler, 'sample', None)
                sample_path = (
                    str(getattr(sample, 'file_path', '') or '')
                    if sample is not None else ''
                )
            except Exception:
                sample_path = ''

            try:
                presence_mask, values = \
                    s._get_simpler_snapshot_state(simpler)
            except Exception:
                presence_mask = 0
                values = [0] * s.SIMPLER_SNAPSHOT_PARAM_COUNT

            simplers.append((
                playback_mode,
                sample_path,
                int(presence_mask),
                tuple(values)
            ))

        # Pad names are also part of the newly-loaded kit/preset reality.
        if self._is_drum:
            drum_names = tuple(
                self._drum_names.get(i, '')
                for i in range(s.DRUM_PAD_COUNT)
            )
        else:
            drum_names = ()

        return (
            inst_sig,
            tuple(macros),
            tuple(simplers),
            drum_names
        )

    def _clear_preset_handoff_state(self, invalidate=True):
        if invalidate:
            self._handoff_gen += 1

        self._preset_handoff_active = False
        self._handoff_baseline_signature = None
        self._handoff_last_signature = None
        self._handoff_stable_reads = 0
        self._handoff_probe_pending = False
        self._handoff_activity_seen = False

    def _clear_snapshot_adoption_wait(self):
        self._waiting_for_snapshot_adopted = False
        self._snapshot_adopt_generation = 0

    def _begin_preset_handoff_tracking(self):
        if self._detached:
            return

        self._preset_handoff_active = True
        self._simpler_address_low = None
        self._simpler_pending_feedback.clear()
        self._handoff_gen += 1
        self._handoff_prism_cleared = False   # early Prism feedback, see _publish_handoff_progress
        # Invalidate any per-pad Simpler feedback callbacks that were scheduled
        # before this structural transaction began.
        self._simpler_feedback_gen += 1
        self._handoff_baseline_signature = self._preset_state_signature()
        self._handoff_last_signature = None
        self._handoff_stable_reads = 0
        self._handoff_probe_pending = False
        self._handoff_activity_seen = False

        self._s.log_message(
            "PrismScript: preset settle TRACKING BEGIN track %d"
            % self.track_id
        )

        # Fail-safe: a transaction that never settles must not leave Hold on,
        # the probe spinning, or per-pad updates suppressed forever.
        self._handoff_txn += 1

        def watchdog(t=self._handoff_txn):
            if (
                self._detached
                or not self._preset_handoff_active
                or t != self._handoff_txn
            ):
                return

            self._s.log_message(
                "PrismScript: preset settle WATCHDOG track %d" % self.track_id
            )
            self.cancel_macro_handoff()
            self._resolve_all()
            self.send_full_state()

            if getattr(self._s, "_browse_handoff_track_id", None) == self.track_id:
                self._complete_prism_browser_transaction()
            else:
                self.send_authoritative_waveforms()

        self._s.schedule_message(self._s.PRESET_HANDOFF_WATCHDOG_TICKS, watchdog)

        self._schedule_preset_handoff_probe(1)

    def _mark_preset_handoff_activity(self):
        if self._detached or not self._preset_handoff_active:
            return

        # Any fresh structural activity invalidates every previously scheduled
        # probe / candidate verification for this local convergence transaction.
        self._handoff_gen += 1
        self._handoff_probe_pending = False

        self._handoff_activity_seen = True
        self._handoff_stable_reads = 0
        self._handoff_last_signature = None

        self._schedule_preset_handoff_probe(1)

    def _publish_handoff_progress(self):
        """While a new kit settles: clear the old kit in Prism once, then
        stream pad names and waveforms as soon as each one is readable.
        The final commit still sends the authoritative state."""
        s = self._s
        if self._detached or not self._is_drum:
            return

        if not getattr(self, "_handoff_prism_cleared", False):
            self._handoff_prism_cleared = True
            self._handoff_names_sent = None
            self._handoff_wave_paths = {}

            # Drop old-kit waveform work still queued or sweeping for this track.
            self._authoritative_refresh_gen += 1
            queued = getattr(s, "_waveform_queue", None)
            if queued is not None:
                s._waveform_queue = [q for q in queued if q[0] != self.track_id]

            for i in range(s.DRUM_PAD_COUNT):
                s._send_pad_name_sysex(self.track_id, i + 1, "")
                s._send_waveform_error(0, self.track_id, i, 4, "Loading")
            s._clear_waveform_signatures(self.track_id)

        names = tuple(self._drum_names.get(i, "") for i in range(s.DRUM_PAD_COUNT))
        if names != self._handoff_names_sent:
            self._handoff_names_sent = names
            for i, name in enumerate(names):
                s._send_pad_name_sysex(self.track_id, i + 1, name)

        for pad, simpler in enumerate(self._simpler_devices[:s.DRUM_PAD_COUNT]):
            path = ""
            if simpler is not None:
                try:
                    sample = getattr(simpler, "sample", None)
                    if sample is not None:
                        path = str(getattr(sample, "file_path", "") or "")
                except Exception:
                    path = ""

            if path and self._handoff_wave_paths.get(pad) != path:
                self._handoff_wave_paths[pad] = path
                s._schedule_simpler_waveform_response(
                    self.track_id, pad, 0, s.WAVEFORM_BIN_COUNT
                )

    def _schedule_preset_handoff_probe(self, delay_ticks=2):
        if (
            self._detached
            or not self._preset_handoff_active
            or self._handoff_probe_pending
        ):
            return

        self._handoff_probe_pending = True
        gen = self._handoff_gen

        def cb(g=gen):
            self._handoff_probe_pending = False
            self._run_preset_handoff_probe(g)

        self._s.schedule_message(delay_ticks, cb)

    def _complete_prism_browser_transaction(self):
        if getattr(self._s, "_browse_handoff_track_id", None) != self.track_id:
            return

        self._s._browse_handoff_track_id = None

        self._s.log_message(
            "PrismBrowser: transaction COMPLETE track=%d"
            % self.track_id
        )

        # Connection/state transaction is complete now.
        self._s._send_mode_status(
            self.track_id,
            1,
            self._s.STATUS_OK
        )

        # Waveforms are intentionally outside ownership timing.
        self.send_authoritative_waveforms()

    def _commit_preset_handoff(self, gen):
        if (
            self._detached
            or not self._preset_handoff_active
            or gen != self._handoff_gen
        ):
            return

        self._s.log_message(
            "PrismScript: preset settle COMMIT CANDIDATE track=%d"
            % self.track_id
        )

        # Resolve the candidate, but DO NOT publish it.
        #
        # Publishing here creates a large unmarked 0x20/0x24 batch that can
        # still be draining when the later authoritative commit marker arrives.
        self._resolve_all()

        commit_signature = self._preset_state_signature()

        self._handoff_probe_pending = False

        # No physical Max ownership exists, so there is no delayed ownership
        # release to verify. This stable candidate becomes the final snapshot.
        if not self._macro_handoff_active:
            snapshot_gen = self._release_generation

            self._s.log_message(
                "PrismScript: preset settle COMMIT FINAL track=%d"
                % self.track_id
            )

            self._arm_snapshot_adoption_wait(snapshot_gen)

            self.send_full_state(snapshot_generation=snapshot_gen)

            if not self._is_drum:
                self._s._send_snapshot_commit(self.track_id, snapshot_gen)

            return

        def release(g=gen, expected=commit_signature):
            if (
                self._detached
                or g != self._handoff_gen
                or not self._preset_handoff_active
                or not self._macro_handoff_active
            ):
                return

            # One last structural verification immediately before the
            # authoritative snapshot / eventual ownership return.
            self._resolve_all()
            current = self._preset_state_signature()

            if current != expected:
                self._s.log_message(
                    "PrismScript: preset settle COMMIT INVALIDATED AT FINAL CHECK track=%d"
                    % self.track_id
                )


                self._handoff_gen += 1
                self._handoff_probe_pending = False
                self._handoff_activity_seen = True
                self._handoff_stable_reads = 0
                self._handoff_last_signature = None

                self._schedule_preset_handoff_probe(1)
                return

            self._s.log_message(
                "PrismScript: preset settle COMMIT FINAL track=%d"
                % self.track_id
            )

            snapshot_gen = self._release_generation

            self._arm_snapshot_adoption_wait(snapshot_gen)

            self.send_full_state(snapshot_generation=snapshot_gen)

            if not self._is_drum:
                self._s._send_snapshot_commit(self.track_id, snapshot_gen)

        self._s.schedule_message(2, release)

    def _run_preset_handoff_probe(self, gen):
        if (
            self._detached
            or not self._preset_handoff_active
            or gen != self._handoff_gen
        ):
            return

        if self._s._suppress_device_updates:
            self._schedule_preset_handoff_probe(1)
            return

        # Nothing can change until Max confirms Hold and the load is issued.
        # Resolving now only loads Live's main thread, which delays Max's ack.
        if self._waiting_for_release_ack:
            self._schedule_preset_handoff_probe(2)
            return

        self._resolve_all()
        signature = self._preset_state_signature()

        changed_from_baseline = (
            signature != self._handoff_baseline_signature
        )

        if changed_from_baseline:
            self._handoff_activity_seen = True

        if signature == self._handoff_last_signature:
            self._handoff_stable_reads += 1
        else:
            self._handoff_last_signature = signature
            self._handoff_stable_reads = 0

        # Stream early feedback to Prism while the kit settles.
        if changed_from_baseline:
            self._publish_handoff_progress()

        self._s.log_message(
            "PrismScript: preset settle OBSERVE track=%d activity=%d changed=%d stable=%d"
            % (
                self.track_id,
                1 if self._handoff_activity_seen else 0,
                1 if changed_from_baseline else 0,
                self._handoff_stable_reads
            )
        )

        # Stable authoritative state is ready for final commit.
        if self._handoff_activity_seen and self._handoff_stable_reads >= 3:
            self._commit_preset_handoff(gen)
            return

        self._schedule_preset_handoff_probe(2)

# ---------------- automatic preset/device macro handoff ----------------
    def request_macro_handoff(self):
        if self._detached:
            return

        if self.script_only:
            # Fence incoming macro writes immediately, including in the tick
            # between a Live structural notification and the deferred resolve.
            was_active = self._preset_handoff_active
            self.begin_macro_handoff()
            if not was_active:
                self._mark_preset_handoff_activity()
            return

        def cb():
            if self._detached:
                return

            was_active = self._macro_handoff_active
            self.begin_macro_handoff()

            # This request itself came from a real Ableton structural event.
            # If it started a fresh transaction, preserve that activity after
            # the deferred Hold write / tracking begin.
            if not was_active and self._preset_handoff_active:
                self._mark_preset_handoff_activity()

        self._s.schedule_message(1, cb)

    def begin_macro_handoff(self):
        if self._detached:
            return

        if self.script_only:
            if self._preset_handoff_active:
                self._mark_preset_handoff_activity()
            else:
                self._next_release_generation()
                self._begin_preset_handoff_tracking()
            return

        if self._macro_handoff_active:
            self._mark_preset_handoff_activity()
            return

        # User-owned __PrismMacros__ OFF state stays completely separate.
        if self._macros_engaged is not True:
            return

        # External Ableton structural transactions still need their own
        # generation for the final snapshot -> SNAPSHOT_ADOPTED fence.
        self._next_release_generation()

        if self._s._bridge.set_macro_hold(self.track, True):
            self._macro_handoff_active = True
            self._s.log_message("PrismScript: macro handoff BEGIN track %d" % self.track_id)
            self._begin_preset_handoff_tracking()

            # Hard fail-safe. A handoff must never leave Hold stuck ON.
            watchdog_gen = self._release_generation

            def watchdog(g=watchdog_gen):
                if (
                    self._detached
                    or not self._macro_handoff_active
                    or g != self._release_generation
                ):
                    return

                self._s.log_message(
                    "PrismScript: macro handoff WATCHDOG release track %d"
                    % self.track_id
                )

                # Invalidate the timed-out wire/adoption transaction so a late
                # SNAPSHOT_ADOPTED can never complete it.
                self._next_release_generation()
                self._clear_snapshot_adoption_wait()

                # Kill any remaining local convergence callbacks/state.
                self._clear_preset_handoff_state()

                self._release_macro_handoff()

            self._s.schedule_message(60, watchdog)

    def _release_macro_handoff(self):
        if not self._macro_handoff_active:
            return

        self._s._bridge.set_macro_hold(self.track, False)
        self._macro_handoff_active = False
        self._s.log_message("PrismScript: macro handoff END track %d" % self.track_id)

    def cancel_macro_handoff(self):
        if (
            not self._macro_handoff_active
            and not self._preset_handoff_active
            and not self._waiting_for_snapshot_adopted
        ):
            return

        self._s.log_message(
            "PrismScript: macro handoff CANCEL track %d"
            % self.track_id
        )

        self._next_release_generation()
        self._clear_snapshot_adoption_wait()
        self._clear_preset_handoff_state()

        if self._macro_handoff_active:
            self._release_macro_handoff()


    # ---------------- device on/off (second kill switch) ----------------

    def _attach_device_on_listener(self):
        p = self._s._bridge.get_device_on_param(self.track)
        if p is None: return
        self._device_on_param = p
        try: last_enabled = [p.value >= 0.5]
        except Exception: last_enabled = [None]
        def listener():
            if self._detached: return
            try: enabled = p.value >= 0.5
            except Exception: return
            was_enabled = last_enabled[0]
            last_enabled[0] = enabled
            if not enabled: return
            if was_enabled is not False: return
            def cb():
                if self._detached: return
                try:
                    if p.value < 0.5: return
                except Exception: return
                self.reassert_connection()
            self._s.schedule_message(2, cb)
        self._device_on_listener = listener
        try: p.add_value_listener(listener)
        except Exception:
            self._device_on_param = None
            self._device_on_listener = None

    def _detach_device_on_listener(self):
        if self._device_on_param is not None and self._device_on_listener is not None:
            try:
                self._device_on_param.remove_value_listener(self._device_on_listener)
            except Exception:
                pass
        self._device_on_param = None
        self._device_on_listener = None

    # ---------------- monitoring ----------------

    def _set_monitoring_in(self):
        if not self._s.MONITOR_IN_ON_ACTIVATE:
            return
        # Deferred one tick: Live can override property writes made in the
        # same frame as an input-routing change (which activate() just made).
        def cb():
            if self._detached:
                return
            try:
                if self.track.current_monitoring_state == 0:
                    return  # already In
            except Exception:
                pass
            try:
                self.track.current_monitoring_state = 0  # 0 = In
                self._s.log_message(
                    "PrismScript: track %d monitoring write done, now = %s"
                    % (self.track_id, str(self.track.current_monitoring_state)))
            except Exception as e:
                self._s.log_message(
                    "PrismScript: monitoring set failed on track %d: %s"
                    % (self.track_id, str(e)))
        self._s.schedule_message(1, cb)

    def _set_monitoring_auto(self):
        if not self._s.MONITOR_IN_ON_ACTIVATE:
            return
        try:
            self.track.current_monitoring_state = 1  # 1 = Auto
        except Exception:
            pass

    # ---------------- resolution ----------------

    def _resolve_all(self):
        """(Re)resolve every parameter this link cares about, then reattach
        value listeners. Safe to call repeatedly."""
        self._detach_script_simpler_controls()
        self._detach_value_listeners()
        self._detach_instrument_listeners()
        self._detach_simpler_meta_listeners()
        self._detach_pad_chain_listeners()
        self._detach_drum_pad_chain_listeners()

        s = self._s
        track = self.track

        self._is_drum = s._find_drum_rack_device(track) is not None

        # Macro targets are also writable/listened to for script-only links.
        self._macro_params = [None] * 16
        inst = s._find_first_instrument_device(track)
        self._instrument_device = inst

        if inst is not None:
            params, count = s._get_macro_params_by_index(inst)
            if params:
                self._macro_params = params
                s.log_message(
                    "PrismScript: track %d labels from '%s' (%d macros)"
                    % (self.track_id, inst.name, count)
                )

        # Mixer
        self._mixer = {'VOL': None, 'PAN': None}
        try:
            mixer = track.mixer_device
            self._mixer['VOL'] = getattr(mixer, 'volume', None)
            self._mixer['PAN'] = getattr(mixer, 'panning', None)
        except Exception:
            pass

        # Sends
        self._sends = {'A': None, 'B': None}
        try:
            sends = list(getattr(track.mixer_device, 'sends', []))
            self._sends['A'] = sends[0] if len(sends) > 0 else None
            self._sends['B'] = sends[1] if len(sends) > 1 else None
        except Exception:
            pass

        # Drum pads + Simpler snapshot targets
        self._drum_params = {}
        self._drum_names = {}
        self._simpler_devices = [None] * s.DRUM_PAD_COUNT

        if self._is_drum:
            self._resolve_drum_pads()

        self._resolve_simpler_params()

        if self._is_drum:
            try:
                self._attach_drum_pad_chain_listeners()
            except Exception as e:
                s.log_message(
                    "PrismScript: drum pad chain listeners failed track=%d: %s"
                    % (self.track_id, str(e))
                )

        try:
            self._attach_pad_chain_listeners()
        except Exception as e:
            s.log_message(
                "PrismScript: pad chain listeners failed track=%d: %s"
                % (self.track_id, str(e))
            )

        try:
            self._attach_simpler_meta_listeners()
        except Exception as e:
            s.log_message(
                "PrismScript: Simpler mode listeners failed track=%d: %s"
                % (self.track_id, str(e))
            )

        if self.script_only:
            self._bind_script_simpler_controls(record_modes=True)
        self._attach_value_listeners()
        self._attach_instrument_listeners(inst)

    def _resolve_drum_pads(self):
        s = self._s
        drum_rack = s._find_drum_rack_device(self.track)
        if drum_rack is None:
            return

        for pad_index in range(s.DRUM_PAD_COUNT):
            note = s.DRUM_PAD_NOTE_START + pad_index
            info = s._get_pad_info_for_note(drum_rack, note)

            vol_param = None
            pan_param = None
            name = ''

            if info is not None:
                name = info.get('name', '')
                chain = info.get('chain')

                if chain is not None:
                    try:
                        mixer = chain.mixer_device
                        vol_param = getattr(mixer, 'volume', None)
                        pan_param = getattr(mixer, 'panning', None)
                    except Exception:
                        pass

            self._drum_params[pad_index] = {
                'VOL': vol_param,
                'PAN': pan_param
            }
            self._drum_names[pad_index] = name

    def _resolve_simpler_params(self):
        s = self._s

        self._drum_pad_objects = [None] * s.DRUM_PAD_COUNT
        self._pad_chains = [None] * s.DRUM_PAD_COUNT
        self._simpler_devices = [None] * s.DRUM_PAD_COUNT

        drum_rack = s._find_drum_rack_device(self.track)
        if drum_rack is None:
            simpler = s._find_simpler_in_container(self.track)
            self._simpler_devices[0] = simpler
            self._pad_chains[0] = (
                getattr(simpler, 'canonical_parent', self.track)
                if simpler is not None else self.track
            )
            return

        for pad_index in range(s.DRUM_PAD_COUNT):
            note = s.DRUM_PAD_NOTE_START + pad_index
            info = s._get_pad_info_for_note(drum_rack, note)

            if info is None:
                continue

            self._drum_pad_objects[pad_index] = info.get('pad')

            chain = info.get('chain')
            if chain is None:
                continue

            self._pad_chains[pad_index] = chain

            simpler = s._find_simpler_in_container(chain)
            if simpler is None:
                continue

            self._simpler_devices[pad_index] = simpler

    def _simpler_state_for_pad(self, pad_index):
        if pad_index < 0 or pad_index >= self._s.DRUM_PAD_COUNT:
            return 0

        simpler = self._simpler_devices[pad_index]
        if simpler is None:
            return 0

        try:
            mode = int(simpler.playback_mode)
        except Exception:
            mode = 0

        mode = max(0, min(2, mode))

        # 1 Classic, 2 One-Shot, 3 Slicing
        return mode + 1

    def _send_pad_meta(self, pad_index):
        self._s._send_pad_meta_sysex(
            self.track_id,
            pad_index + 1,
            self._simpler_state_for_pad(pad_index)
        )
            
    def _send_simpler_snapshot(self, snapshot_generation=0):
        s = self._s

        if not self._is_drum:
            self._send_simpler_snapshot_for_pad(0)
            return

        last_pad = s.DRUM_PAD_COUNT - 1

        for pad_index in range(s.DRUM_PAD_COUNT):
            simpler = self._simpler_devices[pad_index]

            if simpler is None:
                presence_mask = 0
                values = [0] * s.SIMPLER_SNAPSHOT_PARAM_COUNT
            else:
                presence_mask, values = s._get_simpler_snapshot_state(simpler)

            generation = (
                snapshot_generation
                if pad_index == last_pad
                else 0
            )

            s._send_simpler_snapshot_pad(
                self.track_id,
                pad_index,
                presence_mask,
                values,
                snapshot_generation=generation
            )

    # ---------------- listeners ----------------

    def _attach_devices_listener(self):
        if not hasattr(self.track, 'devices'):
            return

        def listener():
            self._on_devices_changed()

        self._devices_listener = listener
        try:
            self.track.add_devices_listener(listener)
        except Exception as e:
            self._s.log_message("PrismScript: devices listener failed on track %d: %s"
                                % (self.track_id, str(e)))
            self._devices_listener = None

    def _detach_devices_listener(self):
        if self._devices_listener is None:
            return
        try:
            if hasattr(self.track, 'remove_devices_listener'):
                self.track.remove_devices_listener(self._devices_listener)
        except Exception:
            pass
        self._devices_listener = None

    def _attach_value_listeners(self):
        s = self._s

        def make(cc_number, param):
            def listener():
                if self._detached:
                    return
                if self.script_only and cc_number <= 16:
                    if self._script_writes_held() or self._script_macro_write_active:
                        return
                self._send_feedback_for_param(cc_number, param, force=False)
            return listener

        # Macro (CC 1-16) LIVE feedback is owned by the M4L device: its dials
        # send 0x20 directly to Prism on user turns, which is the only way to
        # distinguish a manual move from a Prism-driven one (plocks/LFOs).
        # Script-only links own their writes and can suppress their own echoes.
        # The activation/preset-change macro snapshot stays on in both modes.
        if s.MACRO_VALUE_LISTENERS or self.script_only:
            for i in range(16):
                param = self._macro_params[i]
                if param is None:
                    continue
                fn = make(i + 1, param)
                self._macro_listeners[i] = fn
                try:
                    param.add_value_listener(fn)
                except Exception:
                    self._macro_listeners.pop(i, None)

        for which, cc in (('VOL', s.CC_VOLUME), ('PAN', s.CC_PAN)):
            param = self._mixer.get(which)
            if param is not None:
                fn = make(cc, param)
                self._mixer_listeners[which] = fn
                try:
                    param.add_value_listener(fn)
                except Exception:
                    self._mixer_listeners.pop(which, None)

        for which, cc in (('A', s.CC_SEND_A), ('B', s.CC_SEND_B)):
            param = self._sends.get(which)
            if param is not None:
                fn = make(cc, param)
                self._send_listeners[which] = fn
                try:
                    param.add_value_listener(fn)
                except Exception:
                    self._send_listeners.pop(which, None)

        for pad_index, pad in self._drum_params.items():
            self._drum_listeners[pad_index] = {}
            for which, cc_start in (('VOL', s.CC_DRUM_VOL_START),
                                    ('PAN', s.CC_DRUM_PAN_START)):
                param = pad.get(which)
                if param is None:
                    continue
                fn = make(cc_start + pad_index, param)
                self._drum_listeners[pad_index][which] = fn
                try:
                    param.add_value_listener(fn)
                except Exception:
                    self._drum_listeners[pad_index].pop(which, None)

    def _detach_value_listeners(self):
        for i, fn in list(self._macro_listeners.items()):
            param = self._macro_params[i] if i < len(self._macro_params) else None
            if param is not None:
                try:
                    param.remove_value_listener(fn)
                except Exception:
                    pass
        self._macro_listeners = {}

        for which, fn in list(self._mixer_listeners.items()):
            param = self._mixer.get(which)
            if param is not None:
                try:
                    param.remove_value_listener(fn)
                except Exception:
                    pass
        self._mixer_listeners = {}

        for which, fn in list(self._send_listeners.items()):
            param = self._sends.get(which)
            if param is not None:
                try:
                    param.remove_value_listener(fn)
                except Exception:
                    pass
        self._send_listeners = {}

        for pad_index, pad_fns in list(self._drum_listeners.items()):
            pad_params = self._drum_params.get(pad_index, {})
            for which, fn in list(pad_fns.items()):
                param = pad_params.get(which)
                if param is not None:
                    try:
                        param.remove_value_listener(fn)
                    except Exception:
                        pass
        self._drum_listeners = {}

    def _attach_instrument_listeners(self, inst):
        """Name / parameters listeners on the instrument, for label refresh
        on preset load or macro remap."""
        self._instrument_listeners = []
        if inst is None:
            return

        def make():
            def listener():
                if self._s._suppress_device_updates:
                    return
                self.request_macro_handoff()
            return listener

        if hasattr(inst, 'add_name_listener'):
            try:
                fn = make()
                inst.add_name_listener(fn)
                self._instrument_listeners.append(('name', inst, fn))
            except Exception:
                pass

        if hasattr(inst, 'add_parameters_listener'):
            try:
                fn = make()
                inst.add_parameters_listener(fn)
                self._instrument_listeners.append(('parameters', inst, fn))
            except Exception:
                pass

    def _detach_instrument_listeners(self):
        for kind, device, fn in self._instrument_listeners:
            try:
                if kind == 'name' and hasattr(device, 'remove_name_listener'):
                    device.remove_name_listener(fn)
                elif kind == 'parameters' and hasattr(device, 'remove_parameters_listener'):
                    device.remove_parameters_listener(fn)
            except Exception:
                pass
        self._instrument_listeners = []

    

    def _attach_pad_chain_listeners(self):
        self._pad_chain_listeners = {}

        for pad_index, chain in enumerate(self._pad_chains):
            if chain is None:
                continue

            if not hasattr(chain, 'add_devices_listener'):
                continue

            def make_listener(pad):
                def listener():
                    if self._detached or self._s._suppress_device_updates:
                        return

                    # Use the EXISTING structural refresh/debounce.
                    self.request_macro_handoff()

                return listener

            fn = make_listener(pad_index)

            try:
                chain.add_devices_listener(fn)
                self._pad_chain_listeners[pad_index] = (chain, fn)
            except Exception:
                pass

    def _detach_pad_chain_listeners(self):
        for pad_index, item in list(getattr(self, '_pad_chain_listeners', {}).items()):
            chain, fn = item

            try:
                if hasattr(chain, 'remove_devices_listener'):
                    chain.remove_devices_listener(fn)
            except Exception:
                pass

        self._pad_chain_listeners = {}

    def _send_simpler_snapshot_for_pad(self, pad_index):
        s = self._s
        if pad_index < 0 or pad_index >= s.DRUM_PAD_COUNT:
            return
        simpler = self._simpler_devices[pad_index]
        if simpler is None:
            presence_mask, values = 0, [0] * s.SIMPLER_SNAPSHOT_PARAM_COUNT
        else:
            presence_mask, values = s._get_simpler_snapshot_state(simpler)
        s._send_simpler_snapshot_pad(self.track_id, pad_index, presence_mask, values)
        
    def _attach_drum_pad_chain_listeners(self):
        self._drum_pad_chain_listeners = {}

        for pad_index, pad in enumerate(self._drum_pad_objects):
            if pad is None or not hasattr(pad, 'add_chains_listener'):
                continue

            expected_chain = self._pad_chains[pad_index] if pad_index < len(self._pad_chains) else None

            def make_listener(pad, initial_chain):
                last_chain = [initial_chain]

                def listener():
                    if self._detached or self._s._suppress_device_updates:
                        return

                    try:
                        chains = list(getattr(pad, 'chains', []) or [])
                        current_chain = chains[0] if chains else None
                    except Exception:
                        return

                    # Ignore initial/duplicate notifications. We only care when
                    # the actual Chain object assigned to this DrumPad changes.
                    if current_chain == last_chain[0]:
                        return

                    last_chain[0] = current_chain
                    self.request_macro_handoff()

                return listener

            fn = make_listener(pad, expected_chain)

            try:
                pad.add_chains_listener(fn)
                self._drum_pad_chain_listeners[pad_index] = (pad, fn)
            except Exception as e:
                self._s.log_message(
                    "PrismScript: DrumPad chains listener attach failed "
                    "track=%d pad=%d: %s"
                    % (self.track_id, pad_index, str(e))
                )
                
    def _detach_drum_pad_chain_listeners(self):
        for pad_index, item in list(getattr(self, '_drum_pad_chain_listeners', {}).items()):
            pad, fn = item

            try:
                if hasattr(pad, 'remove_chains_listener'):
                    pad.remove_chains_listener(fn)
            except Exception:
                pass

        self._drum_pad_chain_listeners = {}

    def _attach_simpler_meta_listeners(self):
        self._simpler_mode_listeners = {}

        for pad_index, simpler in enumerate(self._simpler_devices):
            if simpler is None:
                continue

            listeners = []

            if hasattr(simpler, 'add_playback_mode_listener'):
                def make_mode_listener(pad):
                    def listener():
                        if self._detached:
                            return

                        # During preset convergence this event is structural
                        # activity. Do not independently publish a stale
                        # per-pad snapshot; the final authoritative snapshot
                        # will contain the settled value.
                        if self._preset_handoff_active:
                            self._mark_preset_handoff_activity()
                            return

                        if self.script_only:
                            if not self._on_script_simpler_mode_changed(pad):
                                return
                            self._queue_script_simpler_state(pad, (6, 7, 20, 23))
                            self._queue_script_simpler_meta(pad)
                            return

                        feedback_gen = self._simpler_feedback_gen

                        def send(g=feedback_gen):
                            if (
                                self._detached
                                or g != self._simpler_feedback_gen
                                or self._preset_handoff_active
                            ):
                                return

                            self._send_pad_meta(pad)
                            self._send_simpler_snapshot_for_pad(pad)

                        self._s.schedule_message(2, send)

                    return listener

                fn = make_mode_listener(pad_index)

                try:
                    simpler.add_playback_mode_listener(fn)
                    listeners.append(('playback_mode', fn))
                except Exception:
                    pass

            if hasattr(simpler, 'add_sample_listener'):
                def make_sample_listener(pad):
                    def listener():
                        if self._detached:
                            return

                        # Same rule: a sample change during a structural handoff
                        # belongs to convergence, not an independent snapshot.
                        if self._preset_handoff_active:
                            self._mark_preset_handoff_activity()
                            return

                        if self.script_only:
                            self._bind_script_simpler_controls(pads=(pad,))
                            self._queue_script_simpler_state(pad, (4, 5, 6, 7))
                            self._queue_script_simpler_meta(pad, waveform=True)
                            return

                        feedback_gen = self._simpler_feedback_gen

                        def send(g=feedback_gen):
                            if (
                                self._detached
                                or g != self._simpler_feedback_gen
                                or self._preset_handoff_active
                            ):
                                return

                            self._send_simpler_snapshot_for_pad(pad)

                            self._s._schedule_simpler_waveform_response(
                                self.track_id,
                                pad,
                                0,
                                self._s.WAVEFORM_BIN_COUNT
                            )

                        self._s.schedule_message(2, send)

                    return listener

                fn = make_sample_listener(pad_index)

                try:
                    simpler.add_sample_listener(fn)
                    listeners.append(('sample', fn))
                except Exception:
                    pass

            if listeners:
                self._simpler_mode_listeners[pad_index] = (simpler, listeners)
            
    def _detach_simpler_meta_listeners(self):
        for pad_index, item in list(getattr(self, '_simpler_mode_listeners', {}).items()):
            simpler, listeners = item
            for kind, fn in listeners:
                try:
                    if kind == 'playback_mode' and hasattr(simpler, 'remove_playback_mode_listener'):
                        simpler.remove_playback_mode_listener(fn)
                    elif kind == 'sample' and hasattr(simpler, 'remove_sample_listener'):
                        simpler.remove_sample_listener(fn)
                except Exception:
                    pass
        self._simpler_mode_listeners = {}

    # ---------------- refresh (debounced) ----------------

    def _on_devices_changed(self):
        if self.script_only:
            self._queue_script_bridge_check()
        if self._s._suppress_device_updates:
            return

        new_inst = self._s._find_first_instrument_device(self.track)

        if new_inst != self._instrument_device:
            self.request_macro_handoff()
            return

        if self.script_only:
            return

        # A top-level device-list change that did not replace the instrument
        # mostly matters to us if the Prism Bridge itself was removed.
        # Defer out of Live's notification callback because deactivation writes
        # Hold / routing state.
        def check_bridge():
            if self._detached:
                return
            if self._s._bridge.find_bridge_param(self.track) is None:
                self._s._on_bridge_lost(self.track_id)

        self._s.schedule_message(1, check_bridge)

    # ---------------- selection ----------------

    def on_selected(self):
        """Full refresh + feedback cycle when this track is selected
        (legacy on-select behavior, scoped to linked tracks)."""
        s = self._s
        s._set_midi_from(self.track, s.MIDI_FROM_ALL_INS)
        s._auto_set_track_input_channel(self.track, self.track_id)
        self._set_monitoring_in()

        # Mid-transaction state is transient (can briefly look non-drum).
        # The handoff commit publishes the settled state.
        if (self._preset_handoff_active or self._macro_handoff_active
                or (self.script_only and self._waiting_for_snapshot_adopted)):
            return

        self._resolve_all()
        self.send_full_state(selected=True)

    # ---------------- script-only Simpler ownership ----------------

    def _simpler_control_generation(self, pad):
        return (self._simpler_control_gen, self._simpler_pad_gen[pad])

    def _detach_script_simpler_controls(self, pad=None):
        if pad is None:
            self._simpler_control_gen += 1
            self._simpler_pending_feedback.clear()
            self._simpler_pending_meta.clear()
        else:
            self._simpler_pad_gen[pad] += 1
            self._simpler_pending_feedback.pop(pad, None)
        self._simpler_address_low = None
        kept = []
        for listener_pad, obj, prop, fn in self._simpler_control_listeners:
            if pad is not None and listener_pad != pad:
                kept.append((listener_pad, obj, prop, fn))
                continue
            try:
                getattr(obj, 'remove_%s_listener' % prop)(fn)
            except Exception:
                pass
        self._simpler_control_listeners = kept

    def _read_simpler_target(self, target):
        if target is None:
            return None
        obj, prop = target
        try:
            if prop == 'value':
                # Invalid/stale proxies must not masquerade as a zero value.
                obj.value
                return self._s._param_to_cc_value(obj)
            return self._s._sample_marker_to_cc(obj, prop)
        except Exception:
            return None

    def _bind_script_simpler_controls(self, record_modes=False, pads=None):
        if not self.script_only or self._detached:
            return
        if pads is None:
            self._detach_script_simpler_controls()
            self._simpler_last_received.clear()
            self._simpler_last_sent.clear()
            pads = range(self._s.DRUM_PAD_COUNT)
            preserved_feedback = {}
        else:
            preserved_feedback = {pad: dict(self._simpler_pending_feedback.get(pad, {}))
                                  for pad in pads}
            for pad in pads:
                self._detach_script_simpler_controls(pad)
                for cache in (self._simpler_last_received, self._simpler_last_sent):
                    for key in list(cache):
                        if key[0] == pad:
                            cache.pop(key, None)

        def attach(pad, obj, prop, fn):
            try:
                getattr(obj, 'add_%s_listener' % prop)(fn)
                self._simpler_control_listeners.append((pad, obj, prop, fn))
            except Exception:
                pass

        for pad in pads:
            self._simpler_targets[pad] = [None] * self._s.SIMPLER_SNAPSHOT_PARAM_COUNT
            simpler = self._simpler_devices[pad]
            generation = self._simpler_control_generation(pad)
            if simpler is None:
                self._script_simpler_modes.pop(pad, None)
                continue
            if record_modes or pad not in self._script_simpler_modes:
                try:
                    self._script_simpler_modes[pad] = (simpler, int(simpler.playback_mode))
                except Exception:
                    self._script_simpler_modes.pop(pad, None)
            targets = self._s._get_simpler_write_targets(simpler)
            self._simpler_targets[pad] = targets
            groups = {}
            for slot, target in enumerate(targets):
                if target is None:
                    continue
                obj, prop = target
                self._simpler_last_sent[(pad, slot)] = self._read_simpler_target(target)
                # One marker listener owns both its absolute and p-lock aliases.
                key = (id(obj), prop)
                groups.setdefault(key, (obj, prop, []))[2].append(slot)

            for obj, prop, slots in groups.values():
                def make_listener(pad_index, indices, target, gen):
                    def listener():
                        if (self._detached or gen != self._simpler_control_generation(pad_index)
                                or self._script_writes_held()
                                or self._script_simpler_write_active):
                            return
                        value = self._read_simpler_target(target)
                        if value is None:
                            return
                        changed = {}
                        for slot_index in indices:
                            key = (pad_index, slot_index)
                            if (value == self._simpler_last_received.get(key)
                                    or value == self._simpler_last_sent.get(key)):
                                continue
                            self._simpler_last_received.pop(key, None)
                            self._simpler_last_sent[key] = value
                            changed[slot_index] = value
                        if changed:
                            self._queue_script_simpler_feedback(pad_index, changed, gen)
                    return listener
                attach(pad, obj, prop, make_listener(pad, tuple(slots), (obj, prop), generation))

            def make_layout_listener(pad_index, gen):
                def listener():
                    if self._detached or gen != self._simpler_control_generation(pad_index):
                        return
                    if self._script_writes_held():
                        self._mark_preset_handoff_activity()
                        return
                    self._bind_script_simpler_controls(pads=(pad_index,))
                return listener
            attach(pad, simpler, 'parameters', make_layout_listener(pad, generation))
            preserved = {slot: value for slot, value in preserved_feedback.get(pad, {}).items()
                         if self._simpler_targets[pad][slot] is not None}
            if preserved:
                self._queue_script_simpler_feedback(pad, preserved, generation)

    def _queue_script_simpler_meta(self, pad, waveform=False):
        self._simpler_pending_meta[pad] = (waveform or self._simpler_pending_meta.get(pad, False))
        self._simpler_meta_gen[pad] += 1
        revision = self._simpler_meta_gen[pad]
        generation = self._simpler_control_gen
        def send(pad_index=pad, rev=revision, gen=generation):
            if (self._detached or gen != self._simpler_control_gen
                    or rev != self._simpler_meta_gen[pad_index]):
                return
            needs_waveform = self._simpler_pending_meta.pop(pad_index, False)
            if self._script_writes_held():
                return
            self._send_pad_meta(pad_index)
            if needs_waveform:
                self._s._schedule_simpler_waveform_response(
                    self.track_id, pad_index, 0, self._s.WAVEFORM_BIN_COUNT)
        self._s.schedule_message(2, send)

    def _queue_script_simpler_state(self, pad, slots):
        changes = {}
        for slot in slots:
            value = self._read_simpler_target(self._simpler_targets[pad][slot])
            if value is not None:
                changes[slot] = value
        if changes:
            self._queue_script_simpler_feedback(pad, changes, self._simpler_control_generation(pad))

    def _queue_script_simpler_feedback(self, pad, changes, generation):
        pending = self._simpler_pending_feedback.get(pad)
        if pending is not None:
            pending.update(changes)
            return
        self._simpler_pending_feedback[pad] = dict(changes)
        def send(gen=generation, pad_index=pad):
            if gen != self._simpler_control_generation(pad_index):
                return
            changed = self._simpler_pending_feedback.pop(pad_index, {})
            if self._detached or self._script_writes_held() or not changed:
                return
            # Capture only manual changes, never reread unrelated played LFO values.
            values = [0] * self._s.SIMPLER_SNAPSHOT_PARAM_COUNT
            mask = 0
            for slot, value in changed.items():
                values[slot] = value
                mask |= 1 << slot
            self._s._send_simpler_snapshot_pad(self.track_id, pad_index, mask, values)
        self._s.schedule_message(1, send)

    def _on_script_simpler_mode_changed(self, pad):
        simpler = self._simpler_devices[pad]
        previous = self._script_simpler_modes.get(pad)
        try:
            mode = int(simpler.playback_mode)
            same_instance = previous is not None and previous[0] == simpler
            if same_instance and previous[1] == mode:
                return False
        except Exception:
            self._bind_script_simpler_controls(pads=(pad,))
            return False
        if (same_instance
                and (previous[1] == 0) != (mode == 0)
                and not self._script_writes_held()):
            try:
                params = list(simpler.parameters)
            except Exception:
                params = []
            old_names = ('Ve Attack', 'Ve Release') if previous[1] == 0 else ('Fade In', 'Fade Out')
            new_names = ('Ve Attack', 'Ve Release') if mode == 0 else ('Fade In', 'Fade Out')
            was_writing = self._script_simpler_write_active
            self._script_simpler_write_active = True
            try:
                for source_name, target_name in zip(old_names, new_names):
                    source = self._s._find_simpler_param(params, (source_name,))
                    target = self._s._find_simpler_param(params, (target_name,))
                    if source is None or target is None:
                        continue
                    try:
                        if not getattr(target, 'is_enabled', True):
                            continue
                        span = source.max - source.min
                        normalized = (source.value - source.min) / span if span else 0.0
                        normalized = max(0.0, min(1.0, normalized))
                        value = target.min + normalized * (target.max - target.min)
                        target.value = round(value) if getattr(target, 'is_quantized', False) else value
                    except Exception as e:
                        self._s.log_message('PrismScript: Simpler envelope transfer failed: %s' % str(e))
            finally:
                self._script_simpler_write_active = was_writing
        self._script_simpler_modes[pad] = (simpler, mode)
        self._bind_script_simpler_controls(pads=(pad,))
        return True

    def _handle_simpler_cc(self, cc, value):
        if self._script_writes_held():
            self._simpler_address_low = None
            return
        if cc == self._s.CC_SIMPLER_ADDRESS:
            self._simpler_address_low = value if 0 <= value <= 127 else None
            return
        address = self._simpler_address_low
        self._simpler_address_low = None
        if address is None or not 0 <= value <= 127:
            return
        remote_slot = address + 128 * (cc - self._s.CC_SIMPLER_VALUE_BANK_0)
        pad, slot = divmod(remote_slot, self._s.SIMPLER_SNAPSHOT_PARAM_COUNT)
        if not 0 <= pad < self._s.DRUM_PAD_COUNT:
            return
        target = self._simpler_targets[pad][slot]
        if target is None:
            return
        obj, prop = target
        was_writing = self._script_simpler_write_active
        self._script_simpler_write_active = True
        try:
            if prop == 'value':
                if not getattr(obj, 'is_enabled', True):
                    return
                raw = obj.min + (obj.max - obj.min) * (value / 127.0)
                obj.value = round(raw) if getattr(obj, 'is_quantized', False) else raw
            else:
                length = int(obj.length)
                if length <= 1:
                    return
                maximum = length - 1
                raw = int(round((value / 127.0) * maximum))
                if prop == 'start_marker':
                    raw = min(raw, max(0, int(obj.end_marker) - 1), maximum - 1)
                else:
                    raw = max(raw, int(obj.start_marker) + 1)
                    raw = min(maximum, raw)
                    if raw <= int(obj.start_marker):
                        return
                setattr(obj, prop, max(0, raw))
            # Suppress delayed notifications too, with Live's actual rounded value.
            # Sample-marker aliases must share echo ownership.
            for alias, candidate in enumerate(self._simpler_targets[pad]):
                if candidate is not None and candidate[0] == obj and candidate[1] == prop:
                    self._simpler_last_received[(pad, alias)] = self._read_simpler_target(candidate)
        except Exception as e:
            self._s.log_message('PrismScript: Simpler write failed track=%d pad=%d slot=%d: %s'
                                % (self.track_id, pad, slot, str(e)))
        finally:
            self._script_simpler_write_active = was_writing

    # ---------------- incoming CCs ----------------

    def _script_writes_held(self):
        return self._preset_handoff_active or self._waiting_for_snapshot_adopted

    def handle_cc(self, cc, value):
        s = self._s

        if self._detached:
            return

        if s.CC_SIMPLER_ADDRESS <= cc <= s.CC_SIMPLER_VALUE_BANK_2:
            if self.script_only:
                self._handle_simpler_cc(cc, value)
            return

        if 1 <= cc <= 16:
            if self.script_only and not self._script_writes_held():
                param = self._macro_params[cc - 1]
                if param is None or not getattr(param, 'is_enabled', True):
                    return
                # A value listener may fire synchronously inside param.value=.
                # Record the resulting value afterwards to suppress deferred
                # feedback too, including quantized values.
                self._script_macro_write_active = True
                try:
                    self._write_cc(param, cc, value)
                finally:
                    self._script_macro_write_active = False
            return

        if cc == s.CC_VOLUME:
            self._write_cc(self._mixer.get('VOL'), cc, value)
        elif cc == s.CC_PAN:
            self._write_cc(self._mixer.get('PAN'), cc, value)
        elif cc == s.CC_SEND_A:
            self._write_cc(self._sends.get('A'), cc, value)
        elif cc == s.CC_SEND_B:
            self._write_cc(self._sends.get('B'), cc, value)
        elif s.CC_DRUM_VOL_START <= cc < s.CC_DRUM_VOL_START + s.DRUM_PAD_COUNT:
            pad = self._drum_params.get(cc - s.CC_DRUM_VOL_START, {})
            self._write_cc(pad.get('VOL'), cc, value)
        elif s.CC_DRUM_PAN_START <= cc < s.CC_DRUM_PAN_START + s.DRUM_PAD_COUNT:
            pad = self._drum_params.get(cc - s.CC_DRUM_PAN_START, {})
            self._write_cc(pad.get('PAN'), cc, value)

    def _write_cc(self, param, cc, value):
        if param is None:
            return
        self._s._set_param_from_cc(param, value)
        self._last_received[cc] = self._s._param_to_cc_value(param)

    # ---------------- feedback (script -> Prism) ----------------

    def _send_feedback_for_param(self, cc, param, force=False):
        s = self._s
        cc_value = s._param_to_cc_value(param)

        received_same = s._values_close(cc_value, self._last_received.get(cc))
        sent_same = s._values_close(cc_value, self._last_sent.get(cc))

        if force or ((not received_same) and (not sent_same)):
            s._send_cc_for_track(self.track_id, cc, cc_value)
            self._last_sent[cc] = cc_value
            self._last_received[cc] = None

    def send_authoritative_refresh(self, resolve=True, on_ready=None):
        """Resolve current Live reality, publish authoritative state, then
        independently begin the waveform sweep."""
        if self._detached or not self._s._connected:
            return

        if resolve:
            self._resolve_all()

        self._s._send_waveform_context(self.track_id)
        self.send_full_state()
        # Connection readiness belongs to the control/state refresh. A newer
        # waveform generation may cancel a sweep, but must never cancel its ACK.
        if on_ready is not None:
            def ready():
                if not self._detached and self._s._connected:
                    on_ready()
            self._s.schedule_message(1, ready)
        self.send_authoritative_waveforms()

    def send_authoritative_waveforms(self, on_complete=None):
        """Waveform-only authoritative refresh.

        Waveform work must never own preset handoff / Hold timing.
        """
        if self._detached or not self._s._connected:
            return

        self._authoritative_refresh_gen += 1
        gen = self._authoritative_refresh_gen

        def start(g=gen, done=on_complete):
            self._continue_authoritative_waveform_refresh(g, 0, done)

        self._s.schedule_message(1, start)

    def _verify_waveforms_later(self, delay_ticks=15):
        """Kits can finish attaching Simplers/samples after the sweep ran.
        ~1.5 s later, re-check every pad once and resend any pad whose
        current sample differs from what Prism was last sent."""
        gen = self._authoritative_refresh_gen

        def check(g=gen):
            if (
                self._detached
                or not self._s._connected
                or g != self._authoritative_refresh_gen
            ):
                return

            s = self._s
            pad_count = s.DRUM_PAD_COUNT if self._is_drum else 1
            for pad in range(pad_count):
                try:
                    _t, simpler, _i, _e = s._resolve_simpler_lab_target(self.track_id, pad)
                    sample = getattr(simpler, "sample", None) if simpler is not None else None
                    path = str(getattr(sample, "file_path", "") or "") if sample is not None else ""
                except Exception:
                    continue

                if path != s._last_wave_paths.get((self.track_id, pad), ""):
                    s._schedule_simpler_waveform_response(
                        self.track_id, pad, 0, s.WAVEFORM_BIN_COUNT
                    )

        self._s.schedule_message(delay_ticks, check)

    def _continue_authoritative_waveform_refresh(self, gen, pad_index, on_complete):
        if (
            self._detached
            or not self._s._connected
            or gen != self._authoritative_refresh_gen
        ):
            return

        pad = int(pad_index)
        processed = 0
        pads_per_tick = 8
        pad_count = self._s.DRUM_PAD_COUNT if self._is_drum else 1

        while pad < pad_count and processed < pads_per_tick:
            simpler = (
                self._simpler_devices[pad]
                if pad < len(self._simpler_devices)
                else None
            )

            # Empty pads get an explicit "no Simpler" reply so Prism clears
            # them instead of keeping the previous kit's waveform.
            self._s._schedule_simpler_waveform_response(
                self.track_id,
                pad,
                0,
                self._s.WAVEFORM_BIN_COUNT
            )
            processed += 1

            pad += 1

        if pad >= pad_count:
            self._verify_waveforms_later()
            if on_complete is not None:
                on_complete()
            return

        def next_batch(g=gen, p=pad, done=on_complete):
            self._continue_authoritative_waveform_refresh(g, p, done)

        self._s.schedule_message(1, next_batch)

    def send_full_state(self, snapshot_generation=0, selected=False):
        """Everything Prism needs about this track.

        Structural metadata is sent before parameter values so Prism can build /
        resolve the Ableton mapped profile before the first value snapshot arrives.

        When snapshot_generation is non-zero on drums, the final Simpler pad
        carries the authoritative transaction generation and becomes the mapped-value
        commit boundary. Tones send their slot-zero snapshot before the existing
        explicit non-drum commit in _commit_preset_handoff().
        """
        s = self._s

        if not s._connected:
            return

        # ------------------------------------------------------------
        # STRUCTURE FIRST
        # ------------------------------------------------------------

        s._send_track_info(
            self.track_id,
            self.track,
            self._is_drum,
            selected
        )

        self._send_all_labels()

        # Pad names also carry 0x07 Simpler mode metadata, so publish them
        # before the authoritative parameter values.
        self._send_all_pad_names()

        # ------------------------------------------------------------
        # VALUES SECOND
        # ------------------------------------------------------------

        self._send_macro_snapshot()

        # Mixer / sends
        for which, cc in (
            ('VOL', s.CC_VOLUME),
            ('PAN', s.CC_PAN)
        ):
            param = self._mixer.get(which)

            if param is not None:
                self._send_feedback_for_param(
                    cc,
                    param,
                    force=True
                )

        for which, cc in (
            ('A', s.CC_SEND_A),
            ('B', s.CC_SEND_B)
        ):
            param = self._sends.get(which)

            if param is not None:
                self._send_feedback_for_param(
                    cc,
                    param,
                    force=True
                )

        # Drum pad mixer values
        for pad_index, pad in self._drum_params.items():
            vol = pad.get('VOL')

            if vol is not None:
                self._send_feedback_for_param(
                    s.CC_DRUM_VOL_START + pad_index,
                    vol,
                    force=True
                )

            pan = pad.get('PAN')

            if pan is not None:
                self._send_feedback_for_param(
                    s.CC_DRUM_PAN_START + pad_index,
                    pan,
                    force=True
                )

        # IMPORTANT:
        # Simpler is intentionally LAST among mapped-value publications.
        #
        # For an authoritative Browser commit on drums, pad 15 additionally carries
        # generationLo/generationHi. Prism queues that pad's snapshot and then
        # the commit marker from the same completed SysEx.
        # Tones send slot zero here, then the existing explicit non-drum commit
        # in _commit_preset_handoff().
        self._send_simpler_snapshot(
            snapshot_generation=snapshot_generation
        )

    def _send_all_labels(self):
        s = self._s
        for i in range(16):
            macro_index = i + 1
            param = self._macro_params[i]
            label = ""
            if param is not None and s._is_macro_mapped(param, macro_index):
                label = param.name
            s._send_label_sysex(self.track_id, macro_index, label)

    def _send_all_pad_names(self):
        s = self._s

        for i in range(s.DRUM_PAD_COUNT):
            name = self._drum_names.get(i, "") if self._is_drum else ""
            s._send_pad_name_sysex(self.track_id, i + 1, name)

            try:
                self._send_pad_meta(i)
            except Exception as e:
                s.log_message(
                    "PrismScript: pad meta send failed track=%d pad=%d: %s"
                    % (self.track_id, i, str(e))
                )

# ============================================================
# PrismScript — ControlSurface shell + handshake + transport +
#               link registry + SysEx I/O
# ============================================================

class PrismScript(ControlSurface):

    DEBUG = False  # gates the verbose drum-check logging

    # Temporary test switch for a machine with M4L. Set False and restart Live
    # to restore automatic detection. Keep Bridge lookup intact so saved/late
    # devices can still be disabled on script-only tracks.
    FORCE_SCRIPT_ONLY = False

    # --- SysEx ---
    SYSEX_MANUFACTURER_ID = 0x7D
    SYSEX_MSG_LABEL = 0x01
    SYSEX_MSG_TRACK_NAME = 0x02
    SYSEX_MSG_TRACK_COLOR = 0x03
    SYSEX_MSG_PAD_NAME = 0x04
    SYSEX_MSG_TRANSPORT = 0x05
    SYSEX_MSG_TRANSPORT_CMD = 0x06
    SYSEX_MSG_PAD_META = 0x07
    SYSEX_MSG_PING = 0x10
    SYSEX_MSG_PONG = 0x11
    SYSEX_MSG_PARAM_BATCH = 0x20
    SYSEX_MSG_TRACK_MODE_SET = 0x21     # Prism -> script
    SYSEX_MSG_TRACK_MODE_STATUS = 0x22  # script -> Prism
    SYSEX_MSG_SIMPLER_SNAPSHOT = 0x24   # script -> Prism, preset/load-state only
    SYSEX_MSG_WAVEFORM_REQUEST = 0x25    # Prism -> script: temporary Simpler Lab
    SYSEX_MSG_WAVEFORM_RESPONSE = 0x26   # script -> Prism: Lab state/waveform responses
    SYSEX_MSG_SNAPSHOT_COMMIT = 0x29
    SYSEX_MSG_SNAPSHOT_ADOPTED = 0x2A
    SYSEX_MSG_RESYNC_REQUEST = 0x2B     # script -> Prism: "send me your mask"

    # Simpler waveform request command.
    SIMPLER_LAB_CMD_GET = 0x01

    WAVEFORM_RESP_META = 0x01
    WAVEFORM_RESP_CHUNK = 0x02
    WAVEFORM_RESP_END = 0x03
    WAVEFORM_RESP_NAME = 0x04
    WAVEFORM_RESP_CONTEXT = 0x05       # invalidate one track before a reconnect/retarget sweep
    WAVEFORM_RESP_ERROR = 0x7F

    WAVEFORM_BIN_COUNT = 256
    WAVEFORM_CHUNK_BINS = 32
    WAVEFORM_CACHE_MAX = 128   # decoded files kept (~25 KB each)

    SIMPLER_SNAPSHOT_PARAM_COUNT = 24
    CC_SIMPLER_ADDRESS = 117
    CC_SIMPLER_VALUE_BANK_0 = 118
    CC_SIMPLER_VALUE_BANK_2 = 120



    MAX_LABEL_LENGTH = 12
    MAX_TRACK_NAME_LENGTH = 20
    MAX_PAD_NAME_LENGTH = 12

    # --- Mode status codes (0x22 byte 3) ---
    STATUS_OK = 0
    STATUS_NO_BRIDGE = 1
    STATUS_OUT_OF_RANGE = 2
    STATUS_NOT_MIDI = 3
    STATUS_INSERT_FAILED = 4
    STATUS_TRACK_MOVED = 5

    # --- Handshake ---
    PING_INTERVAL_TICKS = 20   # ~2 seconds (ticks are ~100ms)
    PING_TIMEOUT_COUNT = 5     # Disconnect after 5 missed pongs (~10s)

    # --- Transport ---
    TRANSPORT_STOPPED = 0
    TRANSPORT_PLAYING = 1
    TRANSPORT_PAUSED = 2
    TRANSPORT_CMD_STOP = 0x00
    TRANSPORT_CMD_START = 0x01
    TRANSPORT_CMD_CONTINUE = 0x02

    # --- Track selection CC ---
    CC_TRACK_SELECT = 99
    TRACK_SELECT_VALUE_OFFSET = 100

    # --- Mixer / send / drum CCs ---
    CC_VOLUME = 64
    CC_PAN = 65
    CC_SEND_A = 66
    CC_SEND_B = 67
    CC_DRUM_VOL_START = 80   # CC 80-95 = pad 1-16 volume
    CC_DRUM_PAN_START = 96   # CC 96-111 = pad 1-16 pan
    DRUM_PAD_COUNT = 16
    DRUM_PAD_NOTE_START = 36

    # --- Limits & behavior ---
    MAX_TRACKS = 16
    FEEDBACK_TOLERANCE = 1
    AUTO_SET_ONLY_FOR_MIDI_TRACKS = True

    # Activation side effects. Monitoring=In makes the track receive Prism
    # MIDI immediately regardless of arm state, without the exclusive-arm
    # trap (arming track B via the API can disarm track A when Live's
    # exclusive arm is on, breaking multi-track control).
    MONITOR_IN_ON_ACTIVATE = True
    ARM_ON_ACTIVATE = False

    # Live macro-value feedback via script listeners. OFF: the M4L device
    # sends 0x20 for manual dial turns itself (only it can distinguish manual
    # turns from Prism-driven changes like plocks/LFOs). Flip to True only as
    # a temporary fallback while the device-side feedback path is unbuilt.
    MACRO_VALUE_LISTENERS = False

    # Lazy-insert verification: after browser.load_item the device may take
    # a moment to register in the LOM. Retry finding the marker param.
    INSERT_VERIFY_DELAY_TICKS = 3    # ~300ms between checks
    INSERT_VERIFY_RETRIES = 10       # ~3s total before giving up
    PRESET_HANDOFF_WATCHDOG_TICKS = 100 # Hard ceiling on a preset/browser settle transaction (~10s).

    # MIDI From routing-type display names (matched case-insensitively).
    MIDI_FROM_ALL_INS = ("All Ins",)
    MIDI_FROM_KEYBOARD = ("Computer Keyboard",)
    CHANNEL_ALL = ("All Channels",)

    # ============================================================
    # Setup / teardown
    # ============================================================

    def __init__(self, c_instance):
        ControlSurface.__init__(self, c_instance)

        with self.component_guard():
            self._links = {}          # {prism_channel: TrackLink}
            self._desired_links = {}  # {prism_track_id: Live Track}
            self._pending = {}        # {prism_channel: {'track': Live Track, 'retries': int}}  
            self._prism_project_name = ""
            self._waveform_cache = {}  # {(path, size, mtime, bins): result}
            self._last_wave_paths = {}  # {(track, pad): sample path Prism last got a reply for}
            self._last_wave_signatures = {}  # successful replies, including file and metadata identity
            self._waveform_queue = []
            self._waveform_queue_pending = False
            self._waveform_queue_generation = 0
            self._waveform_push_session = 127
            self._bridge = BridgeManager(self)
            self._script_only = False  # Latches for new links; existing links keep their mode.
            self._bridge_discovery_checked = False
            self._routing_recovery_pending = True
            self._prism_browser = PrismBrowserConnector(self)
            self._prism_tracks = PrismTrackConnector(self)
            self._sample_lab = PrismSampleLabConnector(self)

            self._current_track_id = 0
            self._handling_selection = False
            self._suppress_selection = False       # set during bridge insert
            self._browse_handoff_track_id = None
            self._suppress_device_updates = False  # set during on-select refresh

            # Handshake
            self._connected = False
            self._ping_miss_count = 0
            self._awaiting_pong = False
            self._prism_session_id = None
            self._pending_global_resync = False
            self._pending_resync_mask = None
            self._selection_listener_added = False
            self._tracks_listener_added = False

            # Transport
            self._transport_playing_listener = None
            self._last_transport_state = None
            self._transport_from_prism = False

            self.log_message("========== PrismScript v2 LOADED (awaiting handshake) ==========")
            self._schedule_ping()
            self.show_message("PrismScript: Awaiting Prism...")

    def disconnect(self):
        self._clear_waveform_work()
        self._sample_lab.disconnect()
        self._prism_browser.reset()
        self._teardown_all_links(write_params=True, preserve_mapping=True)
        self._remove_global_listeners()
        self._connected = False
        ControlSurface.disconnect(self)

    # ============================================================
    # Handshake (Ping / Pong) — unchanged behavior
    # ============================================================

    def _schedule_ping(self):
        self.schedule_message(self.PING_INTERVAL_TICKS, self._do_ping)

    def _do_ping(self):
        if self._awaiting_pong:
            self._ping_miss_count += 1
            if self._connected and self._ping_miss_count >= self.PING_TIMEOUT_COUNT:
                self.log_message("PrismScript: Prism connection lost (missed %d pongs)"
                                 % self._ping_miss_count)
                self._deactivate()
        else:
            self._ping_miss_count = 0

        ping = (0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_PING, 0x00, 0xF7)
        try:
            self._send_midi(ping)
        except Exception:
            pass

        self._awaiting_pong = True
        self._schedule_ping()

    def _on_pong_received(self, midi_bytes=None):
        self._awaiting_pong = False
        self._ping_miss_count = 0
        # Extended PONG: F0 7D 11 01 session[u28] F7. Old five-byte
        # replies still work; new Prism processes announce a fresh token even
        # when they restart inside the missed-Pong timeout.
        session_id = None
        if midi_bytes is not None and len(midi_bytes) == 9 and midi_bytes[3] == 1:
            session_id = sum((int(midi_bytes[4 + i]) & 0x7F) << (7 * i)
                             for i in range(4)) or None
        if session_id is not None:
            previous = getattr(self, '_prism_session_id', None)
            self._prism_session_id = session_id
            if self._connected and session_id != previous:
                self.log_message("PrismScript: fresh Prism session -> reconnect/resync")
                self._pending_global_resync = False
                self._pending_resync_mask = None
                self._prism_browser.reset()
                self._deactivate()
        if not self._connected:
            self.log_message("PrismScript: Prism connected! Activating...")
            self._activate()

    def _activate(self):
        """After handshake: global listeners + transport state. NO track init —
        tracks activate only when Prism sends TRACK_MODE_SET."""
        self._connected = True
        self._routing_recovery_pending = True

        if not self._bridge_discovery_checked:
            self._bridge_discovery_checked = True
            if self.FORCE_SCRIPT_ONLY:
                self._enter_script_only("forced test mode (FORCE_SCRIPT_ONLY=True)")
            else:
                # A saved Bridge can still work even when its .amxd is absent
                # from the browser. Leave it eligible for normal activation.
                saved_bridge = any(self._bridge.find_bridge_param(t) is not None
                                   for t in self.song().tracks)
                if not saved_bridge and self._bridge._find_browser_item() is None:
                    self._enter_script_only("Prism Bridge unavailable in browser")

        if not self._selection_listener_added:
            self.song().view.add_selected_track_listener(self._on_selection_changed)
            self._selection_listener_added = True

        if not self._tracks_listener_added:
            try:
                self.song().add_tracks_listener(self._on_tracks_changed)
                self._tracks_listener_added = True
            except Exception as e:
                self.log_message("PrismScript: tracks listener failed: %s" % str(e))

        self._init_transport_listener()
        self._send_transport_state()
        self._prism_browser._session._send_set_context()
        self._prism_browser._session._send_session_info()

        if self._pending_global_resync:
            pending_mask = self._pending_resync_mask
            self._pending_global_resync = False
            self._pending_resync_mask = None

            self.log_message("PrismScript: replaying deferred GLOBAL RESYNC")

            def replay_resync(mask=pending_mask):
                self._resync_all_connected_tracks(mask)

            self.schedule_message(1, replay_resync)

        else:
            # Every (re)connect: ask Prism for its Ableton track mask. Prism
            # re-prepares its side and answers with a Resync; links this
            # script already knows are reasserted alongside Prism's mask.
            self._send_midi((0xF0, self.SYSEX_MANUFACTURER_ID,
                             self.SYSEX_MSG_RESYNC_REQUEST, 0xF7))
            self.log_message("PrismScript: connect -> requested Prism resync")

        self.show_message("PrismScript: Connected (script-only fallback enabled)"
                          if self._script_only else
                          "PrismScript: Connected (awaiting track modes)")
        self.log_message("========== PrismScript ACTIVATED ==========")

    def _enter_script_only(self, reason):
        if self._script_only:
            return
        self._script_only = True
        self.log_message("PrismScript: SCRIPT-ONLY mode latched (%s)" % reason)
        self.show_message("PrismScript: Script-only control (Bridge unavailable)")

    def _deactivate(self):
        """Connection lost: close every link. write_params=True matters — a
        dead connection must not leave live.remote~ bound (macros locked)."""
        self._clear_waveform_work()
        self._sample_lab.disconnect()
        self._connected = False
        self._last_transport_state = None
        self._transport_from_prism = False
        self._pending.clear()

        self._teardown_all_links(write_params=True, preserve_mapping=True)
        self._remove_transport_listener()

        self.show_message("PrismScript: Disconnected")
        self.log_message("========== PrismScript DEACTIVATED ==========")

    def _teardown_all_links(self, write_params, preserve_mapping=False):
        for tid in list(self._links.keys()):
            link = self._links.pop(tid)
            try:
                link.deactivate(write_param=write_params, preserve_mapping=preserve_mapping)
            except Exception as e:
                self.log_message("PrismScript: error closing link %d: %s" % (tid, str(e)))

    def _remove_global_listeners(self):
        if self._selection_listener_added:
            try:
                self.song().view.remove_selected_track_listener(self._on_selection_changed)
            except Exception:
                pass
            self._selection_listener_added = False
        if self._tracks_listener_added:
            try:
                self.song().remove_tracks_listener(self._on_tracks_changed)
            except Exception:
                pass
            self._tracks_listener_added = False
        self._remove_transport_listener()

    # ============================================================
    # Track mode: activation / deactivation driven by Prism
    # ============================================================

    def _resync_all_connected_tracks(self, prism_mask=None):
        if not self._connected:
            self._pending_global_resync = True
            self._pending_resync_mask = prism_mask
            self.log_message("PrismScript: GLOBAL RESYNC deferred until handshake mask=%s" %
                            ("None" if prism_mask is None else "0x%04X" % (int(prism_mask) & 0xFFFF)))
            return

        try:
            tracks = list(self.song().tracks)
        except Exception:
            return

        if prism_mask is not None:
            prism_mask = int(prism_mask) & 0xFFFF
            recovered = {}

            for track in tracks:
                try:
                    if not bool(getattr(track, 'has_midi_input', False)):
                        continue
                except Exception:
                    continue

                if self._script_only:
                    if not self._midi_from_is(track, self.MIDI_FROM_ALL_INS):
                        continue
                    prism_id = self._routed_prism_track_id(track)
                elif self._bridge.find_bridge_param(track) is not None:
                    prism_id = self._saved_prism_track_id(track)
                else:
                    # A Set saved without M4L has no marker device. Recover
                    # its routing even if a Bridge is available on this machine.
                    if not self._midi_from_is(track, self.MIDI_FROM_ALL_INS):
                        continue
                    prism_id = self._routed_prism_track_id(track)
                if prism_id is None or not (prism_mask & (1 << prism_id)):
                    continue

                if prism_id in recovered:
                    self.log_message("PrismScript: GLOBAL RESYNC duplicate saved routing P%d" % prism_id)
                    recovered[prism_id] = None
                    continue

                recovered[prism_id] = track

            # Resync only ever ADDS. Known pairings win over recovered ones.
            for track_id, target in recovered.items():
                if target is None or track_id in self._desired_links:
                    continue

                self._desired_links[track_id] = target
                self.log_message("PrismScript: GLOBAL RESYNC recovered P%d -> '%s'" %
                                (track_id, getattr(target, 'name', '?')))

            # All recoverable targets are registered before any activation's
            # routing sweep runs, including targets still awaiting insertion.
            self._routing_recovery_pending = False

        # Everything currently linked is reasserted too.
        for track_id, link in self._links.items():
            self._desired_links.setdefault(track_id, link.track)

        # Fail-safe: drop any stuck preset/browser transaction before reasserting.
        self._browse_handoff_track_id = None
        for link in self._links.values():
            link.cancel_macro_handoff()

        desired = sorted(self._desired_links.items(), key=lambda x: x[0])

        self.log_message("PrismScript: GLOBAL RESYNC desired=%s active=%s" %
                        (str([x[0] for x in desired]), str(sorted(self._links.keys()))))

        for track_id, target in desired:
            try:
                live_index = next((i for i, track in enumerate(tracks) if track == target), None)
            except Exception:
                live_index = None

            if live_index is None:
                self.log_message("PrismScript: GLOBAL RESYNC target missing prism=%d" % track_id)
                self._desired_links.pop(track_id, None)
                self._send_mode_status(track_id, 0, self.STATUS_TRACK_MOVED)
                continue

            ok, code, text = self._connect_prism_to_live_track(track_id, live_index)

            if not ok:
                self.log_message("PrismScript: GLOBAL RESYNC FAILED prism=%d live=%d code=%d text='%s'" %
                                (track_id, live_index, code, text))

    def _on_track_mode_set(self, track_id, mode):
        if not self._connected:
            return

        if not (0 <= track_id < self.MAX_TRACKS):
            self._send_mode_status(track_id, 0, self.STATUS_OUT_OF_RANGE)
            return

        if mode == 0:
            self._deactivate_track(track_id)
            self._send_mode_status(track_id, 0, self.STATUS_OK)
            return

        # --- mode == 1 ---

        if track_id in self._links:
            link = self._links[track_id]
            if not link.reassert_connection(
                on_ready=lambda tid=track_id: self._send_mode_status(tid, 1, self.STATUS_OK)
            ):
                self._send_mode_status(track_id, 0, self.STATUS_INSERT_FAILED)
            return

        if track_id in self._pending:
            return  # insert already in flight; verify loop will ack

        tracks = list(self.song().tracks)
        if track_id >= len(tracks):
            self._send_mode_status(track_id, 0, self.STATUS_OUT_OF_RANGE)
            return
        track = tracks[track_id]

        if self.AUTO_SET_ONLY_FOR_MIDI_TRACKS:
            try:
                if not getattr(track, 'has_midi_input', False):
                    self._send_mode_status(track_id, 0, self.STATUS_NOT_MIDI)
                    return
            except Exception:
                self._send_mode_status(track_id, 0, self.STATUS_NOT_MIDI)
                return

        if self._script_only or self._bridge.find_bridge_param(track) is not None:
            self._finish_activation(track_id, track)
            return

        # Lazy insert
        if not self._bridge.insert_bridge(track):
            self._enter_script_only("Prism Bridge insertion failed")
            self._finish_activation(track_id, track)
            return

        self._pending[track_id] = {
            'track': track,
            'retries': self.INSERT_VERIFY_RETRIES,
            'on_ready': None
        }

        def cb(tid=track_id):
            self._verify_pending(tid)
        self.schedule_message(self.INSERT_VERIFY_DELAY_TICKS, cb)

    def _connect_prism_to_live_track(self, prism_track_id, live_track_index, on_ready=None):
        """Authoritatively establish Prism track -> specific Ableton MIDI track."""
        if not self._connected:
            return False, PrismTrackConnector.ERR_CONNECT, "Prism is not connected"
        if not (0 <= prism_track_id < self.MAX_TRACKS):
            return False, PrismTrackConnector.ERR_PRISM_TRACK, "Prism track out of range"

        try:
            tracks = list(self.song().tracks)
        except Exception:
            return False, PrismTrackConnector.ERR_LIVE_TRACK, "Could not read Ableton tracks"

        if live_track_index < 0 or live_track_index >= len(tracks):
            return False, PrismTrackConnector.ERR_LIVE_TRACK, "Ableton track not found"

        target = tracks[live_track_index]

        try:
            if not bool(getattr(target, 'has_midi_input', False)):
                return False, PrismTrackConnector.ERR_NOT_MIDI, "Target is not a MIDI track"
        except Exception:
            return False, PrismTrackConnector.ERR_NOT_MIDI, "Target is not a MIDI track"

        self._desired_links[prism_track_id] = target

        pending = self._pending.get(prism_track_id)
        if pending is not None and pending.get('track') == target:
            pending['on_ready'] = on_ready
            self._verify_pending(prism_track_id)
            return True, 0, ""

        pending = self._pending.pop(prism_track_id, None)
        if pending is not None:
            try:
                self._bridge.set_bridge_active(pending.get('track'), False)
            except Exception:
                pass

        for other_prism, other_pending in list(self._pending.items()):
            if other_prism == prism_track_id:
                continue
            if other_pending.get('track') == target:
                self._pending.pop(other_prism, None)
                self._desired_links.pop(other_prism, None)
                self._send_mode_status(other_prism, 0, self.STATUS_OK)

        target_owner = self._get_link_for_track(target)
        if target_owner is not None and target_owner.track_id != prism_track_id:
            old_prism = target_owner.track_id
            self.log_message("PrismScript: connection overwrite Live '%s' P%d -> P%d" % (getattr(target, 'name', '?'), old_prism, prism_track_id))
            self._links.pop(old_prism, None)
            self._pending.pop(old_prism, None)
            self._desired_links.pop(old_prism, None)
            target_owner.deactivate(write_param=True)
            self._send_mode_status(old_prism, 0, self.STATUS_OK)

        current = self._links.get(prism_track_id)

        if current is not None:
            if current.track == target:
                def reasserted(tid=prism_track_id, cb=on_ready):
                    self._send_mode_status(tid, 1, self.STATUS_OK)
                    if cb is not None:
                        cb()

                if not current.reassert_connection(on_ready=reasserted):
                    return False, PrismTrackConnector.ERR_CONNECT, "Could not refresh connection"
                return True, 0, ""

            self.log_message("PrismScript: Prism P%d retarget '%s' -> '%s'" % (
                prism_track_id,
                getattr(current.track, 'name', '?'),
                getattr(target, 'name', '?')
            ))
            self._links.pop(prism_track_id, None)
            current.deactivate(write_param=True)

        if self._script_only or self._bridge.find_bridge_param(target) is not None:
            self._finish_activation(prism_track_id, target, on_ready=on_ready)
            return True, 0, ""

        if not self._bridge.insert_bridge(target):
            self._enter_script_only("Prism Bridge insertion failed")
            self._finish_activation(prism_track_id, target, on_ready=on_ready)
            return True, 0, ""

        self._pending[prism_track_id] = {
            'track': target,
            'retries': self.INSERT_VERIFY_RETRIES,
            'on_ready': on_ready
        }

        def cb(tid=prism_track_id):
            self._verify_pending(tid)

        self.schedule_message(self.INSERT_VERIFY_DELAY_TICKS, cb)
        return True, 0, ""

    def _verify_pending(self, track_id):
        pending = self._pending.get(track_id)
        if pending is None:
            return

        if not self._connected:
            self._pending.pop(track_id, None)
            return

        track = pending['track']

        try:
            tracks = list(self.song().tracks)
            still_exists = any(t == track for t in tracks)
        except Exception:
            still_exists = False

        if not still_exists:
            self._pending.pop(track_id, None)
            self.log_message("PrismScript: pending Prism channel %d target track deleted" % track_id)
            self._send_mode_status(track_id, 0, self.STATUS_TRACK_MOVED)
            return

        if self._script_only or self._bridge.find_bridge_param(track) is not None:
            self._pending.pop(track_id, None)
            self._finish_activation(track_id, track, on_ready=pending.get('on_ready'))
            return

        pending['retries'] -= 1

        if pending['retries'] <= 0:
            self._pending.pop(track_id, None)
            self.log_message("PrismScript: bridge never appeared for Prism channel %d" % track_id)
            self._enter_script_only("Prism Bridge verification timed out")
            self._finish_activation(track_id, track, on_ready=pending.get('on_ready'))
            return

        def cb(tid=track_id):
            self._verify_pending(tid)

        self.schedule_message(self.INSERT_VERIFY_DELAY_TICKS, cb)

    def _finish_activation(self, track_id, track, on_ready=None):
        self._desired_links[track_id] = track
        link = TrackLink(self, track_id, track, script_only=self._script_only)

        def ready(tid=track_id, expected_link=link):
            # Do not ACK an activation that disappeared/replaced before the
            # scheduled control-ready callback.
            if self._links.get(tid) is not expected_link:
                return

            empty = self._find_first_instrument_device(expected_link.track) is None
            self._send_mode_status(
                tid,
                1,
                self.STATUS_OK,
                1 if empty else 0
            )

            if on_ready is not None:
                try:
                    on_ready()
                except Exception as e:
                    self.log_message("PrismScript: connection ready callback failed: %s" % str(e))

        try:
            link.activate(on_ready=ready)
        
            if self._prism_project_name and not link.script_only:
                self._bridge.set_bridge_project_name(
                    track,
                    self._prism_project_name
                )

        except BridgeUnavailable as e:
            link.deactivate(write_param=True, preserve_mapping=True)
            self._enter_script_only(str(e))
            self._finish_activation(track_id, track, on_ready=on_ready)
            return

        except Exception as e:
            self.log_message(
                "PrismScript: activation FAILED on track %d: %s"
                % (track_id, str(e))
            )

            try:
                link.deactivate(write_param=False)
            except Exception:
                pass

            self._send_mode_status(
                track_id,
                0,
                self.STATUS_INSERT_FAILED
            )
            return

        # Control readiness and waveform work both start on a scheduled tick,
        # so this registry entry exists before either can run.
        self._links[track_id] = link


    def _deactivate_track(self, track_id):
        self._desired_links.pop(track_id, None)
        link = self._links.pop(track_id, None)

        if link is not None:
            link.deactivate(write_param=True)
            return

        pending = self._pending.pop(track_id, None)

        if pending is not None:
            try:
                self._bridge.set_bridge_active(pending['track'], False)
            except Exception:
                pass

    def _on_bridge_lost(self, track_id):
        """Bridge device was deleted from an active track."""
        self.log_message("PrismScript: bridge REMOVED from track %d, closing link"
                         % track_id)
        link = self._links.pop(track_id, None)
        if link is not None:
            link.deactivate(write_param=False)
        self._send_mode_status(track_id, 0, self.STATUS_NO_BRIDGE)


    def _send_mode_status(self, track_id, mode, status, flags=0):
        # flags bit 0: connected Live track has no instrument
        if not self._connected:
            return
        sysex = (0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_TRACK_MODE_STATUS,
                 track_id & 0x7F, mode & 0x7F, status & 0x7F, flags & 0x7F, 0xF7)
        self._send_midi(sysex)
        self.log_message("PrismScript: mode status -> track %d mode %d status %d"
                         % (track_id, mode, status))

    def _send_snapshot_commit(self, track_id, generation):
        generation = int(generation) & 0x3FFF

        if generation == 0:
            return

        self._send_midi((
            0xF0,
            0x7D,
            self.SYSEX_MSG_SNAPSHOT_COMMIT,
            track_id & 0x7F,
            generation & 0x7F,
            (generation >> 7) & 0x7F,
            0xF7
        ))

        self.log_message(
            "PrismScript: SNAPSHOT_COMMIT -> track=%d gen=%d"
            % (track_id, generation)
        )

    # ============================================================
    # Track list changes (reorder / delete)
    # ============================================================

    def _on_tracks_changed(self):
        """Ableton track position may change. Prism ownership stays attached to the
        original Live Track object. Only delete a link if that Track itself is gone."""
        if not self._connected:
            return

        try:
            tracks = list(self.song().tracks)
        except Exception:
            return

        for tid, target in list(self._desired_links.items()):
            if not any(t == target for t in tracks):
                self._desired_links.pop(tid, None)

        # Active connections
        for tid in list(self._links.keys()):
            link = self._links[tid]
            still_exists = any(t == link.track for t in tracks)

            if not still_exists:
                self.log_message("PrismScript: Prism channel %d target track deleted" % tid)
                self._links.pop(tid, None)

                try:
                    link.deactivate(write_param=False)
                except Exception:
                    pass

                self._send_mode_status(tid, 0, self.STATUS_TRACK_MOVED)

        # Bridge insertions still in flight
        for tid in list(self._pending.keys()):
            pending = self._pending[tid]
            target = pending['track']
            still_exists = any(t == target for t in tracks)

            if not still_exists:
                self.log_message("PrismScript: pending Prism channel %d target track deleted" % tid)
                self._pending.pop(tid, None)
                self._send_mode_status(tid, 0, self.STATUS_TRACK_MOVED)

    # ============================================================
    # Transport — unchanged behavior
    # ============================================================

    def _init_transport_listener(self):
        try:
            if self._transport_playing_listener is not None:
                return
            self._transport_playing_listener = self._on_transport_changed
            self.song().add_is_playing_listener(self._transport_playing_listener)
        except Exception as e:
            self.log_message("PrismScript: transport listener failed: %s" % str(e))
            self._transport_playing_listener = None

    def _remove_transport_listener(self):
        try:
            if self._transport_playing_listener is not None:
                self.song().remove_is_playing_listener(self._transport_playing_listener)
        except Exception:
            pass
        self._transport_playing_listener = None

    def _on_transport_changed(self):
        if self._transport_from_prism:
            return
        self._send_transport_state()

    def _get_transport_state(self):
        try:
            return self.TRANSPORT_PLAYING if self.song().is_playing \
                else self.TRANSPORT_STOPPED
        except Exception:
            return self.TRANSPORT_STOPPED

    def _send_transport_state(self):
        if not self._connected:
            return
        state = self._get_transport_state()
        if state == self._last_transport_state:
            return
        self._last_transport_state = state
        sysex = (0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_TRANSPORT,
                 state & 0x7F, 0xF7)
        self._send_midi(sysex)

    def _on_transport_command(self, command):
        if not self._connected:
            return
        self._transport_from_prism = True
        try:
            if command == self.TRANSPORT_CMD_STOP:
                self.song().is_playing = False
                self._last_transport_state = self.TRANSPORT_STOPPED
            elif command == self.TRANSPORT_CMD_START:
                self.song().current_song_time = 0.0
                self.song().is_playing = True
                self._last_transport_state = self.TRANSPORT_PLAYING
            elif command == self.TRANSPORT_CMD_CONTINUE:
                self.song().is_playing = True
                self._last_transport_state = self.TRANSPORT_PLAYING
            else:
                self.log_message("PrismScript: unknown transport cmd 0x%02X" % command)
        except Exception as e:
            self.log_message("PrismScript: transport cmd error: %s" % str(e))
        finally:
            self.schedule_message(1, self._clear_transport_suppression)

    def _clear_transport_suppression(self):
        self._transport_from_prism = False

    # ============================================================
    # MIDI in
    # ============================================================

    def build_midi_map(self, midi_map_handle):
        ControlSurface.build_midi_map(self, midi_map_handle)

        script_handle = self._c_instance.handle()

        for channel in range(self.MAX_TRACKS):
            for cc in range(
                self.CC_DRUM_VOL_START,
                self.CC_DRUM_PAN_START + self.DRUM_PAD_COUNT
            ):
                Live.MidiMap.forward_midi_cc(
                    script_handle,
                    midi_map_handle,
                    channel,
                    cc
                )

        for channel, link in list(self._links.items()):
            if link.script_only and not link._detached:
                for cc in list(range(1, 17)) + list(range(117, 121)):
                    Live.MidiMap.forward_midi_cc(
                        script_handle, midi_map_handle, channel, cc)

    def receive_midi(self, midi_bytes):
        # Legacy Drum Rack chain mixer:
        # raw CC80-95 = pad volumes, CC96-111 = pad pans.
        if len(midi_bytes) >= 3 and (midi_bytes[0] & 0xF0) == 0xB0:
            channel = midi_bytes[0] & 0x0F
            cc = midi_bytes[1] & 0x7F
            value = midi_bytes[2] & 0x7F

            if (1 <= cc <= 16
                    or self.CC_SIMPLER_ADDRESS <= cc <= self.CC_SIMPLER_VALUE_BANK_2):
                link = self._links.get(channel)
                if link is not None and link.script_only:
                    link.handle_cc(cc, value)
                return

            if self.CC_DRUM_VOL_START <= cc < self.CC_DRUM_PAN_START + self.DRUM_PAD_COUNT:
                link = self._links.get(channel)
                if link is not None:
                    link.handle_cc(cc, value)
                return

        if len(midi_bytes) < 5:
            return
        if midi_bytes[0] != 0xF0 or midi_bytes[1] != self.SYSEX_MANUFACTURER_ID:
            return

        msg_type = midi_bytes[2]

        if msg_type == PrismTrackConnector.REQUEST_TYPE:
            self._prism_tracks.receive(midi_bytes)

        elif msg_type == PrismSampleLabConnector.REQUEST_TYPE:
            self._sample_lab.receive(midi_bytes)

        elif msg_type == PrismBrowserConnector.REQUEST_TYPE:
            self._prism_browser.receive(midi_bytes)

        elif msg_type == self.SYSEX_MSG_PONG:
            self._on_pong_received(midi_bytes)

        elif msg_type == self.SYSEX_MSG_TRANSPORT_CMD:
            self._on_transport_command(midi_bytes[3])

        elif msg_type == self.SYSEX_MSG_TRACK_MODE_SET:
            if len(midi_bytes) >= 6:
                self._on_track_mode_set(midi_bytes[3], midi_bytes[4])

        elif msg_type == self.SYSEX_MSG_SNAPSHOT_ADOPTED:
            if len(midi_bytes) >= 7:
                track_id = int(midi_bytes[3]) & 0x7F
                generation = (int(midi_bytes[4]) & 0x7F) | ((int(midi_bytes[5]) & 0x7F) << 7)
                link = self._links.get(track_id)
                if link is not None:
                    link.handle_snapshot_adopted(generation)

        elif msg_type == self.SYSEX_MSG_WAVEFORM_REQUEST:
            if not self._connected:
                return

            # Current waveform request:
            # F0 7D 25 command track pad arg0 arg1 sessionID F7
            if len(midi_bytes) >= 10:
                command = int(midi_bytes[3]) & 0x7F
                track_id = int(midi_bytes[4]) & 0x7F
                pad_index = int(midi_bytes[5]) & 0x7F
                session_id = int(midi_bytes[8]) & 0x7F


                if command == self.SIMPLER_LAB_CMD_GET:
                    self._schedule_simpler_waveform_response(
                        track_id,
                        pad_index,
                        session_id,
                        self.WAVEFORM_BIN_COUNT
                    )

        elif msg_type == self.SYSEX_MSG_PARAM_BATCH:
            if not self._connected:
                return
            if len(midi_bytes) < 7:
                return

            track_id = midi_bytes[3]
            count = midi_bytes[4]
            link = self._links.get(track_id)

            for i in range(count):
                offset = 5 + (i * 2)
                if offset + 1 >= len(midi_bytes):
                    break

                cc = midi_bytes[offset]
                value = midi_bytes[offset + 1]

                if cc == self.CC_TRACK_SELECT:
                    if self.TRACK_SELECT_VALUE_OFFSET <= value <= self.TRACK_SELECT_VALUE_OFFSET + 15:
                        self._select_track_by_id(value - self.TRACK_SELECT_VALUE_OFFSET)
                    continue

                if link is not None:
                    link.handle_cc(cc, value)

    # ============================================================
    # Selection
    # ============================================================

    def _get_link_for_track(self, track):
        if track is None:
            return None
        for link in self._links.values():
            try:
                if link.track == track:
                    return link
            except Exception:
                pass
        return None

    def _on_selection_changed(self):
        if not self._connected or self._handling_selection or self._suppress_selection:
            return

        self._handling_selection = True
        self._suppress_device_updates = True

        try:
            track = self.song().view.selected_track
            link = self._get_link_for_track(track)

            if link is None:
                self._current_track_id = self._get_track_id(track)
                self._fix_unlinked_track(track)
                return

            self._current_track_id = link.track_id
            link.on_selected()

        finally:
            self._handling_selection = False
            self._suppress_device_updates = False
            try:
                self._prism_tracks.send_selection()
            except Exception:
                pass

    def _get_track_id(self, track):
        if track is None:
            return 0
        if track == self.song().master_track:
            return 127
        try:
            for i, t in enumerate(self.song().tracks):
                if t == track:
                    return min(i, 126)
        except Exception:
            pass
        try:
            num_tracks = len(list(self.song().tracks))
            for i, t in enumerate(self.song().return_tracks):
                if t == track:
                    return min(num_tracks + i, 126)
        except Exception:
            pass
        return 0

    def _select_track_by_id(self, track_id):
        if self._handling_selection:
            return True

        try:
            link = self._links.get(track_id)

            if link is not None and not link._detached:
                self.song().view.selected_track = link.track
                return True

            tracks = list(self.song().tracks)

            if track_id == 127:
                self.song().view.selected_track = self.song().master_track
                return True

            if 0 <= track_id < len(tracks):
                self.song().view.selected_track = tracks[track_id]
                return True

            returns = list(self.song().return_tracks)
            return_index = track_id - len(tracks)

            if 0 <= return_index < len(returns):
                self.song().view.selected_track = returns[return_index]
                return True

            return False

        except Exception as e:
            self.log_message("PrismScript: error selecting track: %s" % str(e))
            return False

    def set_prism_project_name(self, name):
        clean = str(name or "").strip()

        if not clean:
            return

        self._prism_project_name = clean

        updated = 0

        for track_id, link in list(self._links.items()):
            if link.script_only:
                continue
            try:
                if self._bridge.set_bridge_project_name(link.track, clean):
                    updated += 1
            except Exception as e:
                self.log_message(
                    "PrismScript: project-name update failed track=%d: %s"
                    % (track_id, str(e))
                )

        self.log_message(
            "PrismScript: Prism project='%s' bridges=%d"
            % (clean, updated)
        )

    # ============================================================
    # Input-routing helpers
    # ============================================================

    def _routing_obj_id(self, routing_obj):
        try:
            if routing_obj is None:
                return ''
            if isinstance(routing_obj, dict):
                return str(routing_obj.get('identifier', ''))
            return str(getattr(routing_obj, 'identifier', ''))
        except Exception:
            return ''

    def _routing_obj_name(self, routing_obj):
        try:
            if routing_obj is None:
                return ''
            if isinstance(routing_obj, dict):
                return str(routing_obj.get('display_name', ''))
            return str(getattr(routing_obj, 'display_name', ''))
        except Exception:
            return ''

    def _pick_input_channel_routing_obj(self, track, target_channel_1_16):
        try:
            avail = list(getattr(track, 'available_input_routing_channels', []))
        except Exception:
            avail = []
        if not avail:
            return None

        target_id = str(int(target_channel_1_16))

        for ro in avail:
            if self._routing_obj_id(ro) == target_id:
                return ro
        for ro in avail:
            name = self._routing_obj_name(ro).strip()
            if not name:
                continue
            if name == target_id:
                return ro
            if (" %s" % target_id) in (" " + name) or name.endswith(target_id):
                return ro
        return None

    def _auto_set_track_input_channel(self, track, track_id):
        """Set track's MIDI input channel to index+1. Only ever called for
        tracks being activated / already linked."""
        if track is None or not (0 <= track_id < self.MAX_TRACKS):
            return
        if self.AUTO_SET_ONLY_FOR_MIDI_TRACKS:
            try:
                if not getattr(track, 'has_midi_input', False):
                    return
            except Exception:
                return

        target_channel = track_id + 1

        try:
            current_id = self._routing_obj_id(
                getattr(track, 'input_routing_channel', None))
        except Exception:
            current_id = ''

        desired = self._pick_input_channel_routing_obj(track, target_channel)
        if desired is None:
            return
        desired_id = self._routing_obj_id(desired)
        if desired_id and desired_id == current_id:
            return
        try:
            track.input_routing_channel = desired
        except Exception as e:
            self.log_message("PrismScript: failed setting track %d input channel: %s"
                             % (track_id, str(e)))

    def _saved_prism_track_id(self, track):
        # Bridges with __PrismTrack__ are authoritative (0 = unassigned).
        if self._bridge.find_track_id_param(track) is not None:
            return self._bridge.get_prism_track_id(track)

        return self._routed_prism_track_id(track)

    def _routed_prism_track_id(self, track):
        """Routing-only identity deliberately ignores any stale Bridge marker."""
        try:
            current = track.input_routing_channel
        except Exception:
            return None

        current_id = self._routing_obj_id(current)
        current_name = self._routing_obj_name(current).strip().lower()

        for track_id in range(self.MAX_TRACKS):
            candidate = self._pick_input_channel_routing_obj(track, track_id + 1)
            if candidate is None:
                continue

            candidate_id = self._routing_obj_id(candidate)
            candidate_name = self._routing_obj_name(candidate).strip().lower()

            if current_id and candidate_id and current_id == candidate_id:
                return track_id

            if current_name and candidate_name and current_name == candidate_name:
                return track_id

        return None

    # ---- MIDI From (input_routing_type) ----

    def _pick_input_routing_type(self, track, wanted_names):
        try:
            avail = list(getattr(track, 'available_input_routing_types', []))
        except Exception:
            return None
        wanted = [w.lower() for w in wanted_names]
        for ro in avail:
            if self._routing_obj_name(ro).strip().lower() in wanted:
                return ro
        return None

    def _midi_from_is(self, track, wanted_names):
        try:
            current = self._routing_obj_name(
                getattr(track, 'input_routing_type', None)).strip().lower()
        except Exception:
            return False
        return current in [w.lower() for w in wanted_names]

    def _set_midi_from(self, track, wanted_names):
        if self._midi_from_is(track, wanted_names):
            return True
        ro = self._pick_input_routing_type(track, wanted_names)
        if ro is None:
            try:
                names = [self._routing_obj_name(r) for r in
                         getattr(track, 'available_input_routing_types', [])]
            except Exception:
                names = []
            self.log_message(
                "PrismScript: MIDI-From type %s not found on '%s' (available: %s)"
                % (list(wanted_names), getattr(track, 'name', '?'), names))
            return False
        try:
            track.input_routing_type = ro
            return True
        except Exception as e:
            self.log_message("PrismScript: failed setting MIDI From on '%s': %s"
                             % (getattr(track, 'name', '?'), str(e)))
            return False

    # ---- Channel (All Channels for unlink) ----

    def _pick_input_channel_by_name(self, track, wanted_names):
        try:
            avail = list(getattr(track, 'available_input_routing_channels', []))
        except Exception:
            return None
        wanted = [w.lower() for w in wanted_names]
        for ro in avail:
            if self._routing_obj_name(ro).strip().lower() in wanted:
                return ro
        return None

    def _set_input_channel_all(self, track):
        ro = self._pick_input_channel_by_name(track, self.CHANNEL_ALL)
        if ro is None:
            self.log_message("PrismScript: 'All Channels' not found on '%s'"
                             % getattr(track, 'name', '?'))
            return
        try:
            track.input_routing_channel = ro
        except Exception as e:
            self.log_message("PrismScript: failed setting All Channels on '%s': %s"
                             % (getattr(track, 'name', '?'), str(e)))

    # ---- Unlinked-track hygiene ----

    def _protect_pending_routing(self, track):
        if any(t == track for t in self._desired_links.values()):
            return True
        if any(p.get('track') == track for p in self._pending.values()):
            return True
        # Until Prism supplies its mask, a routed track may be a saved link.
        return (self._routing_recovery_pending
                and self._midi_from_is(track, self.MIDI_FROM_ALL_INS)
                and self._routed_prism_track_id(track) is not None)

    def _fix_unlinked_track(self, track):
        """On-select hygiene for non-linked tracks: clear All Ins contamination
        only. Never touches monitor or channel."""
        if track is None:
            return
        try:
            if track == self.song().master_track:
                return
            if not getattr(track, 'has_midi_input', False):
                return
        except Exception:
            return

        # Bridge tracks are Prism-owned; their routing is their pairing.
        if self._bridge.find_bridge_device(track) is not None:
            return

        if self._protect_pending_routing(track):
            return

        if self._midi_from_is(track, self.MIDI_FROM_ALL_INS):
            if self._set_midi_from(track, self.MIDI_FROM_KEYBOARD):
                self.log_message("PrismScript: cleared All Ins on unlinked track '%s'"
                                 % getattr(track, 'name', '?'))

    def _sweep_unlinked_midi_from(self, exclude_track=None):
        """Move any non-linked MIDI track off All Ins (-> Computer Keyboard)
        so it can't pick up Prism-controlled traffic. Runs at activation."""
        linked = [link.track for link in self._links.values()]
        if exclude_track is not None:
            linked.append(exclude_track)
        try:
            tracks = list(self.song().tracks)
        except Exception:
            return
        for t in tracks:
            if any(t == lt for lt in linked):
                continue
            try:
                if not getattr(t, 'has_midi_input', False):
                    continue
            except Exception:
                continue

            # Bridge tracks are Prism-owned (possibly awaiting reconnect).
            # Moving their MIDI From resets the channel, so leave them alone.
            if self._bridge.find_bridge_device(t) is not None:
                continue
            if self._protect_pending_routing(t):
                continue
            if self._midi_from_is(t, self.MIDI_FROM_ALL_INS):
                if self._set_midi_from(t, self.MIDI_FROM_KEYBOARD):
                    self.log_message(
                        "PrismScript: moved unlinked track '%s' off All Ins"
                        % getattr(t, 'name', '?'))

    # ============================================================
    # Parameter <-> CC conversion — unchanged behavior
    # ============================================================

    def _set_param_from_cc(self, param, value_0_127):
        try:
            pmin = param.min
            pmax = param.max
            param.value = pmin + (pmax - pmin) * (value_0_127 / 127.0)
        except Exception as e:
            self.log_message("PrismScript: error setting param: %s" % str(e))

    def _param_to_cc_value(self, param):
        try:
            pmin = param.min
            pmax = param.max
            if pmax == pmin:
                return 0
            v = int(round((param.value - pmin) / (pmax - pmin) * 127.0))
            return max(0, min(127, v))
        except Exception:
            return 0

    def _values_close(self, a, b):
        if a is None or b is None:
            return False
        try:
            return abs(int(a) - int(b)) <= self.FEEDBACK_TOLERANCE
        except Exception:
            return False

    def _send_cc_for_track(self, track_id, cc_number, value):
        if not self._connected:
            return
        sysex = (0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_PARAM_BATCH,
                 track_id & 0x7F, 1, cc_number & 0x7F, value & 0x7F, 0xF7)
        self._send_midi(sysex)

    def _send_simpler_snapshot_pad(
        self,
        track_id,
        pad_index,
        presence_mask,
        values,
        snapshot_generation=0
    ):
        if not self._connected:
            return

        vals = list(values[:self.SIMPLER_SNAPSHOT_PARAM_COUNT])

        while len(vals) < self.SIMPLER_SNAPSHOT_PARAM_COUNT:
            vals.append(0)

        # Normal:
        # F0 7D 24 track pad mask0 mask1 mask2 mask3 values[24] F7
        #
        # Final transaction pad:
        # F0 7D 24 track pad mask0 mask1 mask2 mask3 values[24]
        #    genLo genHi F7
        sysex = [
            0xF0,
            self.SYSEX_MANUFACTURER_ID,
            self.SYSEX_MSG_SIMPLER_SNAPSHOT,
            track_id & 0x7F,
            pad_index & 0x7F,
            presence_mask & 0x7F,
            (presence_mask >> 7) & 0x7F,
            (presence_mask >> 14) & 0x7F,
            (presence_mask >> 21) & 0x07
        ]

        for value in vals:
            sysex.append(max(0, min(127, int(value))))

        generation = int(snapshot_generation) & 0x3FFF

        if generation != 0:
            sysex.append(generation & 0x7F)
            sysex.append((generation >> 7) & 0x7F)

        sysex.append(0xF7)

        self.log_message(
            "PrismScript: SIMPLER_TX track=%d pad=%d mask=%d start=%d end=%d"
            % (track_id, pad_index, presence_mask, sysex[13], sysex[14])
        )

        self._send_midi(tuple(sysex))

    # ============================================================
    # SysEx metadata senders — unchanged formats
    # ============================================================

    def _sanitize_label(self, label, max_length):
        sanitized = ""
        for char in label:
            if 32 <= ord(char) <= 126:
                sanitized += char
        return [ord(c) & 0x7F for c in sanitized[:max_length]]

    def _is_macro_mapped(self, param, macro_index):
        if param is None:
            return False
        try:
            return param.name != ("Macro %d" % macro_index)
        except Exception:
            return False

    def _send_label_sysex(self, track_id, macro_index_1_16, label):
        if not self._connected:
            return
        sysex = [0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_LABEL,
                 track_id & 0x7F, macro_index_1_16 & 0x7F]
        sysex.extend(self._sanitize_label(label, self.MAX_LABEL_LENGTH))
        sysex.append(0xF7)
        self._send_midi(tuple(sysex))
        
    def _send_pad_meta_sysex(self, track_id, pad_index_1_16, simpler_state):
        if not self._connected:
            return

        sysex = (
            0xF0,
            self.SYSEX_MANUFACTURER_ID,
            self.SYSEX_MSG_PAD_META,
            track_id & 0x7F,
            pad_index_1_16 & 0x7F,
            simpler_state & 0x7F,
            0xF7
        )

        self._send_midi(sysex)
        
    def _send_pad_name_sysex(self, track_id, pad_index_1_16, name):
        if not self._connected:
            return
        sysex = [0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_PAD_NAME,
                 track_id & 0x7F, pad_index_1_16 & 0x7F]
        sysex.extend(self._sanitize_label(name, self.MAX_PAD_NAME_LENGTH))
        sysex.append(0xF7)
        self._send_midi(tuple(sysex))

    def _send_track_info(self, track_id, track, is_drum, selected=False):
        if track is None:
            self._send_track_name_sysex(track_id, "", is_drum, selected)
            return
        self._send_track_name_sysex(track_id, track.name, is_drum, selected)
        self._send_track_color_sysex(track_id, track, is_drum)

    def _send_track_name_sysex(self, track_id, track_name, is_drum=False, selected=False):
        # flags: bit0 drum track, bit1 you selected this linked track in Live (Prism follows)
        if not self._connected:
            return
        flags = (0x01 if is_drum else 0x00) | (0x02 if selected else 0x00)
        sysex = [0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_TRACK_NAME,
                 track_id & 0x7F, flags]
        sysex.extend(self._sanitize_label(track_name, self.MAX_TRACK_NAME_LENGTH))
        sysex.append(0xF7)
        self._send_midi(tuple(sysex))

    def _send_track_color_sysex(self, track_id, track, is_drum=False):
        if not self._connected:
            return
        try:
            color_int = track.color
            r = (color_int >> 16) & 0xFF
            g = (color_int >> 8) & 0xFF
            b = color_int & 0xFF
            sysex = (0xF0, self.SYSEX_MANUFACTURER_ID, self.SYSEX_MSG_TRACK_COLOR,
                     track_id & 0x7F, (r >> 1) & 0x7F, (g >> 1) & 0x7F,
                     (b >> 1) & 0x7F, 0x01 if is_drum else 0x00, 0xF7)
            self._send_midi(sysex)
        except Exception as e:
            self.log_message("PrismScript: error sending track color: %s" % str(e))

    # ============================================================
    # Instrument / drum detection helpers — unchanged behavior
    # ============================================================

    def _find_first_instrument_device(self, track):
        if not hasattr(track, 'devices'):
            return None
        for d in track.devices:
            try:
                if d.type == Live.Device.DeviceType.instrument:
                    return d
            except Exception:
                pass
        return None

    def _get_macro_params_by_index(self, device):
        try:
            if str(getattr(device, 'class_name', '')) == 'OriginalSimpler':
                return [None] * 16, 0
            params = list(device.parameters)
        except Exception:
            return [None] * 16, 0
        if len(params) < 2:
            return [None] * 16, 0

        macro_params = [None] * 16
        count = 0
        for i in range(16):
            param_index = i + 1  # parameter 0 is Device On
            if param_index < len(params):
                macro_params[i] = params[param_index]
                count += 1
        return macro_params, count

    def _debug(self, msg):
        if self.DEBUG:
            self.log_message(msg)

    def _check_is_drum_rack(self, track):
        if track is None or not hasattr(track, 'devices'):
            return False
        try:
            for device in track.devices:
                if self._is_drum_rack_device(device):
                    return True
        except Exception as e:
            self._debug("PrismScript: DRUM CHECK ERROR: %s" % str(e))
        return False

    def _is_drum_rack_device(self, device):
        try:
            class_name = device.class_name

            if class_name == 'DrumGroupDevice':
                return True

            # Instrument Racks may contain a drum rack in a chain
            # (check nested BEFORE pad properties — pad props raise on IGD).
            if class_name == 'InstrumentGroupDevice':
                if hasattr(device, 'chains'):
                    try:
                        for chain in device.chains:
                            if hasattr(chain, 'devices'):
                                for nested in chain.devices:
                                    if self._is_drum_rack_device(nested):
                                        return True
                    except Exception as e:
                        self._debug("PrismScript: DRUM CHECK chains error: %s" % str(e))
                # fall through to name check only
            else:
                if hasattr(device, 'can_have_drum_pads'):
                    try:
                        if device.can_have_drum_pads:
                            return True
                    except Exception:
                        pass
                if hasattr(device, 'drum_pads'):
                    try:
                        if device.drum_pads is not None:
                            return True
                    except Exception:
                        pass
                if hasattr(device, 'visible_drum_pads'):
                    try:
                        if device.visible_drum_pads is not None:
                            return True
                    except Exception:
                        pass

            name = device.name.lower()
            if 'drum rack' in name or 'drum kit' in name:
                return True
        except Exception as e:
            self._debug("PrismScript: DRUM CHECK exception: %s" % str(e))
        return False

    def _find_drum_rack_device(self, track):
        if not hasattr(track, 'devices'):
            return None
        for device in track.devices:
            result = self._get_drum_rack_from_device(device)
            if result is not None:
                return result
        return None

    def _get_drum_rack_from_device(self, device):
        try:
            class_name = device.class_name
            if class_name == 'DrumGroupDevice':
                return device
            if class_name == 'InstrumentGroupDevice' and hasattr(device, 'chains'):
                for chain in device.chains:
                    if hasattr(chain, 'devices'):
                        for nested in chain.devices:
                            result = self._get_drum_rack_from_device(nested)
                            if result is not None:
                                return result
        except Exception:
            pass
        return None

    # ============================================================
    # Simpler Lab waveform transport
    # ============================================================

    @staticmethod
    def _wave_pack_u14(value):
        v = max(0, min(0x3FFF, int(value)))
        return [v & 0x7F, (v >> 7) & 0x7F]

    @staticmethod
    def _wave_pack_u21(value):
        v = max(0, min(0x1FFFFF, int(value)))
        return [v & 0x7F, (v >> 7) & 0x7F, (v >> 14) & 0x7F]

    @staticmethod
    def _wave_pack_u28(value):
        v = max(0, min(0x0FFFFFFF, int(value)))
        return [
            v & 0x7F,
            (v >> 7) & 0x7F,
            (v >> 14) & 0x7F,
            (v >> 21) & 0x7F
        ]

    @staticmethod
    def _wave_quantize(value):
        try:
            v = float(value)
        except Exception:
            v = 0.0
        if v < -1.0:
            v = -1.0
        elif v > 1.0:
            v = 1.0
        return max(0, min(127, int(round((v + 1.0) * 63.5))))

    def _resolve_simpler_lab_target(self, track_id, pad_index):
        try:
            link = self._links.get(track_id)

            if link is None or link._detached:
                return None, None, None, "Prism channel not connected"

            if pad_index < 0 or pad_index >= self.DRUM_PAD_COUNT:
                return None, None, None, "Pad out of range"

            track = link.track

            drum_rack = self._find_drum_rack_device(track)
            if drum_rack is None:
                if pad_index != 0:
                    return track, None, None, "No Simpler in this slot"

                simpler = self._find_simpler_in_container(track)
                if simpler is None:
                    return track, None, None, "Track has no Simpler"

                return track, simpler, None, None

            note = self.DRUM_PAD_NOTE_START + pad_index
            info = self._get_pad_info_for_note(drum_rack, note)

            if info is None or info.get('chain') is None:
                return track, None, None, "Pad has no chain"

            simpler = self._find_simpler_in_container(info.get('chain'))

            if simpler is None:
                return track, None, info, "Pad has no Simpler"

            return track, simpler, info, None

        except Exception as e:
            return None, None, None, str(e)

    def _cached_waveform_bins(self, file_path, bin_count):
        """Decode each sample file once. Reconnect / resync / preset reload
        re-send from memory; a changed file (size or mtime) decodes again."""
        try:
            import os as _os
            st = _os.stat(file_path)
            key = (file_path, st.st_size, st.st_mtime, int(bin_count))
        except Exception:
            return self._decode_pcm_waveform_bins(file_path, bin_count)

        result = self._waveform_cache.get(key)
        if result is None:
            result = self._decode_pcm_waveform_bins(file_path, bin_count)
            if result is not None:
                if len(self._waveform_cache) >= self.WAVEFORM_CACHE_MAX:
                    self._waveform_cache.clear()
                self._waveform_cache[key] = result
        return result

    def _schedule_simpler_waveform_response(self, track_id, pad_index,
                                            request_id, bin_count=256):
        if not self._connected:
            return
        tid, pad = int(track_id), int(pad_index)
        rid, bins = int(request_id) & 0x7F, int(bin_count)
        queue = getattr(self, '_waveform_queue', None)
        if queue is None:
            queue = self._waveform_queue = []
        link = self._links.get(tid)
        # Coalesce repeated work per pad. Explicit requests take priority over
        # automatic sweeps, and a retry replaces its obsolete request ID.
        for i, old in enumerate(queue):
            if old[0:2] == (tid, pad):
                if rid == 0 and old[2] != 0 and old[4] is link:
                    return
                queue.pop(i)
                break
        item = (tid, pad, rid, bins, link)
        if rid:
            index = next((i for i, old in enumerate(queue) if old[2] == 0), len(queue))
            queue.insert(index, item)
        else:
            queue.append(item)
        self._schedule_waveform_queue()

    def _schedule_waveform_queue(self):
        if getattr(self, '_waveform_queue_pending', False):
            return
        self._waveform_queue_pending = True
        generation = getattr(self, '_waveform_queue_generation', 0)

        def send(g=generation):
            if g != getattr(self, '_waveform_queue_generation', 0):
                return
            self._waveform_queue_pending = False
            if not self._connected:
                self._clear_waveform_work()
                return
            queue = self._waveform_queue
            sent = 0
            while queue and sent < 8:
                tid, pad, rid, bins, expected = queue.pop(0)
                if expected is not None and (expected._detached or self._links.get(tid) is not expected):
                    continue
                # Eight pads globally per tick, including requested replies and
                # every track's sweep. This bounds MIDI bursts during resync.
                self._send_simpler_waveform_response(tid, pad, rid, bins)
                sent += 1
            if queue:
                self._schedule_waveform_queue()

        self.schedule_message(1, send)

    def _clear_waveform_work(self):
        self._waveform_queue = []
        self._waveform_queue_pending = False
        self._waveform_queue_generation = getattr(self, '_waveform_queue_generation', 0) + 1
        self._clear_waveform_signatures()

    def _clear_waveform_signatures(self, track_id=None):
        signatures = getattr(self, '_last_wave_signatures', {})
        self._last_wave_signatures = {
            key: value for key, value in signatures.items()
            if track_id is not None and key[0] != track_id
        }

    def _send_waveform_context(self, track_id):
        self._clear_waveform_signatures(track_id)
        if self._connected:
            self._send_midi((0xF0, self.SYSEX_MANUFACTURER_ID,
                             self.SYSEX_MSG_WAVEFORM_RESPONSE,
                             self.WAVEFORM_RESP_CONTEXT, int(track_id) & 0x7F, 0xF7))

    def _next_waveform_push_session(self):
        # The main Prism coordinator reserves 1..63 for requested transfers.
        # Automatic pushes use 64..127, so late requested replies cannot replace
        # a newer unsolicited waveform for the same pad.
        session = 64 + ((getattr(self, '_waveform_push_session', 127) - 63) % 64)
        self._waveform_push_session = session
        return session

    def _send_waveform_error(self, request_id, track_id, pad_index, code, text):
        message = [
            0xF0,
            self.SYSEX_MANUFACTURER_ID,
            self.SYSEX_MSG_WAVEFORM_RESPONSE,
            self.WAVEFORM_RESP_ERROR,
            int(request_id) & 0x7F,
            int(track_id) & 0x7F,
            int(pad_index) & 0x7F,
            int(code) & 0x7F
        ]
        message.extend(self._sanitize_label(str(text), 60))
        message.append(0xF7)
        return self._send_midi(tuple(message))

    def _send_waveform_name(self, request_id, track_id, pad_index, name):
        message = [
            0xF0,
            self.SYSEX_MANUFACTURER_ID,
            self.SYSEX_MSG_WAVEFORM_RESPONSE,
            self.WAVEFORM_RESP_NAME,
            int(request_id) & 0x7F,
            int(track_id) & 0x7F,
            int(pad_index) & 0x7F
        ]
        message.extend(self._sanitize_label(str(name), 60))
        message.append(0xF7)
        return self._send_midi(tuple(message))

        

    def _send_simpler_waveform_response(self, track_id, pad_index,
                                        request_id, bin_count=256):
        """Resolve one drum-pad Simpler and return Lab state + waveform data."""
        if not self._connected:
            return
        automatic = request_id == 0
        if request_id == 0:
            request_id = self._next_waveform_push_session()
        try:
            import os as _os
            import time as _time
        except Exception as e:
            self._send_waveform_error(
                request_id, track_id, pad_index, 1,
                "Python runtime unavailable: %s" % str(e)
            )
            return

        try:
            track, simpler, info, target_error = self._resolve_simpler_lab_target(
                track_id, pad_index
            )
            # Remember what Prism was told for this pad ('' = nothing).
            self._last_wave_paths[(track_id, pad_index)] = ""
            signatures = getattr(self, '_last_wave_signatures', None)
            if signatures is None:
                signatures = self._last_wave_signatures = {}
            previous_signature = signatures.pop((track_id, pad_index), None)

            if simpler is None:
                self._send_waveform_error(
                    request_id, track_id, pad_index, 4,
                    target_error or "Simpler unavailable"
                )
                return

            try:
                sample = getattr(simpler, 'sample', None)
            except Exception:
                sample = None
            if sample is None:
                self._send_waveform_error(
                    request_id, track_id, pad_index, 7, "Simpler has no sample"
                )
                return

            file_path = str(getattr(sample, 'file_path', '') or '')
            live_frames = int(getattr(sample, 'length', 0) or 0)
            sample_rate = int(getattr(sample, 'sample_rate', 0) or 0)
            start_marker = int(getattr(sample, 'start_marker', 0) or 0)
            end_marker = int(getattr(sample, 'end_marker', 0) or 0)
            playback_mode = int(getattr(simpler, 'playback_mode', 0) or 0)
            try:
                slices = list(getattr(sample, 'slices', []) or [])
            except Exception:
                slices = []


            # Metadata is also useful even when waveform decoding fails.
            # F0 7D 26 01 req track pad status mode
            # frames[u28] sampleRate[u21] start[u28] end[u28]
            # slices[u14] bins[u14] F7
            requested_bins = max(16, min(1024, int(bin_count)))
            meta = [
                0xF0,
                self.SYSEX_MANUFACTURER_ID,
                self.SYSEX_MSG_WAVEFORM_RESPONSE,
                self.WAVEFORM_RESP_META,
                request_id & 0x7F,
                track_id & 0x7F,
                pad_index & 0x7F,
                0,
                playback_mode & 0x7F
            ]
            meta.extend(self._wave_pack_u28(live_frames))
            meta.extend(self._wave_pack_u21(sample_rate))
            meta.extend(self._wave_pack_u28(start_marker))
            meta.extend(self._wave_pack_u28(end_marker))
            meta.extend(self._wave_pack_u14(len(slices)))
            meta.extend(self._wave_pack_u14(requested_bins))
            meta.append(0xF7)
            signature = None
            try:
                stat = _os.stat(file_path)
                signature = (file_path, stat.st_size, stat.st_mtime, tuple(meta[5:-1]))
            except Exception:
                pass
            # Progress already published this exact sample/state. A final kit
            # sweep can skip it; explicit requests always reply to repair loss.
            if automatic and signature is not None and signature == previous_signature:
                signatures[(track_id, pad_index)] = signature
                self._last_wave_paths[(track_id, pad_index)] = file_path
                return
            if self._send_midi(tuple(meta)) is False:
                raise RuntimeError("Could not send waveform metadata")

            if self._send_waveform_name(
                request_id, track_id, pad_index,
                _os.path.basename(file_path) if file_path else ""
            ) is False:
                raise RuntimeError("Could not send waveform name")

            if not file_path:
                self._send_waveform_error(
                    request_id, track_id, pad_index, 8, "Sample has no file path"
                )
                return
            if not _os.path.isfile(file_path):
                self._send_waveform_error(
                    request_id, track_id, pad_index, 9, "Sample file unavailable"
                )
                return

            started = _time.time()
            result = self._cached_waveform_bins(file_path, requested_bins)
            elapsed_ms = (_time.time() - started) * 1000.0

            if result is None:
                self._send_waveform_error(
                    request_id, track_id, pad_index, 10,
                    "Waveform unavailable for this sample format"
                )
                return

            bins = list(result.get('bins', []))
            if not bins:
                self._send_waveform_error(
                    request_id, track_id, pad_index, 11, "Decoded waveform is empty"
                )
                return

            chunk_bins = self.WAVEFORM_CHUNK_BINS
            chunk_count = (len(bins) + chunk_bins - 1) // chunk_bins

            for chunk_index in range(chunk_count):
                start_bin = chunk_index * chunk_bins
                subset = bins[start_bin:start_bin + chunk_bins]

                message = [
                    0xF0,
                    self.SYSEX_MANUFACTURER_ID,
                    self.SYSEX_MSG_WAVEFORM_RESPONSE,
                    self.WAVEFORM_RESP_CHUNK,
                    request_id & 0x7F,
                    track_id & 0x7F,
                    pad_index & 0x7F,
                    chunk_index & 0x7F,
                    chunk_count & 0x7F
                ]
                message.extend(self._wave_pack_u14(start_bin))
                message.append(len(subset) & 0x7F)

                for mn, mx in subset:
                    message.append(self._wave_quantize(mn))
                    message.append(self._wave_quantize(mx))

                message.append(0xF7)
                if self._send_midi(tuple(message)) is False:
                    raise RuntimeError("Could not send waveform chunk")

            end = (
                0xF0,
                self.SYSEX_MANUFACTURER_ID,
                self.SYSEX_MSG_WAVEFORM_RESPONSE,
                self.WAVEFORM_RESP_END,
                request_id & 0x7F,
                track_id & 0x7F,
                pad_index & 0x7F,
                0xF7
            )
            if self._send_midi(end) is False:
                raise RuntimeError("Could not send waveform end")
            self._last_wave_paths[(track_id, pad_index)] = file_path
            if signature is not None:
                signatures[(track_id, pad_index)] = signature

            self.log_message(
                "[SIMPLER LAB] waveform TX track=%d pad=%d session=%d bins=%d "
                "chunks=%d format=%s decode=%.1fms"
                % (
                    track_id, pad_index, request_id, len(bins), chunk_count,
                    str(result.get('format', '?')), elapsed_ms
                )
            )

        except Exception as e:
            self.log_message(
                "[SIMPLER LAB] waveform ERROR track=%d pad=%d session=%d: %s"
                % (track_id, pad_index, request_id, str(e))
            )
            self._send_waveform_error(
                request_id, track_id, pad_index, 12, "Waveform exception"
            )

    # ============================================================
    # TEMP Simpler waveform proof
    # ============================================================


    def _decode_pcm_waveform_bins(self, file_path, bin_count):
        """Return min/max waveform bins for PCM WAV or AIFF/AIFF-C.

        WAV uses Python's wave module when available.
        AIFF is parsed directly so we do not depend on the deprecated/limited
        aifc module. Supported AIFF-C PCM tags:
          NONE / twos -> big-endian signed PCM
          sowt        -> little-endian signed PCM
        """
        self._waveform_aiff_was_protected = False
        
        try:
            import os as _os
        except Exception as e:
            self.log_message("[WAVEFORM TEST] FAIL os module unavailable: %s" % str(e))
            return None

        bin_count = max(16, min(1024, int(bin_count)))
        ext = _os.path.splitext(file_path)[1].lower()

        if ext in ('.wav', '.wave'):
            return self._decode_wav_waveform_bins(file_path, bin_count)

        if ext in ('.aif', '.aiff', '.aifc'):
            result = self._decode_aiff_waveform_bins(file_path, bin_count)

            if result is not None:
                return result

            if self._waveform_aiff_was_protected:
                return None

            return self._decode_aiff_via_coreaudio(
                file_path,
                bin_count
            )

        self.log_message("[WAVEFORM TEST] UNSUPPORTED extension='%s' path='%s'"
                         % (ext, file_path))
        return None

    def _decode_wav_waveform_bins(self, file_path, bin_count):
        """Minimal dependency-free RIFF/WAVE PCM decoder.

        Ableton Live 11's embedded Python is missing audioop, which makes the
        stdlib wave module unusable in this environment. Parse RIFF directly
        instead so ordinary WAV/user samples remain fully available.
        """
        f = None
        try:
            f = open(file_path, 'rb')

            header = f.read(12)
            if (
                len(header) != 12 or
                header[0:4] not in (b'RIFF', b'RIFX') or
                header[8:12] != b'WAVE'
            ):
                self.log_message("[WAVEFORM TEST] WAV FAIL invalid RIFF/WAVE header")
                return None

            byte_order = 'big' if header[0:4] == b'RIFX' else 'little'
            endian = '>' if byte_order == 'big' else '<'

            try:
                import struct as _struct
            except Exception as e:
                self.log_message("[WAVEFORM TEST] WAV FAIL struct unavailable: %s" % str(e))
                return None

            audio_format = 0
            channels = 0
            sample_rate = 0
            block_align = 0
            bits_per_sample = 0
            data_offset = -1
            data_bytes = 0

            while True:
                chunk_header = f.read(8)
                if len(chunk_header) < 8:
                    break

                chunk_id = chunk_header[0:4]
                chunk_size = _struct.unpack(endian + 'I', chunk_header[4:8])[0]
                chunk_start = f.tell()

                if chunk_id == b'fmt ':
                    fmt = f.read(min(chunk_size, 64))
                    if len(fmt) < 16:
                        self.log_message("[WAVEFORM TEST] WAV FAIL short fmt chunk")
                        return None

                    (
                        audio_format,
                        channels,
                        sample_rate,
                        _byte_rate,
                        block_align,
                        bits_per_sample
                    ) = _struct.unpack(endian + 'HHIIHH', fmt[:16])

                    # WAVE_FORMAT_EXTENSIBLE. If present, inspect the subformat.
                    if audio_format == 0xFFFE and len(fmt) >= 40:
                        # First 16 bits of the sub-format GUID encode the classic
                        # format code for PCM/IEEE float.
                        audio_format = _struct.unpack(endian + 'H', fmt[24:26])[0]

                elif chunk_id == b'data':
                    data_offset = f.tell()
                    data_bytes = chunk_size

                # RIFF chunks are word aligned.
                f.seek(chunk_start + chunk_size + (chunk_size & 1), 0)

            if (
                channels <= 0 or
                sample_rate <= 0 or
                block_align <= 0 or
                bits_per_sample <= 0 or
                data_offset < 0 or
                data_bytes <= 0
            ):
                self.log_message(
                    "[WAVEFORM TEST] WAV FAIL metadata fmt=%d channels=%d sr=%d "
                    "align=%d bits=%d dataOffset=%d dataBytes=%d"
                    % (
                        audio_format,
                        channels,
                        sample_rate,
                        block_align,
                        bits_per_sample,
                        data_offset,
                        data_bytes
                    )
                )
                return None

            if audio_format not in (1, 3):
                self.log_message(
                    "[WAVEFORM TEST] WAV UNSUPPORTED formatTag=%d" % audio_format
                )
                return None

            if bits_per_sample not in (8, 16, 24, 32):
                self.log_message(
                    "[WAVEFORM TEST] WAV UNSUPPORTED bits=%d" % bits_per_sample
                )
                return None

            sample_width = max(1, bits_per_sample // 8)
            frames = data_bytes // block_align

            if frames <= 0:
                self.log_message("[WAVEFORM TEST] WAV FAIL no PCM frames")
                return None

            self.log_message(
                "[WAVEFORM TEST] WAV PCM formatTag=%d channels=%d bits=%d "
                "frames=%d sr=%d endian=%s"
                % (
                    audio_format,
                    channels,
                    bits_per_sample,
                    frames,
                    sample_rate,
                    byte_order
                )
            )

            out = []

            for i in range(bin_count):
                start_frame = (i * frames) // bin_count
                end_frame = ((i + 1) * frames) // bin_count
                frame_count = max(1, end_frame - start_frame)

                f.seek(data_offset + (start_frame * block_align), 0)
                raw = f.read(frame_count * block_align)

                if audio_format == 3 and bits_per_sample == 32:
                    mn, mx = self._pcm_float32_minmax(raw, byte_order)
                elif audio_format == 1:
                    mn, mx = self._pcm_minmax(
                        raw,
                        sample_width,
                        byte_order,
                        True if bits_per_sample == 8 else False
                    )
                else:
                    self.log_message(
                        "[WAVEFORM TEST] WAV UNSUPPORTED float bits=%d"
                        % bits_per_sample
                    )
                    return None

                out.append((mn, mx))

            return {
                'format': 'WAV_RAW',
                'channels': channels,
                'sample_width': sample_width,
                'frames': frames,
                'sample_rate': sample_rate,
                'bins': out
            }

        except Exception as e:
            self.log_message(
                "[WAVEFORM TEST] WAV DECODE ERROR '%s': %s"
                % (file_path, str(e))
            )
            return None

        finally:
            if f is not None:
                try:
                    f.close()
                except Exception:
                    pass

    def _pcm_float32_minmax(self, raw, byte_order):
        """Min/max helper for IEEE float32 WAV payloads."""
        try:
            import struct as _struct
        except Exception:
            return (0.0, 0.0)

        count = len(raw) // 4
        if count <= 0:
            return (0.0, 0.0)

        fast = self._array_float_minmax(raw[:count * 4], byte_order)
        if fast is not None:
            return fast

        endian = '>' if byte_order == 'big' else '<'
        mn = 1.0
        mx = -1.0
        seen = False

        for i in range(count):
            try:
                v = float(_struct.unpack_from(endian + 'f', raw, i * 4)[0])
            except Exception:
                continue

            if v != v:  # NaN
                continue

            if v < -1.0:
                v = -1.0
            elif v > 1.0:
                v = 1.0

            if v < mn:
                mn = v
            if v > mx:
                mx = v
            seen = True

        if not seen:
            return (0.0, 0.0)

        return (mn, mx)

    def _decode_aiff_via_coreaudio(self, file_path, bin_count):
        """macOS fallback for AIFF/AIFF-C formats our small parser does not handle.

        Uses Apple's Core Audio afconvert to produce a temporary uncompressed
        16-bit PCM WAV, then reuses Prism's proven WAV waveform decoder.

        This is intended for ordinary AIFF-C codecs such as ima4/fl32/etc.
        Ableton-protected 'able' files may still be rejected by Core Audio.
        """
        try:
            import os as _os
            import subprocess as _subprocess
            import tempfile as _tempfile
        except Exception as e:
            self.log_message(
                "[WAVEFORM TEST] AIFF CORE AUDIO unavailable: %s"
                % str(e)
            )
            return None

        afconvert = "/usr/bin/afconvert"

        if not _os.path.isfile(afconvert):
            self.log_message(
                "[WAVEFORM TEST] AIFF CORE AUDIO afconvert missing"
            )
            return None

        temp_path = None

        try:
            fd, temp_path = _tempfile.mkstemp(
                prefix="prism_waveform_",
                suffix=".wav"
            )

            _os.close(fd)

            # afconvert expects to create the destination itself.
            try:
                _os.remove(temp_path)
            except Exception:
                pass

            command = [
                afconvert,
                file_path,
                temp_path,
                "-f", "WAVE",
                "-d", "LEI16"
            ]

            self.log_message(
                "[WAVEFORM TEST] AIFF CORE AUDIO decode '%s'"
                % file_path
            )

            process = _subprocess.Popen(
                command,
                stdout=_subprocess.PIPE,
                stderr=_subprocess.PIPE
            )

            try:
                stdout_data, stderr_data = process.communicate(
                    timeout=3.0
                )
            except TypeError:
                # Compatibility with an older embedded Python if necessary.
                stdout_data, stderr_data = process.communicate()

            if process.returncode != 0:
                try:
                    error_text = stderr_data.decode(
                        'utf-8',
                        errors='replace'
                    )
                except Exception:
                    error_text = str(stderr_data)

                self.log_message(
                    "[WAVEFORM TEST] AIFF CORE AUDIO FAIL code=%d error='%s'"
                    % (
                        process.returncode,
                        error_text[:300]
                    )
                )
                return None

            if (
                not _os.path.isfile(temp_path) or
                _os.path.getsize(temp_path) <= 44
            ):
                self.log_message(
                    "[WAVEFORM TEST] AIFF CORE AUDIO FAIL no output WAV"
                )
                return None

            self.log_message(
                "[WAVEFORM TEST] AIFF CORE AUDIO OK bytes=%d"
                % _os.path.getsize(temp_path)
            )

            result = self._decode_wav_waveform_bins(
                temp_path,
                bin_count
            )

            if result is not None:
                result['format'] = 'AIFF_CORE_AUDIO'

            return result

        except Exception as e:
            self.log_message(
                "[WAVEFORM TEST] AIFF CORE AUDIO ERROR '%s': %s"
                % (
                    file_path,
                    str(e)
                )
            )
            return None

        finally:
            if temp_path:
                try:
                    if _os.path.isfile(temp_path):
                        _os.remove(temp_path)
                except Exception:
                    pass

    def _half_float_to_float(self, word):
        """Decode one little-endian IEEE-754 binary16 value."""
        sign = -1.0 if (word & 0x8000) else 1.0
        exponent = (word >> 10) & 0x1F
        fraction = word & 0x03FF

        if exponent == 0:
            if fraction == 0:
                return 0.0
            return sign * (fraction / 1024.0) * (2.0 ** -14)

        if exponent == 31:
            # Waveform data should never need NaN or infinity.
            return 0.0

        return (
            sign *
            (1.0 + (fraction / 1024.0)) *
            (2.0 ** (exponent - 15))
        )

    def _decode_asd_waveform_bins(self, file_path, bin_count,
                                  channels, frames, sample_rate):
        """Read Live's precomputed waveform overview from file_path + '.asd'.

        The main SampleOverViewLevel payload contains little-endian IEEE-754
        binary16 values. Each 128-frame source bin contains min/max values for
        every channel:

            minCh0, maxCh0, minCh1, maxCh1, ...

        The channel values are collapsed into one min/max display envelope and
        then reduced to Prism's requested bin count.
        """
        try:
            import os as _os
            import struct as _struct
        except Exception as e:
            self.log_message(
                "[WAVEFORM ASD] runtime unavailable: %s" % str(e)
            )
            return None

        asd_path = file_path + ".asd"

        if not _os.path.isfile(asd_path):
            self.log_message(
                "[WAVEFORM ASD] missing path='%s'" % asd_path
            )
            return None

        try:
            with open(asd_path, 'rb') as f:
                data = f.read()
        except Exception as e:
            self.log_message(
                "[WAVEFORM ASD] read failed path='%s': %s"
                % (asd_path, str(e))
            )
            return None

        # 0x13 is the serialized string length for "SampleOverViewLevel".
        marker = b'\x13SampleOverViewLevel'

        best_start = -1
        best_value_count = 0
        best_object_id = -1
        search_from = 0

        while True:
            marker_pos = data.find(marker, search_from)

            if marker_pos < 0:
                break

            header_pos = marker_pos + len(marker)

            if header_pos + 8 <= len(data):
                object_id, value_count = _struct.unpack_from(
                    '<II',
                    data,
                    header_pos
                )

                payload_start = header_pos + 8
                payload_end = payload_start + (value_count * 2)

                # Small occurrences are schema/type records. The actual
                # waveform table is the largest valid half-float payload.
                if (
                    value_count >= 64 and
                    (value_count & 1) == 0 and
                    payload_end <= len(data) and
                    value_count > best_value_count
                ):
                    best_start = payload_start
                    best_value_count = value_count
                    best_object_id = object_id

            search_from = marker_pos + 1

        if best_start < 0 or best_value_count <= 0:
            self.log_message(
                "[WAVEFORM ASD] no SampleOverViewLevel payload path='%s'"
                % asd_path
            )
            return None

        channels = max(1, int(channels))
        values_per_source_bin = channels * 2

        if best_value_count % values_per_source_bin != 0:
            self.log_message(
                "[WAVEFORM ASD] channel/count mismatch values=%d channels=%d"
                % (best_value_count, channels)
            )
            return None

        source_bin_count = best_value_count // values_per_source_bin

        if source_bin_count <= 0:
            return None

        expected_source_bins = (
            (int(frames) + 127) // 128
            if int(frames) > 0
            else 0
        )

        if (
            expected_source_bins > 0 and
            abs(source_bin_count - expected_source_bins) > 1
        ):
            self.log_message(
                "[WAVEFORM ASD] bin-count warning actual=%d expected=%d "
                "frames=%d channels=%d"
                % (
                    source_bin_count,
                    expected_source_bins,
                    int(frames),
                    channels
                )
            )

        raw = data[
            best_start:
            best_start + (best_value_count * 2)
        ]

        values = []

        for offset in range(0, len(raw), 2):
            word = (
                (raw[offset] & 0xFF) |
                ((raw[offset + 1] & 0xFF) << 8)
            )

            values.append(
                self._half_float_to_float(word)
            )

        source_bins = []

        for source_index in range(source_bin_count):
            combined_min = 1.0
            combined_max = -1.0

            for channel_index in range(channels):
                base = (
                    (source_index * channels + channel_index) * 2
                )

                channel_min = values[base]
                channel_max = values[base + 1]

                if channel_min < combined_min:
                    combined_min = channel_min

                if channel_max > combined_max:
                    combined_max = channel_max

            combined_min = max(-1.0, min(1.0, combined_min))
            combined_max = max(-1.0, min(1.0, combined_max))

            source_bins.append(
                (combined_min, combined_max)
            )

        requested_bins = max(16, min(1024, int(bin_count)))
        output_bins = []

        for output_index in range(requested_bins):
            source_start = (
                output_index * source_bin_count
            ) // requested_bins

            # Ceil division so every overlapping source bin contributes.
            source_end = (
                ((output_index + 1) * source_bin_count) +
                requested_bins - 1
            ) // requested_bins

            if source_start >= source_bin_count:
                source_start = source_bin_count - 1

            if source_end <= source_start:
                source_end = source_start + 1

            if source_end > source_bin_count:
                source_end = source_bin_count

            output_min = 1.0
            output_max = -1.0

            for source_index in range(source_start, source_end):
                source_min, source_max = source_bins[source_index]

                if source_min < output_min:
                    output_min = source_min

                if source_max > output_max:
                    output_max = source_max

            output_bins.append(
                (output_min, output_max)
            )

        self.log_message(
            "[WAVEFORM ASD] OK path='%s' object=%d values=%d "
            "sourceBins=%d outputBins=%d channels=%d expected=%d"
            % (
                asd_path,
                best_object_id,
                best_value_count,
                source_bin_count,
                len(output_bins),
                channels,
                expected_source_bins
            )
        )

        return {
            'format': 'ASD_OVERVIEW',
            'channels': channels,
            'sample_width': 2,
            'frames': int(frames),
            'sample_rate': int(sample_rate),
            'bins': output_bins
        }

    def _decode_aiff_waveform_bins(self, file_path, bin_count):
        """Minimal AIFF / AIFF-C PCM parser.

        We only need COMM + SSND. This intentionally avoids aifc because many
        Ableton factory .aif files use AIFF-C 'sowt', which aifc may reject.
        """
        f = None
        try:
            f = open(file_path, 'rb')

            header = f.read(12)
            if len(header) != 12 or header[0:4] != b'FORM':
                self.log_message("[WAVEFORM TEST] AIFF FAIL invalid FORM header")
                return None

            form_type = header[8:12]
            if form_type not in (b'AIFF', b'AIFC'):
                self.log_message("[WAVEFORM TEST] AIFF FAIL form='%s'"
                                 % repr(form_type))
                return None

            channels = 0
            frames = 0
            sample_bits = 0
            sample_rate = 0
            compression = b'NONE'
            data_offset = -1
            data_bytes = 0

            while True:
                chunk_header = f.read(8)
                if len(chunk_header) < 8:
                    break

                chunk_id = chunk_header[0:4]
                chunk_size = self._be_u32(chunk_header, 4)
                chunk_start = f.tell()

                if chunk_id == b'COMM':
                    comm = f.read(chunk_size)
                    if len(comm) < 18:
                        self.log_message("[WAVEFORM TEST] AIFF FAIL short COMM")
                        return None

                    channels = self._be_u16(comm, 0)
                    frames = self._be_u32(comm, 2)
                    sample_bits = self._be_u16(comm, 6)
                    sample_rate = int(round(self._extended80_to_float(comm[8:18])))

                    if form_type == b'AIFC' and len(comm) >= 22:
                        compression = comm[18:22]
                    else:
                        compression = b'NONE'

                elif chunk_id == b'SSND':
                    ssnd_header = f.read(8)
                    if len(ssnd_header) < 8:
                        self.log_message("[WAVEFORM TEST] AIFF FAIL short SSND")
                        return None

                    offset = self._be_u32(ssnd_header, 0)
                    # blockSize = self._be_u32(ssnd_header, 4)  # not needed
                    data_offset = f.tell() + offset
                    data_bytes = max(0, chunk_size - 8 - offset)

                # AIFF chunks are even-byte aligned.
                f.seek(chunk_start + chunk_size + (chunk_size & 1), 0)

            if channels <= 0 or frames <= 0 or data_offset < 0:
                self.log_message(
                    "[WAVEFORM TEST] AIFF FAIL metadata channels=%d frames=%d dataOffset=%d"
                    % (channels, frames, data_offset)
                )
                return None

            is_float = False
            unsigned_8bit = False

            if compression in (b'NONE', b'twos'):
                if sample_bits not in (8, 16, 24, 32):
                    self.log_message(
                        "[WAVEFORM TEST] AIFF UNSUPPORTED PCM bits=%d"
                        % sample_bits
                    )
                    return None

                byte_order = 'big'
                sample_width = sample_bits // 8

            elif compression == b'sowt':
                if sample_bits not in (8, 16, 24, 32):
                    self.log_message(
                        "[WAVEFORM TEST] AIFF UNSUPPORTED sowt bits=%d"
                        % sample_bits
                    )
                    return None

                byte_order = 'little'
                sample_width = sample_bits // 8

            elif compression == b'raw ' and sample_bits == 8:
                byte_order = 'big'
                sample_width = 1
                unsigned_8bit = True

            elif compression == b'in24':
                byte_order = 'big'
                sample_width = 3
                sample_bits = 24

            elif compression == b'in32':
                byte_order = 'big'
                sample_width = 4
                sample_bits = 32

            elif compression in (b'fl32', b'FL32'):
                byte_order = 'big'
                sample_width = 4
                sample_bits = 32
                is_float = True

            elif compression in (b'fl64', b'FL64'):
                byte_order = 'big'
                sample_width = 8
                sample_bits = 64
                is_float = True

            elif compression == b'able':
                self._waveform_aiff_was_protected = True

                self.log_message(
                    "[WAVEFORM TEST] protected Ableton AIFF tag='able' -> reading ASD overview"
                )

                asd_result = self._decode_asd_waveform_bins(
                    file_path,
                    bin_count,
                    channels,
                    frames,
                    sample_rate
                )

                if asd_result is not None:
                    return asd_result

                self.log_message(
                    "[WAVEFORM TEST] protected sample has no usable ASD overview"
                )

                return None

            bytes_per_frame = channels * sample_width
            expected_bytes = frames * bytes_per_frame
            usable_bytes = min(data_bytes, expected_bytes) if data_bytes > 0 else expected_bytes
            usable_frames = usable_bytes // bytes_per_frame

            if usable_frames <= 0:
                self.log_message("[WAVEFORM TEST] AIFF FAIL no PCM frames")
                return None

            # Prefer actual readable PCM count if the SSND chunk is shorter than COMM.
            frames = min(frames, usable_frames)

            try:
                comp_text = compression.decode('latin1')
            except Exception:
                comp_text = repr(compression)

            self.log_message(
                "[WAVEFORM TEST] AIFF DATA form=%s compression=%s channels=%d bits=%d "
                "frames=%d sr=%d endian=%s"
                % (
                    form_type.decode('latin1'),
                    comp_text,
                    channels,
                    sample_bits,
                    frames,
                    sample_rate,
                    byte_order
                )
            )

            out = []
            for i in range(bin_count):
                start_frame = (i * frames) // bin_count
                end_frame = ((i + 1) * frames) // bin_count
                frame_count = max(1, end_frame - start_frame)

                f.seek(data_offset + (start_frame * bytes_per_frame), 0)
                raw = f.read(frame_count * bytes_per_frame)

                if is_float:
                    mn, mx = self._pcm_ieee_float_minmax(
                        raw,
                        sample_width,
                        byte_order
                    )
                else:
                    mn, mx = self._pcm_minmax(
                        raw,
                        sample_width,
                        byte_order,
                        unsigned_8bit
                    )
                out.append((mn, mx))

            return {
                'format': 'AIFF',
                'channels': channels,
                'sample_width': sample_width,
                'frames': frames,
                'sample_rate': sample_rate,
                'bins': out
            }

        except Exception as e:
            self.log_message("[WAVEFORM TEST] AIFF DECODE ERROR '%s': %s"
                             % (file_path, str(e)))
            return None
        finally:
            if f is not None:
                try:
                    f.close()
                except Exception:
                    pass

    def _pcm_ieee_float_minmax(self, raw, width, byte_order):
        """Min/max helper for AIFF-C fl32/fl64 payloads."""
        try:
            import struct as _struct
        except Exception:
            return (0.0, 0.0)

        if width == 4:
            fmt = 'f'
        elif width == 8:
            fmt = 'd'
        else:
            return (0.0, 0.0)

        count = len(raw) // width
        if count <= 0:
            return (0.0, 0.0)

        if width == 4:
            fast = self._array_float_minmax(raw[:count * 4], byte_order)
            if fast is not None:
                return fast

        endian = '>' if byte_order == 'big' else '<'

        mn = 1.0
        mx = -1.0
        seen = False

        for i in range(count):
            try:
                value = float(
                    _struct.unpack_from(
                        endian + fmt,
                        raw,
                        i * width
                    )[0]
                )
            except Exception:
                continue

            # Ignore NaN.
            if value != value:
                continue

            # AIFF float audio is normally normalized around ±1.
            if value < -1.0:
                value = -1.0
            elif value > 1.0:
                value = 1.0

            if value < mn:
                mn = value

            if value > mx:
                mx = value

            seen = True

        if not seen:
            return (0.0, 0.0)

        return (mn, mx)

    @staticmethod
    def _be_u16(data, offset):
        return ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF)

    @staticmethod
    def _be_u32(data, offset):
        return (
            ((data[offset] & 0xFF) << 24) |
            ((data[offset + 1] & 0xFF) << 16) |
            ((data[offset + 2] & 0xFF) << 8) |
            (data[offset + 3] & 0xFF)
        )

    @staticmethod
    def _extended80_to_float(data):
        """Decode the 80-bit extended float used by AIFF sampleRate."""
        if data is None or len(data) < 10:
            return 0.0

        expon = ((data[0] & 0x7F) << 8) | (data[1] & 0xFF)
        sign = -1.0 if (data[0] & 0x80) else 1.0

        hi_mant = (
            ((data[2] & 0xFF) << 24) |
            ((data[3] & 0xFF) << 16) |
            ((data[4] & 0xFF) << 8) |
            (data[5] & 0xFF)
        )
        lo_mant = (
            ((data[6] & 0xFF) << 24) |
            ((data[7] & 0xFF) << 16) |
            ((data[8] & 0xFF) << 8) |
            (data[9] & 0xFF)
        )

        if expon == 0 and hi_mant == 0 and lo_mant == 0:
            return 0.0

        if expon == 0x7FFF:
            return 0.0

        # Value = mantissa * 2^(exponent-bias), where the explicit integer bit
        # lives at bit 63 of the combined 64-bit mantissa.
        mantissa = (float(hi_mant) * 4294967296.0) + float(lo_mant)
        return sign * mantissa * (2.0 ** (expon - 16383 - 63))

    def _array_minmax(self, raw, width, byte_order):
        """C-speed min/max for signed 16/24/32-bit PCM (same scaling as the
        loops below). Returns None to fall back to the Python loops."""
        try:
            import array as _array
            import sys as _sys

            a = _array.array('h' if width == 2 else 'i')
            if a.itemsize != (2 if width == 2 else 4):
                return None

            if width in (2, 4):
                a.frombytes(raw)
                if byte_order != _sys.byteorder:
                    a.byteswap()
                scale = 32768.0 if width == 2 else 2147483648.0

            elif width == 3:
                # Widen to little-endian int32 (sample << 8) with C slicing.
                n = len(raw) // 3
                buf = bytearray(n * 4)
                if byte_order == 'little':
                    buf[1::4] = raw[0::3]
                    buf[2::4] = raw[1::3]
                    buf[3::4] = raw[2::3]
                else:
                    buf[1::4] = raw[2::3]
                    buf[2::4] = raw[1::3]
                    buf[3::4] = raw[0::3]
                a.frombytes(buf)
                if _sys.byteorder != 'little':
                    a.byteswap()
                scale = 2147483648.0

            else:
                return None

            if len(a) == 0:
                return (0.0, 0.0)
            return (float(min(a)) / scale, float(max(a)) / scale)

        except Exception:
            return None

    def _array_float_minmax(self, raw, byte_order):
        """C-speed min/max for float32, clamped to [-1, 1]. None -> slow path."""
        try:
            import array as _array
            import sys as _sys

            a = _array.array('f')
            if a.itemsize != 4:
                return None
            a.frombytes(raw)
            if byte_order != _sys.byteorder:
                a.byteswap()
            if len(a) == 0:
                return None

            mn = min(a)
            mx = max(a)
            if mn != mn or mx != mx:  # NaN leaked through: use slow path
                return None
            return (max(-1.0, min(1.0, mn)), max(-1.0, min(1.0, mx)))

        except Exception:
            return None

    def _pcm_minmax(self, raw, width, byte_order, unsigned_8bit):
        if not raw:
            return (0.0, 0.0)

        size = len(raw) - (len(raw) % width)
        if size <= 0:
            return (0.0, 0.0)

        
        if width in (2, 3, 4):
            fast = self._array_minmax(raw[:size], width, byte_order)
            if fast is not None:
                return fast

        # ------------------------------------------------------------
        # 8-bit
        # ------------------------------------------------------------
        if width == 1:
            mn = 127
            mx = -128

            for i in range(size):
                value = raw[i] & 0xFF

                if unsigned_8bit:
                    value -= 128
                elif value & 0x80:
                    value -= 0x100

                if value < mn:
                    mn = value
                if value > mx:
                    mx = value

            return (
                float(mn) / 128.0,
                float(mx) / 128.0
            )

        # ------------------------------------------------------------
        # 16-bit signed PCM
        # ------------------------------------------------------------
        if width == 2:
            mn = 32767
            mx = -32768

            if byte_order == 'little':
                for i in range(0, size, 2):
                    value = (
                        (raw[i] & 0xFF) |
                        ((raw[i + 1] & 0xFF) << 8)
                    )

                    if value & 0x8000:
                        value -= 0x10000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            else:
                for i in range(0, size, 2):
                    value = (
                        ((raw[i] & 0xFF) << 8) |
                        (raw[i + 1] & 0xFF)
                    )

                    if value & 0x8000:
                        value -= 0x10000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            return (
                float(mn) / 32768.0,
                float(mx) / 32768.0
            )

        # ------------------------------------------------------------
        # 24-bit signed PCM
        # ------------------------------------------------------------
        if width == 3:
            mn = 8388607
            mx = -8388608

            if byte_order == 'little':
                for i in range(0, size, 3):
                    value = (
                        (raw[i] & 0xFF) |
                        ((raw[i + 1] & 0xFF) << 8) |
                        ((raw[i + 2] & 0xFF) << 16)
                    )

                    if value & 0x800000:
                        value -= 0x1000000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            else:
                for i in range(0, size, 3):
                    value = (
                        ((raw[i] & 0xFF) << 16) |
                        ((raw[i + 1] & 0xFF) << 8) |
                        (raw[i + 2] & 0xFF)
                    )

                    if value & 0x800000:
                        value -= 0x1000000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            return (
                float(mn) / 8388608.0,
                float(mx) / 8388608.0
            )

        # ------------------------------------------------------------
        # 32-bit signed PCM
        # ------------------------------------------------------------
        if width == 4:
            mn = 2147483647
            mx = -2147483648

            if byte_order == 'little':
                for i in range(0, size, 4):
                    value = (
                        (raw[i] & 0xFF) |
                        ((raw[i + 1] & 0xFF) << 8) |
                        ((raw[i + 2] & 0xFF) << 16) |
                        ((raw[i + 3] & 0xFF) << 24)
                    )

                    if value & 0x80000000:
                        value -= 0x100000000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            else:
                for i in range(0, size, 4):
                    value = (
                        ((raw[i] & 0xFF) << 24) |
                        ((raw[i + 1] & 0xFF) << 16) |
                        ((raw[i + 2] & 0xFF) << 8) |
                        (raw[i + 3] & 0xFF)
                    )

                    if value & 0x80000000:
                        value -= 0x100000000

                    if value < mn:
                        mn = value
                    if value > mx:
                        mx = value

            return (
                float(mn) / 2147483648.0,
                float(mx) / 2147483648.0
            )

        return (0.0, 0.0)

    def _find_simpler_in_container(self, container):
        if container is None or not hasattr(container, 'devices'):
            return None

        try:
            devices = list(container.devices)
        except Exception:
            return None

        for device in devices:
            try:
                if str(getattr(device, 'class_name', '')) == 'OriginalSimpler':
                    return device
            except Exception:
                pass

            try:
                chains = list(getattr(device, 'chains', []))
            except Exception:
                chains = []

            for chain in chains:
                found = self._find_simpler_in_container(chain)
                if found is not None:
                    return found

        return None

    def _find_simpler_param(self, params, names):
        for param in params:
            try:
                name = str(getattr(param, 'name', ''))
                original = str(getattr(param, 'original_name', ''))
            except Exception:
                continue

            if name in names or original in names:
                return param

        return None


    def _sample_marker_to_cc(self, sample, prop):
        try:
            length = float(getattr(sample, 'length', 0) or 0)
            marker = float(getattr(sample, prop, 0) or 0)

            if length <= 0:
                return None

            normalized = max(0.0, min(1.0, marker / length))
            return max(0, min(127, int(round(normalized * 127.0))))

        except Exception:
            return None


    def _get_simpler_write_targets(self, simpler):
        """Same 24-slot layout as the Bridge; slots 14, 15 and 19 are reserved."""
        targets = [None] * self.SIMPLER_SNAPSHOT_PARAM_COUNT
        try:
            params = list(simpler.parameters)
            mode = int(simpler.playback_mode)
            sample = simpler.sample
        except Exception:
            return targets
        names = {
            0: ('Transpose',), 1: ('Detune',), 2: ('Pan',), 3: ('Volume',),
            8: ('F On',), 9: ('Filter Type',),
            10: ('Filter Circuit - LP/HP', 'Filter Circuit - BP/NO/Morph'),
            11: ('Filt < Vel',), 12: ('Filter Res',), 13: ('Filter Freq',),
            16: ('Spread',), 17: ('Vol < Vel',), 18: ('Pan < Rnd',),
            20: ('Ve Attack',) if mode == 0 else ('Fade In',),
            21: ('Ve Decay',), 22: ('Ve Sustain',),
            23: ('Ve Release',) if mode == 0 else ('Fade Out',)
        }
        for slot, candidates in names.items():
            param = self._find_simpler_param(params, candidates)
            if param is not None:
                targets[slot] = (param, 'value')
        if sample is not None:
            targets[4] = (sample, 'start_marker')
            targets[5] = (sample, 'end_marker')
        for slot, param_name, marker in ((6, 'S Start', 4), (7, 'S Length', 5)):
            param = self._find_simpler_param(params, (param_name,)) if mode == 0 else None
            targets[slot] = (param, 'value') if param is not None else targets[marker]
        return targets

    def _get_simpler_snapshot_state(self, simpler):
        values = [0] * self.SIMPLER_SNAPSHOT_PARAM_COUNT
        presence_mask = 0

        try:
            params = list(simpler.parameters)
        except Exception:
            params = []

        # One pass over the params instead of ~20 full scans.
        # Same result as _find_simpler_param: earliest param matching
        # any of the names by name or original_name.
        index = {}
        for i, p in enumerate(params):
            try:
                index.setdefault(str(getattr(p, 'name', '')), (i, p))
                index.setdefault(str(getattr(p, 'original_name', '')), (i, p))
            except Exception:
                pass

        def find(names):
            hits = [index[n] for n in names if n in index]
            return min(hits, key=lambda h: h[0])[1] if hits else None

        def put(slot, names):
            param = find(names)

            if param is None:
                return

            values[slot] = self._param_to_cc_value(param)
            nonlocal_presence[0] |= (1 << slot)

        # Python 2-compatible mutable closure storage.
        nonlocal_presence = [0]

        put(0, ("Transpose",))
        put(1, ("Detune",))
        put(2, ("Pan",))
        put(3, ("Volume",))

        put(8, ("F On",))
        put(9, ("Filter Type",))
        put(10, ("Filter Circuit - LP/HP", "Filter Circuit - BP/NO/Morph"))
        put(11, ("Filt < Vel",))
        put(12, ("Filter Res",))
        put(13, ("Filter Freq",))

        put(16, ("Spread",))
        put(17, ("Vol < Vel",))
        put(18, ("Pan < Rnd",))

        put(21, ("Ve Decay",))
        put(22, ("Ve Sustain",))

        try:
            playback_mode = int(getattr(simpler, 'playback_mode', 0) or 0)
        except Exception:
            playback_mode = 0

        try:
            sample = getattr(simpler, 'sample', None)
        except Exception:
            sample = None

        start_cc = self._sample_marker_to_cc(sample, 'start_marker') if sample is not None else None
        end_cc = self._sample_marker_to_cc(sample, 'end_marker') if sample is not None else None

        # Absolute Start / End.
        if start_cc is not None:
            values[4] = start_cc
            nonlocal_presence[0] |= (1 << 4)

        if end_cc is not None:
            values[5] = end_cc
            nonlocal_presence[0] |= (1 << 5)

        # Hidden p-lock bases.
        s_start = find(("S Start",))
        s_length = find(("S Length",))

        if playback_mode == 0 and s_start is not None:
            values[6] = self._param_to_cc_value(s_start)
            nonlocal_presence[0] |= (1 << 6)
        elif start_cc is not None:
            values[6] = start_cc
            nonlocal_presence[0] |= (1 << 6)

        if playback_mode == 0 and s_length is not None:
            values[7] = self._param_to_cc_value(s_length)
            nonlocal_presence[0] |= (1 << 7)
        elif end_cc is not None:
            values[7] = end_cc
            nonlocal_presence[0] |= (1 << 7)

        # Attack / Release mode destinations.
        if playback_mode == 0:
            put(20, ("Ve Attack",))
            put(23, ("Ve Release",))
        else:
            put(20, ("Fade In",))
            put(23, ("Fade Out",))

        presence_mask = nonlocal_presence[0]

        return presence_mask, values

    def _get_pad_info_for_note(self, drum_rack, note):
        try:
            if hasattr(drum_rack, 'drum_pads') and drum_rack.drum_pads is not None:
                pads = drum_rack.drum_pads
                # drum_pads is ordered by note: index directly, scan only if not.
                candidates = pads
                try:
                    if 0 <= note < len(pads) and pads[note].note == note:
                        candidates = (pads[note],)
                except Exception:
                    pass
                for pad in candidates:
                    if hasattr(pad, 'note') and pad.note == note:
                        chain = None
                        pad_name = ''
                        if hasattr(pad, 'chains') and len(pad.chains) > 0:
                            chain = pad.chains[0]
                            pad_name = chain.name if hasattr(chain, 'name') else ''
                        if hasattr(pad, 'name') and pad.name:
                            pad_name = pad.name
                        return {'pad': pad, 'chain': chain, 'name': pad_name}
        except Exception as e:
            self._debug("PrismScript: pad info error for note %d: %s"
                        % (note, str(e)))
        return None
