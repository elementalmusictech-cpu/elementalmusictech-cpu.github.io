from __future__ import absolute_import, print_function, unicode_literals
from .PrismSessionConnector import PrismSessionConnector

import Live
import random

class PrismBrowserConnector(object):
    REQUEST_TYPE = 0x31
    RESPONSE_TYPE = 0x32

    CMD_GET_ROOTS = 0x01
    CMD_GET_CHILDREN = 0x02
    CMD_LOAD_ITEM = 0x03
    CMD_PREVIEW_ITEM = 0x04
    CMD_STOP_PREVIEW = 0x05
    CMD_RANDOM_ITEMS = 0x06
    CMD_RESYNC_ALL = 0x07

    RESP_LIST_BEGIN = 0x01
    RESP_ITEM = 0x02
    RESP_LIST_END = 0x03
    RESP_LOAD_OK = 0x04
    RESP_ERROR = 0x7F

    FLAG_HAS_CHILDREN = 1 << 0
    FLAG_LOADABLE = 1 << 1
    FLAG_DEVICE = 1 << 2
    FLAG_FOLDER = 1 << 3
    FLAG_RACK = 1 << 4

    PAGE_SIZE = 32
    MAX_NAME_LENGTH = 60
    MAX_ITEM_ID = 16383

    ERR_BAD_COMMAND = 1
    ERR_ITEM_NOT_FOUND = 2
    ERR_NOT_LOADABLE = 3
    ERR_TRACK_NOT_FOUND = 4
    ERR_BROWSER = 5
    ERR_REGISTRY_FULL = 6

    ROOTS = (
        ("Sounds", "sounds"),
        ("Drums", "drums"),
        ("Instruments", "instruments"),
        ("Samples","samples"),
        ("Plug-Ins", "plugins"),
    )

    def __init__(self, script):
        self._s = script
        self._session = PrismSessionConnector(script)
        self.reset()

    def reset(self):
        self._items = {}
        self._item_keys = {}
        self._next_item_id = 1
        try:
            Live.Application.get_application().browser.stop_preview()
        except Exception:
            pass

    def receive(self, midi_bytes):
        if len(midi_bytes) < 8: return
        if midi_bytes[0] != 0xF0 or midi_bytes[1] != 0x7D or midi_bytes[2] != self.REQUEST_TYPE: return
        command = midi_bytes[3] & 0x7F
        item_id = (midi_bytes[4] & 0x7F) | ((midi_bytes[5] & 0x7F) << 7)
        argument = midi_bytes[6] & 0x7F
        if not self._session.handles(command):  # session info is polled every second
            self._s.log_message("PrismBrowser: RX cmd=0x%02X item=%d arg=%d" % (command, item_id, argument))
        if command == self.CMD_GET_ROOTS: self._get_roots()
        elif command == self.CMD_GET_CHILDREN: self._get_children(item_id, argument)
        elif command == self.CMD_LOAD_ITEM: self._load_item(item_id, argument)
        elif command == self.CMD_PREVIEW_ITEM: self._preview_item(item_id)
        elif command == self.CMD_STOP_PREVIEW: self._stop_preview()
        elif command == self.CMD_RANDOM_ITEMS: self._get_random_items(item_id, argument)
        elif command == self.CMD_RESYNC_ALL:
            self._resync_all(item_id, argument)
        elif self._session.handles(command): self._session.receive(command, midi_bytes)
        else: self._send_error(self.ERR_BAD_COMMAND, "Unknown browser command")


    def _get_roots(self):
        try:
            browser = Live.Application.get_application().browser
            try: browser.stop_preview()
            except Exception: pass

            entries = self._root_entries()
            self._send_list_begin(0, 0, False)

            for item, fallback_name, collection_style in entries:
                self._send_item(self._register_item(item), item, fallback_name, collection_style)

            self._send_list_end(0, 0, False)
            self._s.log_message("PrismBrowser: roots sent count=%d" % len(entries))

        except Exception as e:
            self._send_error(self.ERR_BROWSER, "Roots failed: %s" % str(e))

    def _get_children(self, item_id, page):
        item = self._items.get(item_id)

        if item is None:
            self._send_error(self.ERR_ITEM_NOT_FOUND, "Browser item not found")
            return

        try:
            children = self._ordered_browser_children(
                getattr(item, "children", ()) or ()
            )

            page = max(0, min(int(page), 127))

            start = page * self.PAGE_SIZE
            end = min(start + self.PAGE_SIZE, len(children))

            has_more = end < len(children)

            self._send_list_begin(item_id, page, has_more)

            for child in children[start:end]:
                child_id = self._register_item(child)
                self._send_item(child_id, child, "")

            self._send_list_end(item_id, page, has_more)

            self._s.log_message(
                "PrismBrowser: children parent=%d page=%d sent=%d total=%d more=%s"
                % (
                    item_id,
                    page,
                    end - start,
                    len(children),
                    str(has_more)
                )
            )

        except Exception as e:
            self._send_error(
                self.ERR_BROWSER,
                "Children failed: %s" % str(e)
            )

    def _get_random_items(self, parent_id, count):
        try:
            count = max(1, min(int(count), self.PAGE_SIZE))

            # --------------------------------------------------------
            # Resolve the CURRENT LEVEL.
            # These immediate navigation folders are always retained.
            # --------------------------------------------------------

            if parent_id == 0:
                browser = Live.Application.get_application().browser
                entries = self._root_entries()

                collections = [(item, fallback, style) for item, fallback, style in entries if style > 0]
                categories = [(item, fallback, style) for item, fallback, style in entries if style == 0]

                categories.sort(key=lambda x: self._item_name(x[0], x[1]).lower())
                folders = collections + categories

                # Deliberately random-search only the real Library roots.
                # Collections are alternate/tagged views of the same content and would
                # otherwise weight tagged content more heavily.
                work = [item for item, _, _ in categories]

            else:
                parent = self._items.get(parent_id)

                if parent is None:
                    self._send_error(
                        self.ERR_ITEM_NOT_FOUND,
                        "Browser item not found"
                    )
                    return

                direct_children = list(
                    getattr(parent, "children", ()) or ()
                )

                navigation = [
                    item
                    for item in direct_children
                    if self._item_is_navigation(item)
                ]

                navigation.sort(
                    key=lambda item: self._item_name(
                        item,
                        ""
                    ).lower()
                )

                folders = [
                    (item, "", 0)
                    for item in navigation
                ]

                # Start inside the current folder, not with the parent
                # itself. This also prevents a loadable parent from
                # appearing as one of its own random results.
                work = direct_children

            # --------------------------------------------------------
            # Folders consume part of the page budget.
            #
            # Example:
            # PAGE_SIZE = 32
            # root folders = 4
            # random content = 28
            # total visible rows = 32
            # --------------------------------------------------------

            random_slots = max(0, count - len(folders))

            found = []
            seen = set()
            visits = 0

            while (
                work
                and len(found) < random_slots
                and visits < 5000
            ):
                node = work.pop(random.randrange(len(work)))

                key = self._browser_item_key(node)

                if key in seen:
                    continue

                seen.add(key)
                visits += 1

                is_navigation = self._item_is_navigation(node)

                # Navigation items are NEVER part of the randomized
                # result section. They may still be traversed.
                if not is_navigation:
                    try:
                        if bool(getattr(node, "is_loadable", False)):
                            found.append(node)
                    except Exception:
                        pass

                try:
                    children = list(
                        getattr(node, "children", ()) or ()
                    )

                    random.shuffle(children)
                    work.extend(children)

                except Exception:
                    pass

            # --------------------------------------------------------
            # Stable navigation first, randomized content second.
            # --------------------------------------------------------

            self._send_list_begin(
                parent_id,
                0,
                False
            )

            for entry in folders:
                item = entry[0]
                fallback_name = entry[1]
                collection_style = entry[2] if len(entry) > 2 else 0
                self._send_item(self._register_item(item), item, fallback_name, collection_style)

            for item in found:
                self._send_item(
                    self._register_item(item),
                    item,
                    ""
                )

            self._send_list_end(
                parent_id,
                0,
                False
            )

            self._s.log_message(
                "PrismBrowser: random parent=%d folders=%d random=%d visits=%d"
                % (
                    parent_id,
                    len(folders),
                    len(found),
                    visits
                )
            )

        except Exception as e:
            self._send_error(
                self.ERR_BROWSER,
                "Random Browser failed: %s" % str(e)
            )

    def _load_item(self, item_id, track_id):
        item = self._items.get(item_id)
        if item is None:
            self._send_error(self.ERR_ITEM_NOT_FOUND, "Browser item not found")
            return

        try:
            if not bool(getattr(item, "is_loadable", False)):
                self._send_error(self.ERR_NOT_LOADABLE, "Item is not loadable")
                return

            # SAMPLE LAB OVERRIDE
            sample_target = getattr(self._s, "_sample_lab_browser_target", None)

            if sample_target is not None:
                try:
                    sample_track = int(sample_target[0])
                    sample_pad = int(sample_target[1])
                except Exception:
                    sample_track = -1
                    sample_pad = -1

                if int(track_id) == sample_track and 0 <= sample_pad < 16:
                    loader = getattr(
                        self._s,
                        "_sample_lab_replace_browser_item",
                        None
                    )

                    if loader is None:
                        self._send_error(
                            self.ERR_BROWSER,
                            "Sample Lab loader unavailable"
                        )
                        return

                    ok, text = loader(
                        item,
                        sample_track,
                        sample_pad
                    )

                    if not ok:
                        self._send_error(
                            self.ERR_BROWSER,
                            text or "Sample replacement failed"
                        )
                        return

                    self._send_load_ok(item_id)

                    self._s.log_message(
                        "PrismBrowser: SAMPLE replace "
                        "item=%d track=%d pad=%d name='%s'"
                        % (
                            item_id,
                            sample_track,
                            sample_pad,
                            self._item_name(item, "")
                        )
                    )

                    return

            # track_id is the Prism track ID.
            # Resolve its actual Ableton destination through TrackLink.
            link = getattr(self._s, "_links", {}).get(track_id)

            if link is None or getattr(link, "_detached", False):
                self._send_error(
                    self.ERR_TRACK_NOT_FOUND,
                    "Prism channel not connected"
                )
                return

            # Keep Browser structural transactions serialized for now.
            existing = getattr(self._s, "_browse_handoff_track_id", None)
            if existing is not None:
                self._send_error(
                    self.ERR_BROWSER,
                    "Another Browser load is already in progress"
                )
                return

            target_track = link.track
            self._s._browse_handoff_track_id = track_id

            def release_failed(reason):
                if getattr(self._s, "_browse_handoff_track_id", None) == track_id:
                    self._s._browse_handoff_track_id = None

                self._s.log_message(
                    "PrismBrowser: load CANCELLED item=%d track=%d reason='%s'"
                    % (item_id, track_id, str(reason))
                )

                self._send_error(
                    self.ERR_BROWSER,
                    "Load cancelled: %s" % str(reason)
                )

            def release_complete(gen):
                if getattr(link, "_detached", False):
                    release_failed("track disconnected before load")
                    return

                # Stale Browser continuations must never load anything.
                if getattr(link, "_release_generation", 0) != gen:
                    return

                if getattr(self._s, "_browse_handoff_track_id", None) != track_id:
                    return

                previous_track = None
                previous_suppress = getattr(
                    self._s,
                    "_suppress_selection",
                    False
                )
                load_succeeded = False

                try:
                    try:
                        previous_track = self._s.song().view.selected_track
                    except Exception:
                        pass

                    self._s._suppress_selection = True
                    self._s.song().view.selected_track = target_track

                    self._s.log_message(
                        "PrismBrowser: release fence PASSED gen=%d item=%d track=%d"
                        % (gen, item_id, track_id)
                    )

                    browser = Live.Application.get_application().browser
                    try:
                        self._s.log_message(
                            "PrismBrowser: HOTSWAP target=%s targetType=%s filter=%s relation=%s"
                            % (
                                str(browser.hotswap_target),
                                type(browser.hotswap_target).__name__,
                                str(browser.filter_type),
                                str(browser.relation_to_hotswap_target(item))
                            )
                        )
                    except Exception as e:
                        self._s.log_message(
                            "PrismBrowser: HOTSWAP INFO ERROR %s" % str(e)
                        )

                    # THIS is now behind the Max release acknowledgment.
                    Live.Application.get_application().browser.load_item(item)

                    load_succeeded = True
                    link._mark_preset_handoff_activity()

                except Exception as e:
                    self._s.log_message(
                        "PrismBrowser: load failed after release gen=%d item=%d track=%d: %s"
                        % (gen, item_id, track_id, str(e))
                    )

                    self._send_error(
                        self.ERR_BROWSER,
                        "Load failed: %s" % str(e)
                    )

                finally:
                    try:
                        if previous_track is not None:
                            self._s.song().view.selected_track = previous_track
                    except Exception:
                        pass

                    self._s._suppress_selection = previous_suppress

                    if not load_succeeded:
                        if getattr(self._s, "_browse_handoff_track_id", None) == track_id:
                            self._s._browse_handoff_track_id = None

                        link.cancel_macro_handoff()

                if not load_succeeded:
                    return

                self._send_load_ok(item_id)

                self._s.log_message(
                    "PrismBrowser: load issued item=%d track=%d gen=%d name='%s'"
                    % (
                        item_id,
                        track_id,
                        gen,
                        self._item_name(item, "")
                    )
                )

            link.request_prism_browser_release(
                release_complete,
                release_failed
            )

        except Exception as e:
            if getattr(self._s, "_browse_handoff_track_id", None) == track_id:
                self._s._browse_handoff_track_id = None

            self._send_error(
                self.ERR_BROWSER,
                "Load failed: %s" % str(e)
            )

    def _preview_item(self, item_id):
        item = self._items.get(item_id)
        if item is None:
            self._send_error(self.ERR_ITEM_NOT_FOUND, "Browser item not found")
            return
        try:
            if not bool(getattr(item, "is_loadable", False)):
                self._send_error(self.ERR_NOT_LOADABLE, "Item is not previewable")
                return
            browser = Live.Application.get_application().browser
            browser.stop_preview()
            browser.preview_item(item)
            self._s.log_message("PrismBrowser: preview item=%d name='%s'" % (item_id, self._item_name(item, "")))
        except Exception as e:
            self._send_error(self.ERR_BROWSER, "Preview failed: %s" % str(e))

    def _resync_all(self, mask_low14=0, mask_high=0):
        try:
            mask = (int(mask_low14) & 0x3FFF) | ((int(mask_high) & 0x03) << 14)
            self._s._resync_all_connected_tracks(mask)
            self._s.log_message("PrismBrowser: global resync requested mask=0x%04X" % mask)
        except Exception as e:
            self._send_error(self.ERR_BROWSER, "Resync failed: %s" % str(e))

    def _stop_preview(self):
        try:
            Live.Application.get_application().browser.stop_preview()
            self._s.log_message("PrismBrowser: preview stopped")
        except Exception as e:
            self._send_error(self.ERR_BROWSER, "Stop preview failed: %s" % str(e))

    def _register_item(self, item):
        key = None
        try:
            uri = getattr(item, "uri", None)
            if uri: key = "uri:" + str(uri)
        except Exception:
            pass
        if key is None: key = "obj:" + str(id(item))
        existing = self._item_keys.get(key)
        if existing is not None:
            self._items[existing] = item
            return existing
        if self._next_item_id > self.MAX_ITEM_ID:
            raise RuntimeError("browser item registry full")
        item_id = self._next_item_id
        self._next_item_id += 1
        self._items[item_id] = item
        self._item_keys[key] = item_id
        return item_id

    def _item_has_children(self, item):
        try:
            children = getattr(item, "children", None)
            return children is not None and len(children) > 0
        except Exception:
            return False

    def _item_is_navigation(self, item):
        try:
            if bool(getattr(item, "is_folder", False)):
                return True
        except Exception:
            pass
        return self._item_has_children(item)

    def _ordered_browser_children(self, children):
        children = list(children or ())
        folders = [item for item in children if self._item_is_navigation(item)]
        content = [item for item in children if not self._item_is_navigation(item)]
        folders.sort(key=lambda item: self._item_name(item, "").lower())
        return folders + content

    def _root_entries(self):
        browser = Live.Application.get_application().browser
        collections = []
        try:
            for item in tuple(getattr(browser, "colors", ()) or ()):
                collections.append((item, "", self._collection_style(item)))
        except Exception:
            pass
        categories = []
        for fallback_name, property_name in self.ROOTS:
            item = getattr(browser, property_name, None)
            if item is not None:
                categories.append((item, fallback_name, 0))
        return collections + categories

    def _browser_item_key(self, item):
        try:
            uri = getattr(item, "uri", None)
            if uri:
                return "uri:" + str(uri)
        except Exception:
            pass
        return "obj:" + str(id(item))

    def _item_name(self, item, fallback):
        try:
            name = str(item.name)
            if name: return name
        except Exception:
            pass
        return fallback

    def _item_is_rack(self, item):
        name = self._item_name(item, "").lower()
        if name.endswith(".adg"): return True
        try:
            uri = str(getattr(item, "uri", "") or "").lower()
            if ".adg" in uri: return True
        except Exception:
            pass
        return False

    def _item_flags(self, item):
        flags = 0
        try:
            children = getattr(item, "children", None)
            if children is not None and len(children) > 0: flags |= self.FLAG_HAS_CHILDREN
        except Exception:
            pass
        try:
            if bool(getattr(item, "is_loadable", False)): flags |= self.FLAG_LOADABLE
        except Exception:
            pass
        try:
            if bool(getattr(item, "is_device", False)): flags |= self.FLAG_DEVICE
        except Exception:
            pass
        try:
            if bool(getattr(item, "is_folder", False)): flags |= self.FLAG_FOLDER
        except Exception:
            pass
        if self._item_is_rack(item): flags |= self.FLAG_RACK
        return flags & 0x7F

    def _safe_text(self, text):
        try: text = str(text)
        except Exception: text = ""
        try: text = text.encode("ascii", "replace").decode("ascii")
        except Exception: pass
        result = []
        for c in text:
            value = ord(c)
            result.append(value if 32 <= value <= 126 else ord("?"))
            if len(result) >= self.MAX_NAME_LENGTH: break
        return result

    def _send_list_begin(self, parent_id, page, has_more):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LIST_BEGIN, parent_id & 0x7F, (parent_id >> 7) & 0x7F, page & 0x7F, 1 if has_more else 0, 0xF7))

    def _send_item(self, item_id, item, fallback_name, collection_style=0):
        message = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_ITEM, item_id & 0x7F, (item_id >> 7) & 0x7F, self._item_flags(item), collection_style & 0x7F]
        message.extend(self._safe_text(self._item_name(item, fallback_name)))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _send_list_end(self, parent_id, page, has_more):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LIST_END, parent_id & 0x7F, (parent_id >> 7) & 0x7F, page & 0x7F, 1 if has_more else 0, 0xF7))

    def _send_load_ok(self, item_id):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LOAD_OK, item_id & 0x7F, (item_id >> 7) & 0x7F, 0xF7))

    def _send_error(self, code, text):
        message = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_ERROR, code & 0x7F]
        message.extend(self._safe_text(text))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _collection_style(self, item):
        try:
            uri = str(getattr(item, "uri", "") or "")
            prefix = "color:colors="
            if uri.startswith(prefix):
                value = int(uri[len(prefix):])
                if 1 <= value <= 7: return value
        except Exception:
            pass
        return 0
