from __future__ import absolute_import, print_function, unicode_literals

import os, json, subprocess, random

# ============================================================================
# PrismSessionConnector.py
#
# Siloed Ableton Live Set/session helper.
#
# This intentionally rides inside the existing Browser wire:
#   Prism -> Live  : 0x31
#   Live  -> Prism : 0x32
#
# Commands 0x01...0x07 remain owned by PrismBrowserConnector.
# This helper owns 0x08+ only.
#
# PrismBrowserConnector needs only:
#   from .PrismSessionConnector import PrismSessionConnector
#   self._session = PrismSessionConnector(script)
#   ...
#   elif self._session.handles(command):
#       self._session.receive(command)
#
# No Simpler / mapped-param / TrackLink behavior lives here.
# ============================================================================


class PrismSessionConnector(object):
    CMD_GET_SESSION_INFO = 0x08
    CMD_SAVE_SET = 0x09
    CMD_SET_PAIR_CHUNK = 0x0A
    CMD_OPEN_PAIRED_SET = 0x0B

    RESP_SESSION_INFO = 0x05
    RESP_SAVE_STARTED = 0x06
    RESP_SAVE_RESULT = 0x07
    RESP_SAVE_EVENT = 0x08
    RESP_SET_CONTEXT = 0x09

    PAIR_PARAM_NAMES = ("__PrismPair0__", "__PrismPair1__", "__PrismPair2__")
    PAIR_CHUNK_COUNT = 3
    PAIR_DATA_KEY = "com.prism.pair-id.v1"
    PAIR_ID_LIMIT = 1 << 42

    SAVE_RESULT_OK = 0
    SAVE_RESULT_NEEDS_SAVE_AS = 1
    SAVE_RESULT_REQUESTED = 2
    SAVE_RESULT_FAILED = 3

    MAX_NAME_LENGTH = 60

    POLL_TICKS = 10
    SAVE_TIMEOUT_TICKS = 30
    SAVE_AS_FRESH_SECONDS = 5.0

    def __init__(self, script):
        self._s = script
        self._context_song = self._s.song()
        self._set_token = random.randint(1, (1 << 28) - 1)
        self._pair_conflicted = False

        self._last_path = None
        self._last_mtime = None
        self._pair_paths = self._load_pair_paths()
        self._pending_pair = None

        # Monotonic session-local save revision. Prism can compare this after
        # returning from Browser even if a manual Live save happened while the
        # Browser UI owned the shared response queue.
        self._save_revision = 0

        self._save_in_flight = False
        self._save_generation = 0

        try:
            self._s.log_message("PrismSession: INIT")
        except Exception:
            pass

        self._schedule_poll()

    def handles(self, command):
        return command in (
            self.CMD_GET_SESSION_INFO,
            self.CMD_SAVE_SET,
            self.CMD_SET_PAIR_CHUNK,
            self.CMD_OPEN_PAIRED_SET
        )

    def _current_set_token(self):
        song = self._s.song()
        if song != self._context_song:
            self._context_song = song
            self._set_token = random.randint(1, (1 << 28) - 1)
            self._pending_pair = None
            self._pair_conflicted = False
            self._save_revision = 0
            self._last_path = None
            self._last_mtime = None
            self._save_generation += 1
            self._save_in_flight = False
        return self._set_token

    def _set_token_bytes(self):
        token = self._current_set_token()
        return [(token >> (7 * index)) & 0x7F for index in range(4)]

    def receive(self, command, midi_bytes=None):
        token = self._current_set_token()
        if command in (self.CMD_SAVE_SET, self.CMD_SET_PAIR_CHUNK):
            if midi_bytes is None or len(midi_bytes) < 13 or int(midi_bytes[7]) != 0x7F:
                return
            requested_token = sum(
                (int(midi_bytes[8 + index]) & 0x7F) << (7 * index)
                for index in range(4)
            )
            if requested_token != token:
                self._send_set_context()
                return
        if command == self.CMD_GET_SESSION_INFO:
            self._send_session_info()
            self._send_set_context()
            return

        if command == self.CMD_SAVE_SET:
            name = self._suggested_name_from_request(midi_bytes)
            name_only = (
                midi_bytes is not None and
                len(midi_bytes) > 4 and
                int(midi_bytes[4]) == 1
            )

            if name_only:
                if name:
                    self._s.set_prism_project_name(name)
                return

            self._save_set(name)
            return

        if command == self.CMD_SET_PAIR_CHUNK:
            if midi_bytes is None or len(midi_bytes) < 8:
                return

            chunk_value = (
                (int(midi_bytes[4]) & 0x7F) |
                ((int(midi_bytes[5]) & 0x7F) << 7)
            )
            chunk_index = int(midi_bytes[6]) & 0x7F

            self._set_pair_chunk(chunk_index, chunk_value)
            return

        if command == self.CMD_OPEN_PAIRED_SET:
            if midi_bytes is None or len(midi_bytes) < 11:
                return

            p0 = int(midi_bytes[4]) | (int(midi_bytes[5]) << 7)
            p1 = int(midi_bytes[6]) | (int(midi_bytes[7]) << 7)
            p2 = int(midi_bytes[8]) | (int(midi_bytes[9]) << 7)

            pair_id = p0 | (p1 << 14) | (p2 << 28)

            self._s.log_message(
                "PrismSession: RX OPEN_PAIR pair=%d" % pair_id
            )

            self._open_paired_set(pair_id)
            return
        

    def _suggested_name_from_request(self, midi_bytes):
        if midi_bytes is None or len(midi_bytes) <= 13:
            return ""

        # F0 7D 31 09 flags 00 00 7F token[4] [name...] F7
        raw = midi_bytes[12:-1]

        try:
            return "".join(
                chr(int(b) & 0x7F)
                for b in raw
                if 32 <= (int(b) & 0x7F) <= 126
            ).strip()
        except Exception:
            return ""

    # ------------------------------------------------------------------
    # Current Set
    # ------------------------------------------------------------------

    def _current_set_info(self):
        try:
            import os

            song = self._s.song()
            path = str(getattr(song, "file_path", "") or "")

            if path:
                name = os.path.basename(path)
            else:
                try:
                    name = str(getattr(song, "name", "") or "")
                except Exception:
                    name = ""

                if not name:
                    name = "Unsaved Set"

            return path, name

        except Exception:
            return "", "Unsaved Set"

    def _mtime(self, path):
        if not path:
            return None

        try:
            import os

            if not os.path.isfile(path):
                return None

            return os.path.getmtime(path)

        except Exception:
            return None

    def _is_recent_write(self, mtime):
        if mtime is None:
            return False

        try:
            import time
            age = abs(time.time() - float(mtime))
            return age <= self.SAVE_AS_FRESH_SECONDS
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Save monitoring
    # ------------------------------------------------------------------

    def _schedule_poll(self):
        try:
            self._s.schedule_message(self.POLL_TICKS, self._poll)
        except Exception:
            pass

    def _poll(self):
        try:
            self._current_set_token()
            path, name = self._current_set_info()
            mtime = self._mtime(path)
            save_detected = False
            reason = ""

            if self._last_path is None:
                self._last_path = path
                self._last_mtime = mtime

                try:
                    self._s.log_message(
                        "PrismSession: baseline path='%s' mtime=%s"
                        % (path, str(mtime))
                    )
                except Exception:
                    pass

                self._send_set_context()
                self._send_session_info()

            elif path != self._last_path:
                old_path = self._last_path
                self._last_path = path
                self._last_mtime = mtime

                if path and self._is_recent_write(mtime):
                    save_detected = True
                    reason = "save-as"
                else:
                    try:
                        self._s.log_message(
                            "PrismSession: Set path changed (not save) '%s' -> '%s'"
                            % (old_path, path)
                        )
                    except Exception:
                        pass

                # Push new Live Set identity even when this was only a load.
                self._send_session_info()
                self._send_set_context()

            elif (
                mtime is not None and
                self._last_mtime is not None and
                mtime != self._last_mtime
            ):
                old_mtime = self._last_mtime
                self._last_mtime = mtime
                save_detected = True
                reason = "mtime"

                try:
                    self._s.log_message(
                        "PrismSession: mtime changed %s -> %s"
                        % (str(old_mtime), str(mtime))
                    )
                except Exception:
                    pass

            elif self._last_mtime is None and mtime is not None:
                self._last_mtime = mtime
                save_detected = True
                reason = "first-write"

            if save_detected:
                self._save_revision = (self._save_revision + 1) & 0x3FFF

                try:
                    self._s.log_message(
                        "PrismSession: SAVE DETECTED reason=%s revision=%d name='%s'"
                        % (reason, self._save_revision, name)
                    )
                except Exception:
                    pass

                # Explicit save event is the primary Sync Save trigger.
                self._send_save_event(name)

                # Session info remains authoritative metadata + catch-up revision.
                self._send_session_info()

                if self._save_in_flight:
                    self._save_in_flight = False
                    self._send_save_result(
                        self.SAVE_RESULT_OK,
                        "Saved %s" % name
                    )

        except Exception as e:
            try:
                self._s.log_message(
                    "PrismSession: poll error: %s" % str(e)
                )
            except Exception:
                pass

        self._schedule_poll()

    # ------------------------------------------------------------------
    # Save command
    # ------------------------------------------------------------------

    def _save_set(self, suggested_name=""):
        path, _name = self._current_set_info()

        if self._save_in_flight:
            return

        self._save_in_flight = True
        self._save_generation += 1
        generation = self._save_generation

        self._send_save_started()

        clean_name = str(suggested_name or "").strip()

        if clean_name:
            try:
                self._s.set_prism_project_name(clean_name)
            except Exception as e:
                try:
                    self._s.log_message(
                        "PrismSession: project-name update failed: %s" % str(e)
                    )
                except Exception:
                    pass

        needs_save_as = not bool(path)

        try:
            self._s.log_message(
                "PrismSession: SAVE REQUEST saveAs=%d suggested='%s'"
                % (1 if needs_save_as else 0, suggested_name)
            )
        except Exception:
            pass

        intended_song = self._s.song()
        intended_token = self._current_set_token()

        def perform(g=generation, name=suggested_name, save_as=needs_save_as):
            if (not self._s._connected or self._s.song() != intended_song or
                    self._current_set_token() != intended_token):
                if g == self._save_generation:
                    self._save_in_flight = False
                return
            self._perform_save(g, name if save_as else "")

        self._s.schedule_message(1, perform)

    def _perform_save(self, generation, suggested_name=""):
        self._s.log_message(
            "PrismSession: PERFORM SAVE suggested='%s'" % suggested_name
        )
        if (
            generation != self._save_generation or
            not self._save_in_flight
        ):
            return

        try:
            import subprocess

            script = '''
            on run argv
                set suggestedName to ""

                if (count of argv) > 0 then
                    set suggestedName to item 1 of argv
                end if

                tell application id "com.ableton.live"
                    activate
                end tell

                tell application "System Events"
                    set liveProc to first application process whose bundle identifier is "com.ableton.live"

                    tell liveProc
                        set frontmost to true
                    end tell

                    delay 0.15

                    tell liveProc
                        keystroke "s" using {command down}
                    end tell
                end tell

                if suggestedName is not "" then
                    repeat 30 times
                        delay 0.1

                        tell application "System Events"
                            tell liveProc
                                try
                                    set focusedItem to value of attribute "AXFocusedUIElement"
                                    set focusedRole to value of attribute "AXRole" of focusedItem

                                    if focusedRole is "AXTextField" or focusedRole is "AXComboBox" then
                                        set value of focusedItem to suggestedName
                                        return "NAME_SET role=" & focusedRole
                                    end if
                                end try
                            end tell
                        end tell
                    end repeat

                    return "NAME_FIELD_NOT_FOCUSED"
                end if

                return "SAVE_TRIGGERED"
            end run
            '''

            args = ["/usr/bin/osascript", "-e", script]

            if suggested_name:
                args.append(suggested_name)

            process = subprocess.Popen(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            try:
                _stdout, stderr = process.communicate(timeout=2.0)
            except TypeError:
                _stdout, stderr = process.communicate()

            if process.returncode != 0:
                self._save_in_flight = False

                try:
                    text = stderr.decode("utf-8", "replace").strip()
                except Exception:
                    text = ""

                self._send_save_result(
                    self.SAVE_RESULT_FAILED,
                    text or "Could not trigger Ableton Save"
                )
                return

            def timeout(g=generation):
                self._save_timeout(g)

            self._s.schedule_message(
                self.SAVE_TIMEOUT_TICKS,
                timeout
            )

        except Exception as e:
            self._save_in_flight = False
            self._send_save_result(
                self.SAVE_RESULT_FAILED,
                "Save failed: %s" % str(e)
            )

    def _save_timeout(self, generation):
        if (
            generation != self._save_generation or
            not self._save_in_flight
        ):
            return

        # Cmd+S can legitimately produce no file timestamp change if the Set
        # was already clean. Report the command as requested rather than
        # claiming a confirmed disk write.
        self._save_in_flight = False

        self._send_save_result(
            self.SAVE_RESULT_REQUESTED,
            "Save requested"
        )

        self._send_session_info()

    # ------------------------------------------------------------------
    # Responses
    # ------------------------------------------------------------------

    def _send_session_info(self):
        path, name = self._current_set_info()

        try:
            line = (
                "PrismSession: TX SESSION revision=%d saved=%d name='%s'"
                % (self._save_revision, 1 if path else 0, name)
            )
            # Polled every second: log changes only.
            if line != getattr(self, "_last_session_log", None):
                self._last_session_log = line
                self._s.log_message(line)
        except Exception:
            pass

        message = [
            0xF0,
            0x7D,
            0x32,
            self.RESP_SESSION_INFO,
            1 if path else 0,
            self._save_revision & 0x7F,
            (self._save_revision >> 7) & 0x7F
        ]

        message.extend(self._safe_text(name))
        message.append(0xF7)

        self._s._send_midi(tuple(message))

    def _send_save_event(self, name):
        try:
            self._s.log_message(
                "PrismSession: TX SAVE_EVENT revision=%d name='%s'"
                % (self._save_revision, name)
            )
        except Exception:
            pass

        message = [
            0xF0,
            0x7D,
            0x32,
            self.RESP_SAVE_EVENT,
            self._save_revision & 0x7F,
            (self._save_revision >> 7) & 0x7F,
            0x7F
        ]

        message.extend(self._set_token_bytes())
        message.extend(self._safe_text(name))
        message.append(0xF7)

        self._s._send_midi(tuple(message))

    def _send_save_started(self):
        self._s._send_midi((
            0xF0,
            0x7D,
            0x32,
            self.RESP_SAVE_STARTED,
            0xF7
        ))

    def _send_save_result(self, status, text=""):
        message = [
            0xF0,
            0x7D,
            0x32,
            self.RESP_SAVE_RESULT,
            int(status) & 0x7F
        ]

        message.extend(self._safe_text(text))
        message.append(0xF7)

        self._s._send_midi(tuple(message))

    def _safe_text(self, text):
        try:
            text = str(text)
        except Exception:
            text = ""

        try:
            text = text.encode("ascii", "replace").decode("ascii")
        except Exception:
            pass

        result = []

        for c in text:
            value = ord(c)
            result.append(
                value if 32 <= value <= 126 else ord("?")
            )

            if len(result) >= self.MAX_NAME_LENGTH:
                break

        return result

    # ------------------------------------------------------------------
    # Intelligent saving / project pairing
    # ------------------------------------------------------------------

    def _pair_parameter_sets(self):
        result = []
        wanted = set(self.PAIR_PARAM_NAMES)

        try:
            tracks = list(self._s.song().tracks)
        except Exception:
            return result

        for track in tracks:
            try:
                devices = list(track.devices)
            except Exception:
                continue

            for device in devices:
                # Pair params only live on Max devices; skip the rest cheaply.
                if 'MxDevice' not in str(getattr(device, 'class_name', '')):
                    continue

                found = {}

                try:
                    for param in device.parameters:
                        name = str(getattr(param, "name", ""))

                        if name in wanted:
                            found[name] = param

                except Exception:
                    continue

                if all(name in found for name in self.PAIR_PARAM_NAMES):
                    result.append(
                        tuple(found[name] for name in self.PAIR_PARAM_NAMES)
                    )

        return result

    def _native_pair_id(self, song):
        try:
            value = song.get_data(self.PAIR_DATA_KEY, None)
            # Do not truncate corrupt floats or accept booleans as IDs.
            if isinstance(value, bool) or not isinstance(value, (int, str)):
                return 0
            pair_id = int(value)
            return pair_id if 0 < pair_id < self.PAIR_ID_LIMIT else 0
        except Exception:
            return 0

    def _store_native_pair_id(self, song, pair_id):
        try:
            # A decimal string avoids numeric conversion by other API clients.
            song.set_data(self.PAIR_DATA_KEY, str(pair_id))
            return self._native_pair_id(song) == pair_id
        except Exception as e:
            self._s.log_message("PrismSession: Set pair storage failed: %s" % e)
            return False

    def _bridge_pair_chunks(self):
        self._pair_conflicted = False
        common = None
        for params in self._pair_parameter_sets():
            chunks = []
            for param in params:
                try:
                    value = int(round(float(param.value)))
                except Exception:
                    value = 0
                chunks.append(max(0, min(0x3FFF, value)))
            pair_id = self._pair_id_from_chunks(chunks)
            if not pair_id:
                continue
            if common is not None and common != chunks:
                self._pair_conflicted = True
                return [0, 0, 0]
            common = chunks
        return common if common is not None else [0, 0, 0]

    def _pair_id_from_chunks(self, chunks):
        return chunks[0] | (chunks[1] << 14) | (chunks[2] << 28)

    def _chunks_from_pair_id(self, pair_id):
        return [(pair_id >> (14 * index)) & 0x3FFF
                for index in range(self.PAIR_CHUNK_COUNT)]

    def _mirror_bridge_pair_id(self, pair_id):
        chunks = self._chunks_from_pair_id(pair_id)
        for params in self._pair_parameter_sets():
            for param, value in zip(params, chunks):
                try:
                    if int(round(float(param.value))) != value:
                        param.value = float(value)
                except Exception:
                    pass

    def _read_pair_chunks(self):
        song = self._s.song()
        pair_id = self._native_pair_id(song)
        if pair_id:
            self._pair_conflicted = False
            # Native Set data is authoritative, including after adding a Bridge.
            self._mirror_bridge_pair_id(pair_id)
            return self._chunks_from_pair_id(pair_id)

        chunks = self._bridge_pair_chunks()
        pair_id = self._pair_id_from_chunks(chunks)
        if pair_id:
            # Adopt an existing pair without allocating a different identity.
            self._store_native_pair_id(song, pair_id)
        return chunks

    def _set_pair_chunk(self, index, value):
        index = int(index)
        value = max(0, min(0x3FFF, int(value)))

        if index < 0 or index >= self.PAIR_CHUNK_COUNT:
            self._pending_pair = None
            return

        song = self._s.song()
        path, _ = self._current_set_info()
        if index == 0:
            self._pending_pair = (song, path, [value])
            return

        pending = self._pending_pair
        if (pending is None or pending[0] != song or pending[1] != path or
                len(pending[2]) != index):
            self._pending_pair = None
            return

        pending[2].append(value)
        if index != self.PAIR_CHUNK_COUNT - 1:
            return

        self._pending_pair = None
        pair_id = self._pair_id_from_chunks(pending[2])
        if not pair_id:
            return

        existing_pair = self._pair_id_from_chunks(self._read_pair_chunks())
        if self._pair_conflicted or (existing_pair and existing_pair != pair_id):
            self._send_set_context()
            return

        stored = self._store_native_pair_id(song, pair_id)
        self._mirror_bridge_pair_id(pair_id)
        # Older Live versions can retain their original Bridge storage path.
        stored = stored or self._pair_id_from_chunks(self._bridge_pair_chunks()) == pair_id
        self._s.log_message("PrismSession: pair=%d stored=%d" % (pair_id, stored))
        # This read-back context is the acknowledgement. Prism requests the
        # first-pair persistence save only after the returned ID matches.
        self._send_set_context()

    def _send_set_context(self):
        token_bytes = self._set_token_bytes()
        path, name = self._current_set_info()
        chunks = self._read_pair_chunks()

        message = [
            0xF0,
            0x7D,
            0x32,
            self.RESP_SET_CONTEXT,
            0x40 | (1 if path else 0) | (0x20 if self._pair_conflicted else 0)
        ]

        for value in chunks:
            message.extend((
                value & 0x7F,
                (value >> 7) & 0x7F
            ))

        message.extend(token_bytes)
        message.extend((self._save_revision & 0x7F, (self._save_revision >> 7) & 0x7F))
        message.extend(self._safe_text(name))
        message.append(0xF7)

        self._s._send_midi(tuple(message))

        pair_id = (
            chunks[0] |
            (chunks[1] << 14) |
            (chunks[2] << 28)
        )

        if pair_id != 0 and path:
            self._remember_pair_path(pair_id, path)

        line = "PrismSession: TX CONTEXT pair=%d name='%s'" % (pair_id, name)
        # Polled every second: log changes only.
        if line != getattr(self, "_last_context_log", None):
            self._last_context_log = line
            self._s.log_message(line)

    def _pair_cache_path(self):
        folder = os.path.expanduser("~/Library/Application Support/PrismScript")
        if not os.path.isdir(folder):
            os.makedirs(folder)
        return os.path.join(folder, "AbletonPairPaths.json")

    def _load_pair_paths(self):
        try:
            with open(self._pair_cache_path(), "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_pair_paths(self):
        temporary_path = None
        try:
            import tempfile
            cache_path = self._pair_cache_path()
            with tempfile.NamedTemporaryFile(mode="w", dir=os.path.dirname(cache_path),
                                             delete=False) as f:
                temporary_path = f.name
                json.dump(self._pair_paths, f)
            os.replace(temporary_path, cache_path)
            return True
        except Exception as e:
            self._s.log_message("PrismSession: pair cache save failed: %s" % e)
            return False
        finally:
            if temporary_path and os.path.exists(temporary_path):
                os.unlink(temporary_path)

    def _remember_pair_path(self, pair_id, path):
        if pair_id <= 0 or not path:
            return

        key = str(pair_id)

        # Polled every second: only touch disk when something changed.
        if self._pair_paths.get(key) == path:
            return

        # Remove old pair pointing at same Live Set.
        previous_paths = dict(self._pair_paths)
        for old_key, old_path in list(self._pair_paths.items()):
            if old_key != key and old_path == path:
                del self._pair_paths[old_key]

        self._pair_paths[key] = path
        if not self._save_pair_paths():
            # Keep the index eligible for retry after a temporary disk failure.
            self._pair_paths = previous_paths

    def _open_paired_set(self, pair_id):
        path = self._pair_paths.get(str(pair_id))

        if not path or not os.path.isfile(path):
            self._s.log_message("PrismSession: no path for pair=%d" % pair_id)
            return

        current_path, _ = self._current_set_info()

        if current_path and os.path.realpath(current_path) == os.path.realpath(path):
            self._s.log_message("PrismSession: pair already open=%d" % pair_id)
            return

        self._s.log_message("PrismSession: opening pair=%d path='%s'" % (pair_id, path))
        subprocess.Popen(["/usr/bin/open", path])
