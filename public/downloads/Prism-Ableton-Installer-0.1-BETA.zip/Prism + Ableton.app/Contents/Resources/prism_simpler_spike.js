autowatch = 1;
inlets = 1;
outlets = 1;

var activeState = false;
var liveApiReady = false;
var holdState = false;
var resumeAfterHold = false;

var PAD_COUNT = 16;
var PARAMS_PER_PAD = 24;
var FIRST_PAD_NOTE = 36;
var ACTIVE_PARAM_COUNT = 24;

var START_DEBOUNCE_MS = 120;
var HOLD_REACQUIRE_DELAY_MS = 900;
var DEVICE_CHANGE_DELAY_MS = 900;
var PAD_DELAY_MS = 20;

var TARGET_PARAMS = [
    ["Transpose"],                                                   // 0
    ["Detune"],                                                      // 1
    ["Pan"],                                                         // 2
    ["Volume"],                                                      // 3
    null,                                                            // 4 absolute sample Start
    null,                                                            // 5 absolute sample End
    ["S Start"],                                                     // 6 hidden p-lock Start
    ["S Length"],                                                    // 7 hidden p-lock End/Length
    ["F On"],                                                        // 8 Filter On
    ["Filter Type"],                                                 // 9
    ["Filter Circuit - LP/HP", "Filter Circuit - BP/NO/Morph"],      // 10 Circuit Type
    ["Filt < Vel"],                                                  // 11 Vel -> Flt
    ["Filter Res"],                                                  // 12
    ["Filter Freq"],                                                 // 13
    null,                                                            // 14
    null,                                                            // 15
    ["Spread"],                                                      // 16
    ["Vol < Vel"],                                                   // 17 Vel -> Vel
    ["Pan < Rnd"],                                                   // 18 Ran -> Pan
    null,                                                            // 19
    ["Ve Attack"],                                                   // 20
    ["Ve Decay"],                                                    // 21
    ["Ve Sustain"],                                                  // 22
    ["Ve Release"]                                                   // 23
];

var api = null;
var devicesObserver = null;
var ignoreInitialDevicesCallback = false;

var modeObservers = new Array(PAD_COUNT);
var modeObserverIds = new Array(PAD_COUNT);
var lastPlaybackModes = new Array(PAD_COUNT);

var startTask = null;
var padTask = null;

var generation = 0;
var scheduledGeneration = 0;
var padGeneration = 0;

var currentPad = 0;
var padChains = null;
var simplerPaths = new Array(PAD_COUNT);
var plockStartAvailable = new Array(PAD_COUNT);
var plockEndAvailable = new Array(PAD_COUNT);
var lastBoundIds = {};
var boundSpecs = {};   // voice -> { id, min, max } of the parameter it owns
var heardValues = {};  // voice -> value live.remote~ is applying (parameter units)
var dirtyVoices = {};  // voices Prism moved since bind (Live's stored value is stale)


var layoutCache = {};

function clean(v) {
    return (v + "").split('"').join("");
}

function ensureRuntime() {
    if (!api) api = new LiveAPI("this_device");
    if (!startTask) startTask = new Task(runStartTask, this);
    if (!padTask) padTask = new Task(runPadTask, this);
}

function gotoPath(path) {
    try {
        ensureRuntime();
        api.goto(path);
        return parseInt(api.id) > 0;
    } catch(e) {
        return false;
    }
}

function parkApi() {
    if (!api) return;

    try {
        // Do not leave the shared scratch LiveAPI sitting on a
        // Simpler / drum_pads path while Ableton replaces the Rack.
        api.goto("this_device");
    } catch(e) {
        api = null;
    }
}

function getString(prop) {
    try { return clean(api.get(prop)); }
    catch(e) { return ""; }
}

function getInt(prop) {
    try { return parseInt(api.get(prop) + ""); }
    catch(e) { return 0; }
}

function getFloat(prop) {
    try { return parseFloat(api.get(prop) + ""); }
    catch(e) { return NaN; }
}

function getCount(child) {
    try { return api.getcount(child); }
    catch(e) { return 0; }
}

function globalSlot(pad, param) {
    return pad * PARAMS_PER_PAD + param;
}

function voiceFor(pad, param) {
    return globalSlot(pad, param) + 1;
}

/* ---------- DEVICE OBSERVER ---------- */

function attachDevicesObserver() {
    if (devicesObserver || !liveApiReady || !activeState) return;

    try {
        ignoreInitialDevicesCallback = true;
        devicesObserver = new LiveAPI(onDevicesChanged, "this_device canonical_parent");
        devicesObserver.property = "devices";
        post("[SIMPLER OPT] devices observer attached\n");
    } catch(e) {
        devicesObserver = null;
        ignoreInitialDevicesCallback = false;
        post("[SIMPLER OPT] devices observer ERROR " + e + "\n");
    }
}

function detachDevicesObserver() {
    if (!devicesObserver) return;

    try {
        devicesObserver.property = "";
        devicesObserver.id = 0;
    } catch(e) {}

    devicesObserver = null;
    ignoreInitialDevicesCallback = false;
    post("[SIMPLER OPT] devices observer detached\n");
}

function onDevicesChanged(args) {
    if (!activeState || !liveApiReady) return;
    if ((args[0] + "") !== "devices") return;

    if (ignoreInitialDevicesCallback) {
        ignoreInitialDevicesCallback = false;
        return;
    }

    if (holdState) {
        resumeAfterHold = true;
        post("[SIMPLER OPT] devices changed during hold\n");
        return;
    }

    post("[SIMPLER OPT] devices changed -> resolve\n");
    requestResolve(DEVICE_CHANGE_DELAY_MS);
}

/* ---------- MODE OBSERVERS ---------- */

function detachModeObserver(pad) {
    var observer = modeObservers[pad];

    if (observer) {
        try {
            observer.property = "";
            observer.id = 0;
        } catch(e) {}
    }

    modeObservers[pad] = null;
    modeObserverIds[pad] = 0;
    lastPlaybackModes[pad] = undefined;
}

function detachModeObservers() {
    for (var pad = 0; pad < PAD_COUNT; pad++) detachModeObserver(pad);
}

function attachModeObserver(pad, simplerPath) {
    if (!gotoPath(simplerPath)) {
        detachModeObserver(pad);
        return;
    }

    var simplerId = parseInt(api.id);

    if (!(simplerId > 0)) {
        detachModeObserver(pad);
        return;
    }

    if (modeObservers[pad] && modeObserverIds[pad] === simplerId) return;

    // Do not transfer envelope values between unrelated Simpler instances.
    detachModeObserver(pad);

    var ignoreInitial = true;

    try {
        var observer = new LiveAPI(function(args) {
            if (!activeState || !liveApiReady) return;
            if ((args[0] + "") !== "playback_mode") return;

            if (ignoreInitial) {
                ignoreInitial = false;
                return;
            }

            // Stop stale Classic S Start / S Length ownership immediately.
            plockStartAvailable[pad] = false;
            plockEndAvailable[pad] = false;
            clearVoice(voiceFor(pad, 6));
            clearVoice(voiceFor(pad, 7));

            if (holdState) {
                resumeAfterHold = true;
                return;
            }

            post("[SIMPLER OPT] pad=" + pad + " playback_mode changed -> resolve\n");
            requestResolve(START_DEBOUNCE_MS);
        });

        // Observe the resolved Simpler OBJECT, not its Drum Rack path.
        // This prevents MxD from trying to re-evaluate a stale
        // "... drum_pads ..." path while a Rack is being replaced.
        observer.id = simplerId;

        modeObservers[pad] = observer;
        modeObserverIds[pad] = simplerId;
        observer.property = "playback_mode";

    } catch(e) {
        modeObservers[pad] = null;
        modeObserverIds[pad] = 0;
        lastPlaybackModes[pad] = undefined;
        plockStartAvailable[pad] = false;
        plockEndAvailable[pad] = false;

        post("[SIMPLER OPT] mode observer ERROR pad=" + pad + " " + e + "\n");
    }
}

/* ---------- OWNERSHIP ---------- */

function hold(v) {
    holdState = (v == 1);

    if (holdState) {
        resumeAfterHold = true;
        cancelResolve();

        // Release all live.remote~ ownership before the current
        // rack/Simplers are replaced.
        writeBackAll();
        outlet(0, 0, "clear");
        lastBoundIds = {};
        forgetBindings();

        // Invalidate paths/availability belonging to the old topology.
        simplerPaths = new Array(PAD_COUNT);
        plockStartAvailable = new Array(PAD_COUNT);
        plockEndAvailable = new Array(PAD_COUNT);

        // Drop LiveAPI observers pointing into the old rack/Simplers.
        detachDevicesObserver();
        detachModeObservers();
        parkApi();

        post("[SIMPLER OPT] hold=1 -> remotes + observers detached\n");

        // Signal only after the full Hold teardown path has completed.
        outlet(0, "teardown_done");
        post("[SIMPLER OPT] teardown_done\n");
    }
    else {
        post("[SIMPLER OPT] hold=0\n");

        if (activeState && liveApiReady) {
            attachDevicesObserver();
            requestResolve(HOLD_REACQUIRE_DELAY_MS);
            resumeAfterHold = false;
        }
    }
}

function active(v) {
    activeState = (v == 1);

    if (!activeState) {
        cancelResolve();
        detachDevicesObserver();
        detachModeObservers();
        parkApi();

        // Hold already released every live.remote~ before active(0)
        // arrives. Do not issue the same clear twice.
        if (!holdState) {
            writeBackAll();
            outlet(0, 0, "clear");
            post("[SIMPLER OPT] inactive -> clear all\n");
        } else {
            post("[SIMPLER OPT] inactive while held -> already cleared\n");
        }

        lastBoundIds = {};
        forgetBindings();
        lastPlaybackModes = new Array(PAD_COUNT);
        simplerPaths = new Array(PAD_COUNT);
        plockStartAvailable = new Array(PAD_COUNT);
        plockEndAvailable = new Array(PAD_COUNT);
        return;
    }

    if (!liveApiReady || holdState) return;

    attachDevicesObserver();

    var delay = resumeAfterHold ? HOLD_REACQUIRE_DELAY_MS : START_DEBOUNCE_MS;
    resumeAfterHold = false;

    post("[SIMPLER OPT] active -> resolve delay=" + delay + "ms\n");
    requestResolve(delay);
}



function bang() {
    ensureRuntime();
    liveApiReady = true;

    if (activeState && !holdState) {
        attachDevicesObserver();
        requestResolve(START_DEBOUNCE_MS);
    } else {
        outlet(0, 0, "clear");
        lastBoundIds = {};
    }
}



/* ---------- SCHEDULER ---------- */

function requestResolve(delayMs) {
    if (!activeState || !liveApiReady || holdState) return;

    ensureRuntime();

    generation++;
    scheduledGeneration = generation;

    try { startTask.cancel(); } catch(e) {}
    try { padTask.cancel(); } catch(e) {}

    startTask.schedule(delayMs === undefined ? START_DEBOUNCE_MS : delayMs);
}

function cancelResolve() {
    generation++;

    if (startTask) {
        try { startTask.cancel(); } catch(e) {}
    }

    if (padTask) {
        try { padTask.cancel(); } catch(e) {}
    }
}

function runStartTask() {
    var gen = scheduledGeneration;

    if (gen != generation || !activeState || !liveApiReady || holdState)
        return;

    beginResolve(gen);
}

function runPadTask() {
    var gen = padGeneration;

    if (gen != generation || !activeState || !liveApiReady || holdState)
        return;

    processPad(gen);
}

function schedulePad(gen, delayMs) {
    if (gen != generation || !activeState || holdState)
        return;

    ensureRuntime();
    padGeneration = gen;

    try { padTask.cancel(); } catch(e) {}

    padTask.schedule(delayMs);
}

/* ---------- LIVE TREE ---------- */

function findDrumRack(containerPath) {
    if (!gotoPath(containerPath))
        return null;

    var count = getCount("devices");

    for (var i = 0; i < count; i++) {
        var path = containerPath + " devices " + i;

        if (!gotoPath(path))
            continue;

        var cls = getString("class_name");

        if (cls == "DrumGroupDevice")
            return path;

        if (cls.indexOf("GroupDevice") !== -1) {
            var chains = getCount("chains");

            for (var c = 0; c < chains; c++) {
                var found = findDrumRack(path + " chains " + c);

                if (found)
                    return found;
            }
        }
    }

    return null;
}

function buildPadChains(rackPath) {
    var table = {};

    if (!gotoPath(rackPath))
        return table;

    var count = getCount("drum_pads");

    for (var i = 0; i < count; i++) {
        var padPath = rackPath + " drum_pads " + i;

        if (!gotoPath(padPath))
            continue;

        var note = getInt("note");

        if (note < FIRST_PAD_NOTE || note >= FIRST_PAD_NOTE + PAD_COUNT)
            continue;

        if (getCount("chains") < 1)
            continue;

        table[note] = padPath + " chains 0";
    }

    return table;
}

function findSimpler(containerPath) {
    if (!gotoPath(containerPath))
        return null;

    var count = getCount("devices");

    for (var i = 0; i < count; i++) {
        var path = containerPath + " devices " + i;

        if (!gotoPath(path))
            continue;

        var cls = getString("class_name");
        var display = getString("class_display_name");

        if (cls == "OriginalSimpler" || display == "Simpler")
            return path;

        if (cls.indexOf("GroupDevice") !== -1) {
            var chains = getCount("chains");

            for (var c = 0; c < chains; c++) {
                var found = findSimpler(path + " chains " + c);

                if (found)
                    return found;
            }
        }
    }

    return null;
}

/* ---------- LAYOUT CACHE ---------- */

function targetMatches(target, name, original) {
    if (!target)
        return false;

    for (var i = 0; i < target.length; i++) {
        if (name == target[i] || original == target[i])
            return true;
    }

    return false;
}

function targetIndexFor(name, original) {
    for (var i = 0; i < ACTIVE_PARAM_COUNT; i++) {
        if (targetMatches(TARGET_PARAMS[i], name, original))
            return i;
    }

    return -1;
}

function makeAnchors(specs) {
    var preference = [
        3,  // Volume
        6,  // hidden S Start
        0,  // Transpose
        1,  // Detune
        2,  // Pan
        16, // Spread
        13, // Filter Freq
        12, // Filter Res
        17, // Vol < Vel
        18, // Pan < Rnd
        20, // Ve Attack
        21, // Ve Decay
        22, // Ve Sustain
        23, // Ve Release
        8,  // F On
        9,  // Filter Type
        11, // Filt < Vel
        7,  // hidden S Length
        10  // Circuit
    ];

    var anchors = [];

    for (var i = 0; i < preference.length && anchors.length < 4; i++) {
        var target = preference[i];
        var spec = specs[target];

        if (spec)
            anchors.push({
                target: target,
                index: spec.index
            });
    }

    return anchors;
}

function validateLayout(simplerPath, layout, count) {
    if (!layout || layout.total != count)
        return false;

    for (var i = 0; i < layout.anchors.length; i++) {
        var anchor = layout.anchors[i];

        if (anchor.index < 0 || anchor.index >= count)
            return false;

        if (!gotoPath(simplerPath + " parameters " + anchor.index))
            return false;

        var name = getString("name");
        var original = getString("original_name");
        var wanted = TARGET_PARAMS[anchor.target];

        if (!targetMatches(wanted, name, original))
            return false;
    }

    return true;
}

function discoverLayout(simplerPath, count) {
    var specs = new Array(ACTIVE_PARAM_COUNT);
    var fadeInSpec = null;
    var fadeOutSpec = null;

    // Scan the full parameter list. Fade In / Fade Out are auxiliary
    // mode-dependent targets and are not included in TARGET_PARAM_COUNT.
    for (var i = 0; i < count; i++) {
        if (!gotoPath(simplerPath + " parameters " + i))
            continue;

        var name = getString("name");
        var original = getString("original_name");
        var target = targetIndexFor(name, original);

        if (!fadeInSpec && (name == "Fade In" || original == "Fade In")) {
            var pmin = getFloat("min");
            var pmax = getFloat("max");

            if (!isNaN(pmin) && !isNaN(pmax)) {
                fadeInSpec = {
                    index: i,
                    min: pmin,
                    max: pmax
                };
            }
        }

        if (!fadeOutSpec && (name == "Fade Out" || original == "Fade Out")) {
            var pmin = getFloat("min");
            var pmax = getFloat("max");

            if (!isNaN(pmin) && !isNaN(pmax)) {
                fadeOutSpec = {
                    index: i,
                    min: pmin,
                    max: pmax
                };
            }
        }

        if (target < 0 || specs[target])
            continue;

        var pmin = getFloat("min");
        var pmax = getFloat("max");

        if (isNaN(pmin) || isNaN(pmax))
            continue;

        specs[target] = {
            index: i,
            min: pmin,
            max: pmax
        };

    }

    var layout = {
        total: count,
        specs: specs,
        fadeInSpec: fadeInSpec,
        fadeOutSpec: fadeOutSpec,
        anchors: makeAnchors(specs)
    };

    // Parameter layouts can differ by Simpler playback mode even when
    // the raw parameter count happens to match.
    var key = count + ":" + getPlaybackMode(simplerPath);

    if (!layoutCache[key])
        layoutCache[key] = [];

    layoutCache[key].push(layout);


    return layout;
}

function getPlaybackMode(simplerPath) {
    if (!gotoPath(simplerPath))
        return 0;

    return getInt("playback_mode");
}

function getLayout(simplerPath) {
    if (!gotoPath(simplerPath))
        return null;

    var count = getCount("parameters");

    if (count <= 0)
        return null;

    var mode = getPlaybackMode(simplerPath);
    var key = count + ":" + mode;
    var candidates = layoutCache[key];

    if (candidates) {
        for (var i = 0; i < candidates.length; i++) {
            if (validateLayout(simplerPath, candidates[i], count))
                return candidates[i];
        }
    }

    return discoverLayout(simplerPath, count);
}

/* ---------- ENVELOPE MODE TRANSFER ---------- */

function transferSpecValue(simplerPath, fromSpec, toSpec) {
    if (!fromSpec || !toSpec)
        return false;

    if (!gotoPath(simplerPath + " parameters " + fromSpec.index))
        return false;

    var value = getFloat("value");

    // If Prism moved the source parameter, Live's stored value is stale:
    // transfer what is actually being heard.
    var fromVoice = voiceForParamId(parseInt(api.id));
    if (fromVoice >= 0 && dirtyVoices[fromVoice])
        value = heardValues[fromVoice];

    if (isNaN(value))
        return false;

    var normalized = 0;

    if (fromSpec.max > fromSpec.min) {
        normalized =
            (value - fromSpec.min) /
            (fromSpec.max - fromSpec.min);
    }

    normalized = Math.max(0, Math.min(1, normalized));

    var targetValue =
        toSpec.min +
        normalized *
        (toSpec.max - toSpec.min);

    if (!gotoPath(simplerPath + " parameters " + toSpec.index))
        return false;

    try {
        api.set("value", targetValue);

        // If a remote owns the target, it would keep playing its old value:
        // push the new one through it too.
        var toVoice = voiceForParamId(parseInt(api.id));
        if (toVoice >= 0) {
            outlet(0, toVoice, "raw", targetValue);
            heardValues[toVoice] = targetValue;
            delete dirtyVoices[toVoice];
        }
        return true;

    } catch(e) {
        post("[SIMPLER OPT] envelope transfer ERROR " + e + "\n");
        return false;
    }
}

function transferEnvelopeModeValues(simplerPath, layout, oldMode, newMode) {
    if (!layout)
        return;

    if (oldMode == 0 && newMode != 0) {
        var attackTransferred =
            transferSpecValue(
                simplerPath,
                layout.specs[20],
                layout.fadeInSpec
            );

        var releaseTransferred =
            transferSpecValue(
                simplerPath,
                layout.specs[23],
                layout.fadeOutSpec
            );

        post(
            "[SIMPLER OPT] envelope transfer ADSR -> Fade attack=" +
            (attackTransferred ? 1 : 0) +
            " release=" +
            (releaseTransferred ? 1 : 0) +
            "\n"
        );
    }
    else if (oldMode != 0 && newMode == 0) {
        var fadeInTransferred =
            transferSpecValue(
                simplerPath,
                layout.fadeInSpec,
                layout.specs[20]
            );

        var fadeOutTransferred =
            transferSpecValue(
                simplerPath,
                layout.fadeOutSpec,
                layout.specs[23]
            );

        post(
            "[SIMPLER OPT] envelope transfer Fade -> ADSR attack=" +
            (fadeInTransferred ? 1 : 0) +
            " release=" +
            (fadeOutTransferred ? 1 : 0) +
            "\n"
        );
    }
}

/* ---------- SAMPLE MARKERS ---------- */


function setSampleMarker(pad, isStart, value) {
    if (!activeState || !liveApiReady || holdState)
        return;

    if (pad < 0 || pad >= PAD_COUNT)
        return;

    var simpler = simplerPaths[pad];

    if (!simpler)
        return;

    value = parseInt(value);

    if (isNaN(value))
        return;

    value = Math.max(0, Math.min(127, value));

    if (!gotoPath(simpler + " sample"))
        return;

    var length = getInt("length");
    var start = getInt("start_marker");
    var end = getInt("end_marker");

    if (length <= 1)
        return;

        // Last valid marker position is length - 1.
    var maxPos = length - 1;
    var target = Math.round((value / 127.0) * maxPos);
    target = Math.max(0, Math.min(maxPos, target));

    try {
        if (isStart) {
            target =
                Math.min(
                    target,
                    Math.max(0, end - 1)
                );

            api.set("start_marker", target);
        }
        else {
            target =
                Math.max(
                    target,
                    Math.min(maxPos, start + 1)
                );

            target =
                Math.min(
                    maxPos,
                    target
                );

            api.set("end_marker", target);
        }

    } catch(e) {
        post(
            "[SIMPLER OPT] marker ERROR pad=" +
            pad +
            " start=" +
            (isStart ? 1 : 0) +
            " value=" +
            value +
            " target=" +
            target +
            " " +
            e +
            "\n"
        );
    }
}

// Receives: marker remoteSlot value
//
// slot 4:
// absolute sample Start
//
// slot 5:
// absolute sample End
//
// slot 6:
// Classic -> S Start via live.remote~
// otherwise -> absolute Start
//
// slot 7:
// Classic -> S Length via live.remote~
// otherwise -> absolute End

function marker(slot, value) {
    if (!activeState || !liveApiReady || holdState)
        return;

    slot = parseInt(slot);
    value = parseInt(value);

    if (isNaN(slot) || isNaN(value))
        return;

    var pad = Math.floor(slot / PARAMS_PER_PAD);
    var param = slot % PARAMS_PER_PAD;

    if (pad < 0 || pad >= PAD_COUNT)
        return;

    if (param == 4) {
        setSampleMarker(pad, true, value);
        return;
    }

    if (param == 5) {
        setSampleMarker(pad, false, value);
        return;
    }

    if (param == 6) {
        if (plockStartAvailable[pad])
            return;

        setSampleMarker(pad, true, value);
        return;
    }

    if (param == 7) {
        if (plockEndAvailable[pad])
            return;

        setSampleMarker(pad, false, value);
        return;
    }
}

/* ---------- RESOLVE ---------- */

function beginResolve(gen) {
    try {
        var rack = findDrumRack("this_device canonical_parent");

        if (!rack) {
            detachModeObservers();

            simplerPaths = new Array(PAD_COUNT);
            plockStartAvailable = new Array(PAD_COUNT);
            plockEndAvailable = new Array(PAD_COUNT);

            post("[SIMPLER OPT] no Drum Rack\n");

            outlet(0, 0, "clear");

            lastBoundIds = {};

            return;
        }

        padChains = buildPadChains(rack);

        currentPad = 0;

        schedulePad(gen, 0);

    } catch(e) {
        post("[SIMPLER OPT] begin ERROR " + e + "\n");
    }
}

function processPad(gen) {
	if (currentPad >= PAD_COUNT) {
    	return;
	}

    var pad = currentPad++;
    var note = FIRST_PAD_NOTE + pad;

    try {
        var chain = padChains[note];

        if (!chain) {
            simplerPaths[pad] = null;
            plockStartAvailable[pad] = false;
            plockEndAvailable[pad] = false;

            detachModeObserver(pad);
            clearPad(pad);

            schedulePad(gen, PAD_DELAY_MS);
            return;
        }

        var simpler = findSimpler(chain);

        if (!simpler) {
            simplerPaths[pad] = null;
            plockStartAvailable[pad] = false;
            plockEndAvailable[pad] = false;

            detachModeObserver(pad);
            clearPad(pad);

            schedulePad(gen, PAD_DELAY_MS);
            return;
        }

        simplerPaths[pad] = simpler;

        attachModeObserver(pad, simpler);

        var playbackMode = getPlaybackMode(simpler);
        var layout = getLayout(simpler);

        if (!layout) {
            plockStartAvailable[pad] = false;
            plockEndAvailable[pad] = false;

            clearPad(pad);

            schedulePad(gen, PAD_DELAY_MS);
            return;
        }

        // Hidden p-lock DeviceParameters only own their
        // live.remote~ voices in Classic.
        plockStartAvailable[pad] =
            playbackMode == 0 &&
            !!layout.specs[6];

        plockEndAvailable[pad] =
            playbackMode == 0 &&
            !!layout.specs[7];

        var previousMode = lastPlaybackModes[pad];

        if (
            previousMode !== undefined &&
            previousMode != playbackMode
        ) {
            transferEnvelopeModeValues(
                simpler,
                layout,
                previousMode,
                playbackMode
            );
        }

        lastPlaybackModes[pad] = playbackMode;

        for (var param = 0; param < ACTIVE_PARAM_COUNT; param++) {
            var voice = voiceFor(pad, param);

            // Slots 4/5 are LOM Sample markers,
            // not DeviceParameters.
            if (!TARGET_PARAMS[param]) {
                clearVoice(voice);
                continue;
            }

            var spec = layout.specs[param];

            // Slots 6/7 use S Start / S Length only in Classic.
            // marker() owns their absolute fallback in other modes.
            if (
                (param == 6 || param == 7) &&
                playbackMode != 0
            ) {
                spec = null;
            }

            // Only Attack and Release change destination
            // based on playback mode.
            //
            // Classic:
            //   20 -> Ve Attack
            //   23 -> Ve Release
            //
            // One-Shot / Slicing:
            //   20 -> Fade In
            //   23 -> Fade Out
            //
            // Decay and Sustain remain mapped in every mode.
            if (playbackMode != 0) {
                if (param == 20) {
                    spec = layout.fadeInSpec;
                }
                else if (param == 23) {
                    spec = layout.fadeOutSpec;
                }
            }

            if (!spec) {
                clearVoice(voice);
                continue;
            }

            if (!gotoPath(simpler + " parameters " + spec.index)) {
                clearVoice(voice);
                continue;
            }

            var id = parseInt(api.id);

            if (!(id > 0)) {
                clearVoice(voice);
                continue;
            }

			if (lastBoundIds[voice] === id) {
    			// Already owned by this voice. live.remote~ itself makes is_enabled = 0,
    			// so do not re-test ownership for an unchanged binding.
    			continue;
			}

			// Only acquire a NEW target if Live says it is directly controllable.
			// is_enabled == 0 includes Macro-controlled parameters, parameters owned by
			// another live.remote~, and parameters Live otherwise considers unavailable.
			var enabled = getInt("is_enabled");

			if (enabled !== 1) {
    			clearVoice(voice);
    			continue;
			}

var loadedValue = getFloat("value");

            if (isNaN(loadedValue)) {
                clearVoice(voice);
                continue;
            }

            if (
                lastBoundIds[voice] !== undefined &&
                lastBoundIds[voice] !== 0
            ) {
                writeBackVoice(voice);
                outlet(0, voice, "clear");
            }

            // Bind first (deferred inside the voice), then seed. The direct
            // "raw" lands before the bind; the voice's deferlow'd copy lands
            // right after it, so an old held value can't be re-applied.
            outlet(
                0,
                voice,
                "bind",
                id,
                spec.min,
                spec.max
            );

            outlet(
                0,
                voice,
                "raw",
                loadedValue
            );

            lastBoundIds[voice] = id;
            boundSpecs[voice] = { id: id, min: spec.min, max: spec.max };
            heardValues[voice] = loadedValue;
            delete dirtyVoices[voice];        
        }

    } catch(e) {
        post(
            "[SIMPLER OPT] pad=" +
            pad +
            " ERROR " +
            e +
            "\n"
        );

        plockStartAvailable[pad] = false;
        plockEndAvailable[pad] = false;

        clearPad(pad);

    }

    schedulePad(gen, PAD_DELAY_MS);
}

/* ---------- HEARD-VALUE TRACKING / WRITE-BACK ---------- */

// Patch tap: pack i s i -> prepend voicevalue. Same numbers poly~ receives.
function voicevalue(voice, tag, v) {
    var spec = boundSpecs[voice];
    if (!spec) return;
    heardValues[voice] = spec.min + (v / 127.0) * (spec.max - spec.min);
    dirtyVoices[voice] = true;
}

// live.remote~ never writes Live's stored value. Before releasing a
// parameter, store what it was actually playing so nothing jumps back.
function writeBackVoice(voice) {
    if (!dirtyVoices[voice]) return;
    delete dirtyVoices[voice];

    var spec = boundSpecs[voice];
    if (!spec || !spec.id) return;

    try {
        var wb = new LiveAPI("id " + spec.id);
        if (parseInt(wb.id) === 0) return;   // parameter is gone

        var v = Math.max(spec.min, Math.min(spec.max, heardValues[voice]));
        if (parseInt(wb.get("is_quantized")) === 1) v = Math.round(v);
        wb.set("value", v);
    } catch (e) {
        post("[SIMPLER OPT] write-back ERROR voice=" + voice + " " + e + "\n");
    }
}

function writeBackAll() {
    var voices = [];
    for (var key in dirtyVoices) voices.push(parseInt(key));
    for (var i = 0; i < voices.length; i++) writeBackVoice(voices[i]);
    dirtyVoices = {};
}

function forgetBindings() {
    boundSpecs = {};
    heardValues = {};
    dirtyVoices = {};
}

function voiceForParamId(id) {
    for (var key in boundSpecs) {
        if (boundSpecs[key] && boundSpecs[key].id === id) return parseInt(key);
    }
    return -1;
}

/* ---------- CLEAR ---------- */

function clearPad(pad) {
    for (var param = 0; param < ACTIVE_PARAM_COUNT; param++) {
        clearVoice(
            voiceFor(
                pad,
                param
            )
        );
    }
}

function clearVoice(voice) {
    if (
        lastBoundIds[voice] === undefined ||
        lastBoundIds[voice] === 0
    ) {
        return;
    }

    writeBackVoice(voice);

    outlet(
        0,
        voice,
        "clear"
    );

    lastBoundIds[voice] = 0;
    delete boundSpecs[voice];
    delete heardValues[voice];
}