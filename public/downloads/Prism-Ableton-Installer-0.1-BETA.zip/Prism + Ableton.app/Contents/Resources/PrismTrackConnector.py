from __future__ import absolute_import, print_function, unicode_literals

class PrismTrackConnector(object):
    REQUEST_TYPE = 0x27
    RESPONSE_TYPE = 0x28

    CMD_GET_TRACKS = 0x01
    CMD_CONNECT = 0x02
    CMD_DISCONNECT = 0x03
    CMD_CREATE_MIDI_TRACK = 0x04

    RESP_LIST_BEGIN = 0x01
    RESP_TRACK = 0x02
    RESP_LIST_END = 0x03
    RESP_CONNECT_OK = 0x04
    RESP_DISCONNECT_OK = 0x05
    RESP_SELECTION = 0x06
    RESP_ERROR = 0x7F

    FLAG_SELECTED = 1 << 0
    NO_PRISM_TRACK = 0x7F
    MAX_NAME_LENGTH = 40

    ERR_BAD_COMMAND = 1
    ERR_PRISM_TRACK = 2
    ERR_LIVE_TRACK = 3
    ERR_NOT_MIDI = 4
    ERR_CONNECT = 5

    def __init__(self, script):
        self._s = script
        self._has_requested_tracks = False
        self._requesting_prism_track = 0

    def receive(self, midi_bytes):
        # F0 7D 27 command prismTrack liveLo liveHi arg F7
        if len(midi_bytes) < 9:
            return
        if midi_bytes[0] != 0xF0 or midi_bytes[1] != 0x7D or midi_bytes[2] != self.REQUEST_TYPE:
            return
        command = int(midi_bytes[3]) & 0x7F
        prism_track = int(midi_bytes[4]) & 0x7F
        live_index = (int(midi_bytes[5]) & 0x7F) | ((int(midi_bytes[6]) & 0x7F) << 7)
        self._s.log_message("PrismTrack: RX cmd=0x%02X prism=%d live=%d" % (command, prism_track, live_index))
        if command == self.CMD_GET_TRACKS:
            self.send_tracks(prism_track)
        elif command == self.CMD_CONNECT:
            self._connect(prism_track, live_index)
        elif command == self.CMD_DISCONNECT:
            self._disconnect(prism_track)
        elif command == self.CMD_CREATE_MIDI_TRACK:
            self._create_midi_track(prism_track)
        else:
            self._send_error(self.ERR_BAD_COMMAND, "Unknown track command")

    def send_tracks(self, requesting_prism_track=0):
        self._has_requested_tracks = True
        self._requesting_prism_track = requesting_prism_track
        try:
            tracks = list(self._s.song().tracks)
            selected = self._s.song().view.selected_track
            midi_tracks = []
            for live_index, track in enumerate(tracks):
                try:
                    if bool(getattr(track, 'has_midi_input', False)):
                        midi_tracks.append((live_index, track))
                except Exception:
                    pass
            self._send_list_begin(requesting_prism_track, len(midi_tracks))
            for live_index, track in midi_tracks:
                owner = self._s._get_link_for_track(track)
                owner_id = owner.track_id if owner is not None and not owner._detached else self.NO_PRISM_TRACK
                flags = self.FLAG_SELECTED if track == selected else 0
                self._send_track(live_index, owner_id, flags, track)
            self._send_list_end(requesting_prism_track, len(midi_tracks))
            self._s.log_message("PrismTrack: list sent midi=%d total=%d" % (len(midi_tracks), len(tracks)))
        except Exception as e:
            self._send_error(self.ERR_CONNECT, "Track list failed: %s" % str(e))

    def send_selection(self):
        if not self._has_requested_tracks or not getattr(self._s, '_connected', False):
            return
        live_index = 0x3FFF
        try:
            selected = self._s.song().view.selected_track
            for i, track in enumerate(self._s.song().tracks):
                if track == selected and bool(getattr(track, 'has_midi_input', False)):
                    live_index = i
                    break
        except Exception:
            pass
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_SELECTION,
                            live_index & 0x7F, (live_index >> 7) & 0x7F, 0xF7))

    def _connect(self, prism_track, live_index):
        def ready():
            self._send_connect_ok(prism_track, live_index)
            self.send_tracks(prism_track)

            # Ableton follows the connect: select the Live track you just linked.
            # Prism is already on prism_track, so the resulting selection event
            # doesn't move Prism anywhere.
            link = self._s._links.get(prism_track)
            if link is not None:
                try:
                    self._s.song().view.selected_track = link.track
                except Exception:
                    pass
        ok, code, text = self._s._connect_prism_to_live_track(prism_track, live_index, ready)
        if not ok:
            self._send_error(code, text)

    def _disconnect(self, prism_track):
        if not (0 <= prism_track < self._s.MAX_TRACKS):
            self._send_error(self.ERR_PRISM_TRACK, "Prism track out of range")
            return
        self._s._deactivate_track(prism_track)
        self._s._send_mode_status(prism_track, 0, self._s.STATUS_OK)
        self._send_disconnect_ok(prism_track)
        self.send_tracks(prism_track)

    def _send_list_begin(self, prism_track, count):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LIST_BEGIN,
                            prism_track & 0x7F, count & 0x7F, (count >> 7) & 0x7F, 0xF7))

    def _send_track(self, live_index, owner_id, flags, track):
        try:
            color = int(getattr(track, 'color', 0))
        except Exception:
            color = 0
        r = ((color >> 16) & 0xFF) >> 1
        g = ((color >> 8) & 0xFF) >> 1
        b = (color & 0xFF) >> 1
        message = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_TRACK,
                   live_index & 0x7F, (live_index >> 7) & 0x7F,
                   owner_id & 0x7F, flags & 0x7F, r & 0x7F, g & 0x7F, b & 0x7F]
        message.extend(self._safe_text(getattr(track, 'name', '')))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _send_list_end(self, prism_track, count):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_LIST_END,
                            prism_track & 0x7F, count & 0x7F, (count >> 7) & 0x7F, 0xF7))

    def _send_connect_ok(self, prism_track, live_index):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_CONNECT_OK,
                            prism_track & 0x7F, live_index & 0x7F, (live_index >> 7) & 0x7F, 0xF7))

    def _send_disconnect_ok(self, prism_track):
        self._s._send_midi((0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_DISCONNECT_OK,
                            prism_track & 0x7F, 0xF7))

    def _send_error(self, code, text):
        message = [0xF0, 0x7D, self.RESPONSE_TYPE, self.RESP_ERROR, code & 0x7F]
        message.extend(self._safe_text(text))
        message.append(0xF7)
        self._s._send_midi(tuple(message))

    def _create_midi_track(self, prism_track):
        if not (0 <= prism_track < self._s.MAX_TRACKS):
            self._send_error(self.ERR_PRISM_TRACK, "Prism track out of range")
            return
        try:
            song = self._s.song()
            song.create_midi_track(-1)
            new_track = list(song.tracks)[-1]

            def connect_new(p=prism_track, target=new_track):
                try:
                    tracks = list(self._s.song().tracks)
                    for live_index, track in enumerate(tracks):
                        if track == target:
                            self._connect(p, live_index)
                            return
                    self._send_error(self.ERR_LIVE_TRACK, "Created MIDI track not found")
                except Exception as e:
                    self._send_error(self.ERR_CONNECT, "Could not connect new MIDI track: %s" % str(e))

            self._s.schedule_message(1, connect_new)
            self._s.log_message("PrismTrack: created MIDI track -> connecting to Prism P%d" % prism_track)
        except Exception as e:
            self._send_error(self.ERR_CONNECT, "Could not create MIDI track: %s" % str(e))
    

    def _safe_text(self, text):
        try:
            text = str(text)
        except Exception:
            text = ""
        try:
            text = text.encode('ascii', 'replace').decode('ascii')
        except Exception:
            pass
        result = []
        for c in text:
            value = ord(c)
            result.append(value if 32 <= value <= 126 else ord('?'))
            if len(result) >= self.MAX_NAME_LENGTH:
                break
        return result
